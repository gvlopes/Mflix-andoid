# Ninja TV — Relatório de modificações e de testes

## 1. Base do projeto (nada foi recriado do zero)
O Ninja TV foi feito **a partir do projeto original (HarpiaPlay)**: mesma arquitetura (Java, Android nativo, AppCompat, Media3/ExoPlayer, OkHttp, Glide),
mesmo painel PHP, mesmas APIs e mesma comunicação com o site e o servidor IPTV. Mudou o pacote (`com.ninjatv.app`), o nome (Ninja TV),
a identidade visual e a tela inicial.

## 2. O que foi preservado (código reaproveitado, sem alteração de comportamento)
Login (usuário/senha com várias DNS do painel, ativação por código, teste grátis) · identificação do usuário e do aparelho (`api/device.php`) ·
validade/status da assinatura (servidor IPTV) · painel/`app-config.json` · temas e ícones remotos · atualização remota de configuração ·
histórico e "continuar assistindo" · favoritos · busca · perfil/conta · ajustes (PIN parental, categorias ocultas, formato ao vivo, etc.) ·
categorias de canais/filmes/séries do servidor · player Media3 (reconexão automática, ±10 s, próximo episódio, salva onde parou) ·
YouTube (em alta + busca, via painel) · Suporte (QR code, telefone, e-mail) · vídeo de fundo do login · mini QR no login · clima (Open-Meteo).

## 3. O que mudou
| Item | Implementação |
|---|---|
| Identidade | Paleta preta + dourado/laranja (`Theme.java`, `styles.xml`), logo/ícone/banner a partir da logo enviada, fundo ninja (lua, pagode, torii), partículas em brasa dourada |
| Cabeçalho | Logo NINJA TV, **usuário real** (usuário do servidor ou ID do aparelho), mensagem do painel (`home_notice`), indicador de conexão (conectividade real do aparelho), sino de notificações |
| Menu lateral | Início, Buscar, Histórico, Favoritos, **YouTube**, **Suporte**, Perfil, Ajustes — com ícone, texto, contorno dourado no item ativo/foco (YouTube oculta só se o admin desativar no painel) |
| Destaque | Os 5 melhores filmes entre os 30 mais recentes **do servidor** (séries se faltar), com capa/backdrop, nome, ano, gêneros, nota e sinopse reais (`get_vod_info`), botões ASSISTIR AGORA e MAIS INFORMAÇÕES, indicadores e troca automática |
| Assinatura | Coroa, ASSINATURA ATIVA/VENCIDA, data e hora de vencimento reais (atualizados no servidor ao abrir), indicador de status |
| Relógio e clima | Hora/data do aparelho + temperatura/cidade reais (Open-Meteo) |
| Categorias | 6 **estrelas ninja** em formato de shuriken (TV AO VIVO, FILMES, SÉRIES, ANIMES, KIDS, ESPORTES), com efeito de foco/toque e navegação por controle remoto |
| Animes / Kids / Esportes | O app original não tinha essas seções. Foram criadas como **grupos que reúnem as categorias do seu servidor cujo nome combina** (ex.: "Anime", "Infantil", "Esportes/ESPN/Premiere"). Se o servidor não tiver, a tela informa isso (sem dados falsos) |
| Histórico | Abas "Tudo" e "Em andamento"; YouTube fica na própria aba do YouTube |
| Player | Mesmo mecanismo; seek bar dourada/laranja neon (`res/layout/ninja_player_view.xml`) |

## 4. Observações honestas
- As estrelas foram **geradas por mim** (SVG renderizado em PNG), inspiradas na sua logo — não é a arte original. Para usar suas próprias artes,
  substitua `res/drawable-nodpi/star_<categoria>_n.webp` (normal) e `_f.webp` (em foco) por PNG/WebP 512×512 com fundo transparente.
  Categorias: `live, vod, series, anime, kids, sports`.
- Não usei personagens de anime/kids (direitos autorais): os emblemas são símbolos (olho, rosto sorridente, bola etc.).
- "Notificações" = aviso enviado pelo painel + alertas de vencimento da assinatura. Não há notificação push no app original.
- Painel: use o **NinjaTV-Painel** (tema padrão "Ninja Dourado"). O app usa o tema ativo do painel; se o painel tiver outro tema ativo, as cores mudam.
- A URL do painel está em `app/src/main/assets/app-config.json` (hoje aponta para `web.harpiabanner.shop`). **Troque pelo domínio do seu painel Ninja TV.**

## 5. Testes
Este ambiente **não tem Android SDK, aparelho, emulador nem acesso ao seu servidor IPTV/painel**. Portanto **NENHUM dos testes funcionais abaixo foi executado**
e eu não os declaro como aprovados. O que foi feito foi apenas **verificação estática**: balanceamento de código, todos os recursos (`R.drawable.*`, `R.layout.*`)
referenciados existem, imagens e XML geradas e conferidas visualmente.

| # | Teste | Situação |
|---|---|---|
| 1 | Login | não executado |
| 2 | Identificação do usuário | não executado |
| 3 | Comunicação com o site | não executado |
| 4 | Comunicação com o servidor | não executado |
| 5 | Carregamento dos conteúdos | não executado |
| 6 | TV ao vivo | não executado |
| 7 | Filmes | não executado |
| 8 | Séries | não executado |
| 9 | Animes | não executado |
| 10 | Kids | não executado |
| 11 | Esportes | não executado |
| 12 | Reprodução de vídeos | não executado |
| 13 | YouTube | não executado |
| 14 | Suporte | não executado |
| 15 | Histórico | não executado |
| 16 | Favoritos | não executado |
| 17 | Busca | não executado |
| 18 | Perfil | não executado |
| 19 | Configurações | não executado |
| 20 | Assinatura e validade | não executado |
| 21 | Notificações | não executado |
| 22 | Navegação por controle remoto | não executado |
| 23 | Barra de progresso do player | não executado |
| 24 | Navegação entre todas as telas | não executado |

Sugestão: gere o APK (GitHub Actions — `build-apk-ninjatv.yml` — ou Android Studio), instale e percorra esta lista; me envie qualquer erro de compilação ou comportamento estranho.

## 6. APK assinado
Não foi possível gerar o APK aqui (sem Android SDK). Foram entregues: a keystore do Ninja TV (`NinjaTV-assinatura.zip`) e o workflow do GitHub que compila e assina.
