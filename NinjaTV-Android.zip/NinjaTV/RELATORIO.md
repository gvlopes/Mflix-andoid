# Ninja TV — Relatório de modificações e de testes

## 1. Base do projeto (nada foi recriado do zero)
O Ninja TV foi feito **a partir do projeto original (HarpiaPlay)**: mesma arquitetura (Java, Android nativo, AppCompat, Media3/ExoPlayer, OkHttp, Glide),
mesmo painel PHP, mesmas APIs e mesma comunicação com o site e o servidor IPTV. Mudou o pacote (`com.ninjatv.app`), o nome (Ninja TV),
a identidade visual e a tela inicial.

## 2. O que foi preservado (código reaproveitado, sem alteração de comportamento)
Login (usuário/senha com várias DNS do painel, ativação por código, teste grátis) · identificação do usuário e do aparelho (`api/device.php`) ·
validade/status da assinatura (servidor IPTV) · painel/`app-config.json` · temas e ícones remotos · atualização remota de configuração ·
histórico e "continuar assistindo" · favoritos · busca · perfil/conta · ajustes (PIN parental, categorias ocultas, formato ao vivo, etc.) ·
categorias de canais/filmes/séries do servidor · player Media3 (reconexão automática, ±10 s, próximo episódio, salva onde parou) ·
YouTube (em alta + busca, via painel) · Suporte (QR code, telefone, e-mail) · vídeo de fundo do login · mini QR no login · clima (Open-Meteo).

## 3. O que mudou
| Item | Implementação |
|---|---|
| Identidade | Paleta preta + dourado/laranja (`Theme.java`, `styles.xml`), logo/ícone/banner a partir da logo enviada, **fundo ninja enviado por você** (horizontal na TV e um recorte vertical no celular), partículas em brasa dourada |
| Cabeçalho | Logo NINJA TV, **usuário real** (usuário do servidor ou ID do aparelho), mensagem do painel (`home_notice`), indicador de conexão (conectividade real do aparelho), sino de notificações |
| Menu lateral | Início, Buscar, Histórico, Favoritos, **YouTube**, **Suporte**, Perfil, Ajustes — com ícone, texto, contorno dourado no item ativo/foco (YouTube oculta só se o admin desativar no painel) |
| Destaque | Os 5 melhores filmes entre os 30 mais recentes **do servidor** (séries se faltar), com capa/backdrop, nome, ano, gêneros, nota e sinopse reais (`get_vod_info`), botões ASSISTIR AGORA e MAIS INFORMAÇÕES, indicadores e troca automática |
| Assinatura | Coroa, ASSINATURA ATIVA/VENCIDA, data e hora de vencimento reais (atualizados no servidor ao abrir), indicador de status |
| Relógio e clima | Hora/data do aparelho + temperatura/cidade reais (Open-Meteo) |
| Categorias | 6 **botões em cartão** (TV AO VIVO, FILMES, SÉRIES, ANIMES, KIDS, ESPORTES): cantos arredondados, borda dourada, brilho laranja no canto, ícone e nome, no estilo da tela de referência; efeito de foco/toque e navegação por controle remoto. (As estrelas foram retiradas.) |
| Animes / Kids / Esportes | O app original não tinha essas seções. Foram criadas como **grupos que reúnem as categorias do seu servidor cujo nome combina** (ex.: "Anime", "Infantil", "Esportes/ESPN/Premiere"). Se o servidor não tiver, a tela informa isso (sem dados falsos) |
| Histórico | Abas "Tudo" e "Em andamento"; YouTube fica na própria aba do YouTube |
| Player | Mesmo mecanismo; seek bar dourada/laranja neon (`res/layout/ninja_player_view.xml`) |

### 3.1 Celular (vertical) e TV (horizontal)
- Na **primeira abertura, antes do login**, o app pergunta **"Qual aparelho você está usando?"** — **Celular** ou **TV / TV Box** (sugere TV automaticamente se detectar Android TV).
- Celular: telas em **vertical** (tela inicial em coluna: cabeçalho, destaque, atalhos do menu em fileira, assinatura, relógio/clima e as 6 estrelas em grade 3×2; categorias viram fileira de chips). TV: **horizontal**, com menu lateral e controle remoto.
- Vídeo (player e YouTube) sempre em tela cheia horizontal. A escolha pode ser mudada em **Ajustes → Tipo de aparelho**.

- **Correção do corte nas bordas:** as telas estavam configuradas para **não se refazer ao girar**; se o aparelho estivesse deitado quando a pessoa escolhia "Celular", a tela era montada com a largura errada e cortava as laterais. Agora todas as telas (menos o vídeo) se refazem ao mudar de orientação, e há margens de segurança nas bordas.
- **Modo salvo sem "piscar":** o modo escolhido (TV/celular) fica salvo no aparelho. Antes, ao abrir o app no modo TV ele aparecia por um instante na posição vertical e depois girava; agora a tela só é desenhada depois que a orientação certa está ativa (com uma proteção que mostra a tela mesmo assim se o sistema não girar).
- **Dados móveis:** a rede passou a tentar os endereços **IPv4 primeiro** (o IPv6 vira reserva) e o tempo de conexão subiu de 12 s para 20 s. Em 4G/5G muitas operadoras entregam IPv6 e, se o servidor ou o painel não atende IPv6 direito, a conexão falhava só nos dados móveis. Se ainda falhar, a mensagem de erro do login agora mostra o servidor e o motivo técnico.
- **Celular:** logo NINJA TV maior no topo e banner de destaque grande (capa/backdrop do filme ocupando o banner, com título e botões por cima).
- **Anúncio por aparelho:** o painel agora tem **dois vídeos** (TV horizontal e celular vertical); o login do app usa o vídeo do aparelho escolhido.

### 3.2 Spotify
- Novo item **Spotify** no menu (logo abaixo do YouTube): playlists, álbuns, músicas e artistas, busca e player oficial (embed). Credenciais no painel (**Spotify**: Client ID e Client Secret) — o Secret fica só no servidor; buscas pelo painel com cache de 6 h.
- Limite do Spotify: sem conta, o embed toca **prévias**; música completa exige que a pessoa entre na própria conta **Premium** dentro do player. O app não toca áudio do Spotify por conta própria.
- Disponível enquanto a Web API de busca do Spotify aceitar o app (sujeito às regras do Spotify).

## 4. Observações honestas
- Os botões de categoria são desenhados em código (cartão + ícone vetorial), sem imagens. Não usei personagens/símbolos de anime ou kids (direitos autorais): os emblemas são genéricos (olho, rosto sorridente, bola etc.).
- "Notificações" = aviso enviado pelo painel + alertas de vencimento da assinatura. Não há notificação push no app original.
- Painel: use o **NinjaTV-Painel** (tema padrão "Ninja Dourado"). O app usa o tema ativo do painel; se o painel tiver outro tema ativo, as cores mudam.
- A URL do painel está em `app/src/main/assets/app-config.json` (hoje aponta para `web.harpiabanner.shop`). **Troque pelo domínio do seu painel Ninja TV.**

## 5. Testes
Este ambiente **não tem Android SDK, aparelho, emulador nem acesso ao seu servidor IPTV/painel**. Portanto **NENHUM dos testes funcionais abaixo foi executado**
e eu não os declaro como aprovados. O que foi feito foi apenas **verificação estática**: balanceamento de código, todos os recursos (`R.drawable.*`, `R.layout.*`)
referenciados existem, imagens e XML geradas e conferidas visualmente.

| # | Teste | Situação |
|---|---|---|
| 1 | Login | não executado |
| 2 | Identificação do usuário | não executado |
| 3 | Comunicação com o site | não executado |
| 4 | Comunicação com o servidor | não executado |
| 5 | Carregamento dos conteúdos | não executado |
| 6 | TV ao vivo | não executado |
| 7 | Filmes | não executado |
| 8 | Séries | não executado |
| 9 | Animes | não executado |
| 10 | Kids | não executado |
| 11 | Esportes | não executado |
| 12 | Reprodução de vídeos | não executado |
| 13 | YouTube | não executado |
| 14 | Suporte | não executado |
| 15 | Histórico | não executado |
| 16 | Favoritos | não executado |
| 17 | Busca | não executado |
| 18 | Perfil | não executado |
| 19 | Configurações | não executado |
| 20 | Assinatura e validade | não executado |
| 21 | Notificações | não executado |
| 22 | Navegação por controle remoto | não executado |
| 23 | Barra de progresso do player | não executado |
| 24 | Navegação entre todas as telas | não executado |
| 25 | Pergunta do aparelho + layout vertical/horizontal | não executado |
| 26 | Spotify (busca e player) | não executado |
| 27 | Vídeo de Anúncio separado (TV/celular) | não executado |
| 28 | Layout sem corte nas bordas (celular e TV) | não executado |
| 29 | Modo TV/celular salvo, sem piscar ao reabrir | não executado |
| 30 | Funcionamento em dados móveis (4G/5G) | não executado |

Sugestão: gere o APK (GitHub Actions — `build-apk-ninjatv.yml` — ou Android Studio), instale e percorra esta lista; me envie qualquer erro de compilação ou comportamento estranho.

## 6. APK assinado
Não foi possível gerar o APK aqui (sem Android SDK). Foram entregues: a keystore do Ninja TV (`NinjaTV-assinatura.zip`) e o workflow do GitHub que compila e assina.
