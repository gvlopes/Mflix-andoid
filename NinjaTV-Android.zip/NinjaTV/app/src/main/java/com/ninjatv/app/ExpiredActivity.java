package com.ninjatv.app;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Fim do teste: QR code de pagamento (se configurado no painel) e o ID do dispositivo embaixo. */
public class ExpiredActivity extends BaseActivity {
    private ImageView qr;
    private TextView info;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        UI.background(bg);
        bg.setAlpha(0.35f);
        frame.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER);
        sv.addView(outer, new ScrollView.LayoutParams(-1, -1));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = UI.dp(this, 26);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable cg = new GradientDrawable();
        cg.setColor(0x66000000 | (UI.BG & 0xFFFFFF));
        cg.setCornerRadius(UI.dp(this, 24 * Theme.radius));
        cg.setStroke(UI.dp(this, 1), 0x66FFFFFF);
        card.setBackground(cg);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(UI.fitWidth(this, 440), -2);
        cl.setMargins(UI.dp(this, 16), UI.dp(this, 16), UI.dp(this, 16), UI.dp(this, 16));
        outer.addView(card, cl);

        TextView title = UI.text(this, "Período de teste encerrado", 22, UI.WHITE, true);
        title.setGravity(Gravity.CENTER);
        card.addView(title, UI.lp(-1, -2, 0, this));
        info = UI.text(this, "Para continuar usando o app, renove a anuidade.", 13, UI.MUTED, false);
        info.setGravity(Gravity.CENTER);
        card.addView(info, UI.lp(-1, -2, 8, this));

        qr = new ImageView(this);
        qr.setBackground(UI.round(this, 0xFFFFFFFF, 12));
        qr.setPadding(UI.dp(this, 8), UI.dp(this, 8), UI.dp(this, 8), UI.dp(this, 8));
        qr.setVisibility(android.view.View.GONE);
        card.addView(qr, UI.lp(UI.dp(this, 220), UI.dp(this, 220), 16, this));

        TextView lab = UI.text(this, "ID do dispositivo", 12, UI.MUTED, false);
        lab.setGravity(Gravity.CENTER);
        card.addView(lab, UI.lp(-1, -2, 16, this));
        TextView id = UI.text(this, Panel.friendlyId(), 34, Cfg.primary(), true);
        id.setGravity(Gravity.CENTER);
        id.setLetterSpacing(0.2f);
        card.addView(id, UI.lp(-1, -2, 2, this));
        card.addView(UI.primaryButton(this, "JÁ PAGUEI · VERIFICAR", this::recheck), UI.lp(-1, -2, 18, this));

        frame.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        recheck();
    }

    private void recheck() {
        Repo.async(() -> Panel.license(), new Repo.Result<Panel.License>() {
            @Override public void ok(Panel.License l) {
                if (!l.limited || !l.expired) {
                    startActivity(new Intent(ExpiredActivity.this, SplashActivity.class));
                    finish();
                    return;
                }
                if (!l.qrUrl.isEmpty()) {
                    qr.setVisibility(android.view.View.VISIBLE);
                    UI.image(qr, l.qrUrl, R.drawable.nt_logo);
                    info.setText("Escaneie o QR code para renovar a anuidade. Depois do pagamento, toque em verificar.");
                } else {
                    info.setText("Fale com o suporte e informe o ID abaixo para renovar.");
                }
            }
            @Override public void fail(String e) { info.setText("Sem conexão com o servidor. Tente de novo."); }
        });
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() { finishAffinity(); }
}
