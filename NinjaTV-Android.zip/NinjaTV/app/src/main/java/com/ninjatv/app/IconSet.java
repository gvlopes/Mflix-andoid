package com.ninjatv.app;

import android.graphics.Color;
import android.graphics.Path;
import androidx.core.graphics.PathParser;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/** Catálogo de ícones vetoriais (traços em grade 24x24). Gerado a partir da mesma fonte usada no painel. */
public final class IconSet {
    private IconSet() {}

    public static final class Def {
        public final String id;
        public final Path[] main, accent;
        Def(String id, Path[] main, Path[] accent) { this.id = id; this.main = main; this.accent = accent; }
    }

    private static final Map<String, Def> M = new LinkedHashMap<>();
    private static final Map<String, String> DEFAULTS = new HashMap<>();

    private static Path[] parse(String[] d) {
        Path[] out = new Path[d.length];
        int n = 0;
        for (String s : d) { Path p = PathParser.createPathFromPathData(s); if (p != null) out[n++] = p; }
        return java.util.Arrays.copyOf(out, n);
    }

    private static void add(String id, String[] main, String[] accent) { M.put(id, new Def(id, parse(main), parse(accent))); }

    static {
        add("tv_wave", new String[]{"M5 7.5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2z"}, new String[]{"M8.5 3l3.5 4.5L15.5 3", "M7 14.5h2.5l1.5-3 2 6 1.5-3H17"});
        add("tv_play", new String[]{"M5 7.5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2z"}, new String[]{"M8.5 3l3.5 4.5L15.5 3", "M10.5 11.5l4 2.7-4 2.7z"});
        add("monitor", new String[]{"M4 4h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"}, new String[]{"M8 20h8", "M12 16v4"});
        add("antenna", new String[]{"M12 10.5a1.5 1.5 0 1 0 .01 0z", "M9.8 21l2.2-8.5 2.2 8.5"}, new String[]{"M7.6 7.6a6.2 6.2 0 0 0 0 8.8", "M16.4 7.6a6.2 6.2 0 0 1 0 8.8", "M4.6 4.6a10.4 10.4 0 0 0 0 14.8", "M19.4 4.6a10.4 10.4 0 0 1 0 14.8"});
        add("camera_video", new String[]{"M4 11h11a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1z", "M16 14l5-2.8v7.6L16 16z"}, new String[]{"M4 7a3 3 0 1 0 6 0a3 3 0 1 0-6 0", "M10.5 7.5a2.5 2.5 0 1 0 5 0a2.5 2.5 0 1 0-5 0"});
        add("clapper", new String[]{"M3.5 10.5h17v8.5a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1z"}, new String[]{"M3 7.6l16.6-3.7.8 3.4L3.8 11z", "M7.6 6.7l1.5 3.2", "M12.2 5.7l1.5 3.2", "M16.6 4.8l1.5 3.2"});
        add("film_strip", new String[]{"M4 4h16a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"}, new String[]{"M7.5 4v16", "M16.5 4v16", "M3 8.5h4.5", "M3 12h4.5", "M3 15.5h4.5", "M16.5 8.5H21", "M16.5 12H21", "M16.5 15.5H21"});
        add("play_square", new String[]{"M5 4.5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2z", "M8 2h8"}, new String[]{"M10 9l5.5 3.5L10 16z"});
        add("play_circle", new String[]{"M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0"}, new String[]{"M10 8.5l5.5 3.5-5.5 3.5z"});
        add("layers", new String[]{"M12 3l9 4.5-9 4.5-9-4.5z"}, new String[]{"M3 12l9 4.5 9-4.5", "M3 16.5L12 21l9-4.5"});
        add("grid", new String[]{"M4 4h6v6H4z", "M14 4h6v6h-6z", "M4 14h6v6H4z"}, new String[]{"M14 14h6v6h-6z"});
        add("star", new String[]{"M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"}, new String[]{"M19.5 2.5v3", "M18 4h3"});
        add("heart", new String[]{"M12 20.5s-8-4.9-8-10.7A4.6 4.6 0 0 1 12 7.2a4.6 4.6 0 0 1 8 2.6c0 5.8-8 10.7-8 10.7z"}, new String[]{"M7.5 10.6a2.7 2.7 0 0 1 2.3-2.2"});
        add("bookmark", new String[]{"M6 3h12v18l-6-4.5L6 21z"}, new String[]{"M9.5 7.5h5"});
        add("clock", new String[]{"M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0"}, new String[]{"M12 7v5l3.2 2"});
        add("history", new String[]{"M3.5 12a8.5 8.5 0 1 0 2.6-6.1"}, new String[]{"M3.5 4.5V9H8", "M12 7.5V12l3 1.8"});
        add("bolt", new String[]{"M13 2.5L4.5 13.5H11l-1 8 8.5-11H12z"}, new String[]{"M18.5 3v3", "M17 4.5h3"});
        add("fire", new String[]{"M12 21c4 0 6.5-2.8 6.5-6.2 0-3.4-2.4-5.2-3.5-8.3-1.8 1.2-2.7 2.7-3.1 4.3C10.8 9 9.9 7.2 9 5.5c-.5 3-3.5 5.4-3.5 9.3C5.5 18.2 8 21 12 21z"}, new String[]{"M12 21c-1.8 0-3-1.2-3-2.9 0-1.6 1.3-2.4 3-4.6 1.7 2.2 3 3 3 4.6 0 1.7-1.2 2.9-3 2.9z"});
        add("crown", new String[]{"M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"}, new String[]{"M7 15.5h10"});
        add("globe", new String[]{"M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0"}, new String[]{"M3 12h18", "M12 3c2.8 2.6 4 5.6 4 9s-1.2 6.4-4 9c-2.8-2.6-4-5.6-4-9s1.2-6.4 4-9z"});
        add("headset", new String[]{"M4.5 14v-2a7.5 7.5 0 0 1 15 0v2", "M3.5 14h3v5h-2a1 1 0 0 1-1-1z", "M20.5 14h-3v5h2a1 1 0 0 0 1-1z"}, new String[]{"M19.5 19c0 1.7-1.6 2.5-4.2 2.5H12.5"});
        add("home", new String[]{"M3 11.5L12 4l9 7.5", "M5.5 10v9.5a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V10"}, new String[]{"M10 20.5v-5h4v5"});
        add("wifi", new String[]{"M12 19.3v.01"}, new String[]{"M2.5 9.5a14 14 0 0 1 19 0", "M5.5 12.8a9.5 9.5 0 0 1 13 0", "M8.6 16a5 5 0 0 1 6.8 0"});
        add("wifi_off", new String[]{"M3.5 3.5l17 17"}, new String[]{"M2.5 9.5a14 14 0 0 1 4-2.7", "M9.2 6c4.4-.7 8.9.9 12.3 3.5", "M8.6 16a5 5 0 0 1 6.8 0", "M12 19.3v.01"});
        add("bell", new String[]{"M6 9a6 6 0 0 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9z"}, new String[]{"M10 20a2 2 0 0 0 4 0"});
        add("music", new String[]{"M9 18V6l10-2v12"}, new String[]{"M3 18a3 3 0 1 0 6 0a3 3 0 1 0-6 0", "M13 16a3 3 0 1 0 6 0a3 3 0 1 0-6 0"});
        add("phone", new String[]{"M7 2.5h10a1.5 1.5 0 0 1 1.5 1.5v16a1.5 1.5 0 0 1-1.5 1.5H7A1.5 1.5 0 0 1 5.5 20V4A1.5 1.5 0 0 1 7 2.5z"}, new String[]{"M10.5 18.5h3"});
        add("eye", new String[]{"M2 12c3-5 7-7 10-7s7 2 10 7c-3 5-7 7-10 7s-7-2-10-7z"}, new String[]{"M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0", "M19 3v3", "M17.5 4.5h3"});
        add("smile", new String[]{"M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0"}, new String[]{"M9 10v.01", "M15 10v.01", "M8 14.5c1.2 1.6 2.6 2.4 4 2.4s2.8-.8 4-2.4"});
        add("ball", new String[]{"M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0"}, new String[]{"M12 8.2l3 2.2-1.1 3.6h-3.8L9 10.4z", "M12 3v5.2", "M15 10.4l5-1.6", "M13.9 14l3 4.2", "M10.1 14l-3 4.2", "M9 10.4L4 8.8"});
        add("gear", new String[]{"M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0"}, new String[]{"M12 2.5v3", "M12 18.5v3", "M2.5 12h3", "M18.5 12h3", "M5.3 5.3l2.1 2.1", "M16.6 16.6l2.1 2.1", "M18.7 5.3l-2.1 2.1", "M7.4 16.6l-2.1 2.1"});
        add("user", new String[]{"M8.5 8a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0-7 0"}, new String[]{"M4.5 20.5c.8-3.6 3.8-5.5 7.5-5.5s6.7 1.9 7.5 5.5"});
        add("search", new String[]{"M4 11a7 7 0 1 0 14 0a7 7 0 1 0-14 0"}, new String[]{"M16.2 16.2L21 21"});
        add("key", new String[]{"M3 15.5a4 4 0 1 0 8 0a4 4 0 1 0-8 0"}, new String[]{"M10.5 12.8L20.5 3.5", "M16.5 7.5l3 3", "M14 10l2 2"});
        add("back", new String[]{"M15 5l-7 7 7 7"}, new String[]{});
        DEFAULTS.put("live", "tv_wave");
        DEFAULTS.put("vod", "camera_video");
        DEFAULTS.put("series", "play_square");
        DEFAULTS.put("youtube", "play_circle");
        DEFAULTS.put("fav", "heart");
        DEFAULTS.put("history", "history");
        DEFAULTS.put("support", "headset");
    }

    public static Def get(String id) { return M.get(id); }

    /** Ícone configurado no painel para a categoria (live, vod, series, youtube, fav, history) ou o padrão. */
    public static String idFor(String kind) {
        String v = Cfg.get("icon_" + kind, "");
        if (M.containsKey(v)) return v;
        String d = DEFAULTS.get(kind);
        return d == null ? "play_circle" : d;
    }

    private static int parse(String hex, int def) {
        try { return Color.parseColor(hex); } catch (Exception e) { return def; }
    }

    /** Cor principal dos ícones: personalizada no painel ou a do tema. */
    public static int mainColor() { String v = Cfg.get("icon_color", ""); return v.isEmpty() ? Theme.icon : parse(v, Theme.icon); }

    /** Cor de destaque dos ícones: personalizada no painel ou a do tema. */
    public static int accentColor() { String v = Cfg.get("icon_accent", ""); return v.isEmpty() ? Theme.iconAccent : parse(v, Theme.iconAccent); }
}
