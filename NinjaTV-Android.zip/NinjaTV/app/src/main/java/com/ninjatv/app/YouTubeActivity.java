package com.ninjatv.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.inputmethod.EditorInfo;
import android.util.DisplayMetrics;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * YouTube com a aparência do YouTube (celular: 1 coluna; TV: grade com foco).
 * Os vídeos vêm da API configurada no painel (a chave fica no servidor).
 */
public class YouTubeActivity extends BaseActivity {
    private static final int YT_BG = 0xFF0F0F0F, YT_CHIP = 0xFF272727, YT_RED = 0xFFFF0000;
    private static final int[] AVATARS = {0xFF8E24AA, 0xFF1E88E5, 0xFF00897B, 0xFFF4511E, 0xFF6D4C41, 0xFF3949AB, 0xFFD81B60};
    // 0 = Tudo (em alta), 1..6 = buscas prontas, 7 = Favoritos, 8 = Histórico
    private static final String[] LABELS = {"Tudo", "Música", "Jogos", "Filmes", "Notícias", "Esportes", "Ao vivo", "Favoritos", "Histórico"};

    private final List<Item> data = new ArrayList<>();
    private Feed adapter;
    private EditText search;
    private TextView status;
    private LinearLayout chips;
    private String mode = "home", term = "";
    private int selChip = 0;
    private long reqId = 0;

    private int dp(float v) { return UI.dp(this, v); }

    private GradientDrawable shape(int color, int radiusDp, int strokeDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private StateListDrawable focusable(GradientDrawable normal, GradientDrawable focused) {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, focused);
        sl.addState(new int[]{}, normal);
        return sl;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(YT_BG);

        // ----- barra superior: voltar, logo e pesquisa -----
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), dp(8), dp(12), dp(4));

        TextView back = UI.text(this, "←", 22, Color.WHITE, true);
        back.setPadding(dp(8), dp(4), dp(12), dp(4));
        back.setFocusable(true);
        back.setClickable(true);
        back.setOnClickListener(v -> finish());
        head.addView(back);

        TextView play = UI.text(this, "▶", 11, Color.WHITE, true);
        play.setGravity(Gravity.CENTER);
        play.setPadding(dp(7), dp(3), dp(7), dp(3));
        play.setBackground(shape(YT_RED, 6, 0, 0));
        head.addView(play);
        TextView name = UI.text(this, "YouTube", 18, Color.WHITE, true);
        name.setLetterSpacing(-0.03f);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-2, -2);
        nlp.leftMargin = dp(5);
        head.addView(name, nlp);

        search = new EditText(this);
        search.setHint("Pesquisar");
        search.setHintTextColor(0xFFAAAAAA);
        search.setTextColor(Color.WHITE);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setPadding(dp(16), 0, dp(16), 0);
        search.setBackground(focusable(shape(YT_CHIP, 20, 0, 0), shape(YT_CHIP, 20, 2, 0xFF3EA6FF)));
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                doSearch();
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        slp.leftMargin = dp(12);
        head.addView(search, slp);

        ImageView go = new ImageView(this);
        go.setImageResource(android.R.drawable.ic_menu_search);
        go.setColorFilter(Color.WHITE);
        go.setPadding(dp(8), dp(8), dp(8), dp(8));
        go.setFocusable(true);
        go.setClickable(true);
        go.setOnClickListener(v -> doSearch());
        head.addView(go, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // ----- chips de categorias -----
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chips = new LinearLayout(this);
        chips.setPadding(dp(12), dp(6), dp(4), dp(6));
        for (int i = 0; i < LABELS.length; i++) chips.addView(chip(i));
        hs.addView(chips);
        root.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        styleChips();

        status = UI.text(this, "", 13, 0xFFAAAAAA, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        // ----- feed: celular = 1 coluna; TV = grade -----
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int span = UI.phone() ? 1 : Math.max(2, (int) (dm.widthPixels / dm.density) / 290);
        RecyclerView grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, span));
        grid.setClipToPadding(false);
        grid.setPadding(UI.phone() ? 0 : dp(8), dp(4), UI.phone() ? 0 : dp(8), dp(24));
        adapter = new Feed();
        grid.setAdapter(adapter);
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        load();
    }

    private TextView chip(final int idx) {
        TextView t = UI.text(this, LABELS[idx], 14, Color.WHITE, true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnClickListener(v -> select(idx));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void styleChips() {
        for (int i = 0; i < chips.getChildCount(); i++) {
            TextView t = (TextView) chips.getChildAt(i);
            boolean on = i == selChip;
            t.setTextColor(on ? Color.BLACK : Color.WHITE);
            t.setBackground(focusable(shape(on ? Color.WHITE : YT_CHIP, 16, 0, 0), shape(on ? Color.WHITE : YT_CHIP, 16, 3, YT_RED)));
        }
    }

    private void select(int idx) {
        selChip = idx;
        styleChips();
        if (idx == 0) { mode = "home"; term = ""; search.setText(""); }
        else if (idx <= 6) { mode = "search"; term = LABELS[idx].toLowerCase(); search.setText(LABELS[idx]); }
        else mode = idx == 7 ? "fav" : "history";
        load();
    }

    private void doSearch() {
        String q = search.getText().toString().trim();
        if (q.length() < 2) { UI.toast(this, "Digite pelo menos 2 letras."); return; }
        mode = "search";
        term = q;
        selChip = -1;
        styleChips();
        load();
    }

    private void load() {
        final long id = ++reqId;
        if ("fav".equals(mode) || "history".equals(mode)) {
            List<Item> src = "fav".equals(mode) ? Store.get(this).favorites(Repo.session(), "yt") : new ArrayList<Item>();
            if ("history".equals(mode)) for (Item i : Store.get(this).history(Repo.session(), false)) if ("yt".equals(i.kind)) src.add(i);
            show(src);
            status.setText(src.isEmpty() ? T.t("Nenhum resultado.") : "");
            return;
        }
        final String q = "search".equals(mode) ? term : "";
        status.setText(T.t("Carregando..."));
        show(new ArrayList<Item>());
        Repo.async(() -> YouTube.search(q), new Repo.Result<List<Item>>() {
            @Override public void ok(List<Item> v) {
                if (id != reqId) return;
                show(v);
                status.setText(v.isEmpty() ? T.t("Nenhum resultado.") : "");
            }
            @Override public void fail(String e) { if (id == reqId) status.setText(e); }
        });
    }

    private void show(List<Item> v) {
        data.clear();
        data.addAll(v);
        adapter.notifyDataSetChanged();
    }

    private void play(Item it) {
        Store.get(this).progress(Repo.session(), it, 0, 0);       // entra no histórico
        Intent i = new Intent(this, YouTubePlayerActivity.class);
        i.putExtra("id", it.id);
        i.putExtra("title", it.name);
        startActivity(i);
    }

    private void toggleFav(Item it) {
        boolean on = Store.get(this).toggleFavorite(Repo.session(), it);
        UI.toast(this, on ? "Adicionado aos favoritos" : "Removido dos favoritos");
        if ("fav".equals(mode)) load();
    }

    /** Miniatura sempre 16:9. */
    private static class Thumb extends ImageView {
        Thumb(Context c) { super(c); }
        @Override protected void onMeasure(int w, int h) {
            int width = MeasureSpec.getSize(w);
            setMeasuredDimension(width, width * 9 / 16);
        }
    }

    private class Feed extends RecyclerView.Adapter<Feed.VH> {
        class VH extends RecyclerView.ViewHolder {
            final View card;
            final Thumb thumb;
            final TextView avatar, title, channel;
            VH(View c, Thumb t, TextView a, TextView ti, TextView ch) { super(c); card = c; thumb = t; avatar = a; title = ti; channel = ch; }
        }

        @Override public VH onCreateViewHolder(ViewGroup p, int type) {
            final boolean phone = UI.phone();
            LinearLayout card = new LinearLayout(p.getContext());
            card.setOrientation(LinearLayout.VERTICAL);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(-1, -2);
            lp.setMargins(phone ? 0 : dp(8), 0, phone ? 0 : dp(8), dp(phone ? 18 : 12));
            card.setLayoutParams(lp);
            card.setFocusable(true);
            card.setClickable(true);
            if (!phone) card.setBackground(focusable(shape(0x00000000, 14, 0, 0), shape(0x22FFFFFF, 14, 3, Color.WHITE)));
            if (!phone) card.setPadding(dp(4), dp(4), dp(4), dp(4));

            Thumb th = new Thumb(p.getContext());
            th.setScaleType(ImageView.ScaleType.CENTER_CROP);
            th.setBackgroundColor(0xFF1F1F1F);
            if (!phone) {
                th.setOutlineProvider(new ViewOutlineProvider() {
                    @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(12)); }
                });
                th.setClipToOutline(true);
            }
            card.addView(th, new LinearLayout.LayoutParams(-1, -2));

            LinearLayout row = new LinearLayout(p.getContext());
            row.setPadding(phone ? dp(12) : dp(4), dp(10), phone ? dp(4) : dp(4), 0);
            TextView av = UI.text(p.getContext(), "", 15, Color.WHITE, true);
            av.setGravity(Gravity.CENTER);
            row.addView(av, new LinearLayout.LayoutParams(dp(36), dp(36)));

            LinearLayout col = new LinearLayout(p.getContext());
            col.setOrientation(LinearLayout.VERTICAL);
            TextView ti = UI.text(p.getContext(), "", phone ? 14 : 15, Color.WHITE, false);
            ti.setMaxLines(2);
            ti.setEllipsize(TextUtils.TruncateAt.END);
            TextView ch = UI.text(p.getContext(), "", 12, 0xFFAAAAAA, false);
            ch.setSingleLine(true);
            ch.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(ti);
            col.addView(ch);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
            clp.leftMargin = dp(12);
            row.addView(col, clp);

            final VH h = new VH(card, th, av, ti, ch);
            if (phone) {
                TextView more = UI.text(p.getContext(), "⋮", 22, Color.WHITE, true);
                more.setPadding(dp(10), 0, dp(10), 0);
                more.setOnClickListener(v -> { int pos = h.getAdapterPosition(); if (pos >= 0) toggleFav(data.get(pos)); });
                row.addView(more);
            }
            card.addView(row, new LinearLayout.LayoutParams(-1, -2));
            card.setOnClickListener(v -> { int pos = h.getAdapterPosition(); if (pos >= 0) play(data.get(pos)); });
            card.setOnLongClickListener(v -> { int pos = h.getAdapterPosition(); if (pos >= 0) toggleFav(data.get(pos)); return true; });
            return h;
        }

        @Override public void onBindViewHolder(VH h, int pos) {
            Item it = data.get(pos);
            UI.image(h.thumb, it.cover, android.R.color.transparent);
            h.title.setText(it.name);
            String ch = it.plot == null ? "" : it.plot.trim();
            h.channel.setText(ch);
            h.avatar.setText(ch.isEmpty() ? "?" : String.valueOf(Character.toUpperCase(ch.charAt(0))));
            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            circle.setColor(AVATARS[Math.abs(ch.hashCode()) % AVATARS.length]);
            h.avatar.setBackground(circle);
        }

        @Override public int getItemCount() { return data.size(); }
    }
}
