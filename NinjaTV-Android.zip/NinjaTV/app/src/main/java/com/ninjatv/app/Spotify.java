package com.ninjatv.app;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Spotify: a busca é feita pelo painel (Client ID/Secret ficam no servidor, com cache). */
public final class Spotify {
    private Spotify() {}

    public static boolean enabled() { return !"0".equals(Cfg.get("spotify_enabled", "1")); }

    /** type: playlist | album | track | artist. query vazia = busca inicial definida no painel. */
    public static List<Item> search(String query, String type) throws Exception {
        JSONObject j = Panel.spotify(query == null ? "" : query.trim(), type);
        JSONObject d = j.optJSONObject("data");
        JSONArray a = d == null ? null : d.optJSONArray("items");
        List<Item> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            String t = o.optString("type", type);
            if (!id.matches("^[A-Za-z0-9]{22}$") || !t.matches("^(playlist|album|track|artist)$")) continue;
            Item it = new Item();
            it.kind = "sp";
            it.id = id;
            it.ext = t;
            it.name = o.optString("title", "");
            it.plot = o.optString("subtitle", "");
            it.cover = o.optString("thumb", "");
            out.add(it);
        }
        return out;
    }
}
