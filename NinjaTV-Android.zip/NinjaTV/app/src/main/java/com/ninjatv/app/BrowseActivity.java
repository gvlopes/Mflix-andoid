package com.ninjatv.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Listas: canais, filmes, séries, animes, kids, esportes, favoritos, histórico e busca. */
public class BrowseActivity extends BaseActivity {
    // Animes, Kids e Esportes são grupos: reúnem as categorias do servidor cujo nome combina com o tema
    private static final Pattern P_ANIME = Pattern.compile(".*\\banim[eê]s?\\b.*", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_KIDS = Pattern.compile(".*(kids|infantil|infantis|crian[cç]as?|children|desenhos?|cartoon|disney|nickelodeon|discovery kids|gloob|junior|baby).*", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_SPORTS = Pattern.compile(".*(esporte|esportes|sport|sports|futebol|football|soccer|premiere|sportv|espn|combate|ufc|nba|nfl|f[óo]rmula|libertadores|brasileir[aã]o|champions|copa|luta|basquete|t[eê]nis|bein|dazn|eleven).*", Pattern.CASE_INSENSITIVE);

    private String kind;
    private boolean allHistory = true;
    private RecyclerView grid, catList;
    private ItemAdapter adapter;
    private TextView count, empty, tabAll, tabProgress;
    private EditText search;
    private final List<String[]> rows = new ArrayList<>();   // {tipo, categoria, rótulo}; tipo null = todas do grupo
    private int rowIndex = 0;
    private List<Item> current = new ArrayList<>();

    private boolean isGroup() { return kind.equals("anime") || kind.equals("kids") || kind.equals("sports"); }
    private boolean hasCats() { return kind.equals("live") || kind.equals("vod") || kind.equals("series") || isGroup(); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        kind = getIntent().getStringExtra("kind");
        if (kind == null) kind = "vod";
        boolean cats = hasCats();

        final boolean ph = UI.phone();
        LinearLayout root = new LinearLayout(this);
        root.setBackgroundColor(UI.BG);
        root.setOrientation(ph ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);

        if (cats) {
            catList = new RecyclerView(this);
            catList.setLayoutManager(ph ? new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false) : new LinearLayoutManager(this));
            catList.setBackgroundColor(ph ? 0x00000000 : UI.SURFACE);
            catList.setPadding(UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6));
            if (!ph) root.addView(catList, new LinearLayout.LayoutParams(UI.dp(this, 230), -1));
        }

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 12);
        right.setPadding(p, p, p, 0);
        root.addView(right, ph ? new LinearLayout.LayoutParams(-1, 0, 1) : new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(UI.backButton(this));
        TextView title = UI.text(this, titleFor(kind), 18, UI.WHITE, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1);
        tlp.leftMargin = UI.dp(this, 12);
        top.addView(title, tlp);
        count = UI.text(this, "", 12, UI.MUTED, false);
        top.addView(count);
        right.addView(top, new LinearLayout.LayoutParams(-1, -2));
        if (cats && ph) right.addView(catList, UI.lp(-1, UI.dp(this, 58), 6, this));

        if (kind.equals("history")) {
            LinearLayout tabs = new LinearLayout(this);
            tabAll = UI.button(this, "Tudo", () -> { allHistory = true; refresh(); });
            tabProgress = UI.button(this, "Em andamento", () -> { allHistory = false; refresh(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = UI.dp(this, 8);
            tabs.addView(tabAll, lp);
            tabs.addView(tabProgress);
            right.addView(tabs, UI.lp(-2, -2, 8, this));
        }

        search = UI.input(this, T.t("Buscar canais, filmes e séries"), false);
        right.addView(search, UI.lp(-1, -2, 8, this));

        empty = UI.text(this, T.t("Nenhum resultado."), 14, UI.MUTED, false);
        empty.setGravity(Gravity.CENTER);
        empty.setVisibility(View.GONE);
        right.addView(empty, UI.lp(-1, -2, 20, this));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int panelPx = cats && !ph ? UI.dp(this, 230) : 0;
        int cardDp = kind.equals("live") ? 150 : 130;
        int cell = UI.dp(this, cardDp + 12);
        int span = Math.max(2, (dm.widthPixels - panelPx - UI.dp(this, 24)) / cell);
        grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, span));
        grid.setClipToPadding(false);
        adapter = new ItemAdapter(cardDp, (it, pos) -> openItem(it), (it, pos) -> toggleFav(it));
        grid.setAdapter(adapter);
        right.addView(grid, UI.lp(-1, 0, 8, this));
        ((LinearLayout.LayoutParams) grid.getLayoutParams()).weight = 1;

        setContentView(root);

        if (cats) {
            buildRows();
            catList.setAdapter(new CatAdapter());
        }
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void afterTextChanged(Editable s) { refresh(); }
        });
        if (kind.equals("search")) search.requestFocus();
        refresh();
    }

    private String titleFor(String k) {
        switch (k) {
            case "live": return T.t("Ao Vivo");
            case "vod": return T.t("Filmes");
            case "series": return T.t("Séries");
            case "anime": return "Animes";
            case "kids": return "Kids";
            case "sports": return "Esportes";
            case "fav": return T.t("Favoritos");
            case "history": return "Histórico";
            default: return T.t("Busca");
        }
    }

    private static String kindLabel(String k) { return "live".equals(k) ? "Canais" : "vod".equals(k) ? "Filmes" : "Séries"; }

    /** Linhas da lista de categorias. Em grupos, só entram categorias do servidor que combinam com o tema. */
    private void buildRows() {
        rows.clear();
        if (!isGroup()) {
            rows.add(new String[]{kind, null, "Todos"});
            for (Cat c : Repo.cats(kind)) rows.add(new String[]{kind, c.id, c.name});
            return;
        }
        Pattern pat = kind.equals("anime") ? P_ANIME : kind.equals("kids") ? P_KIDS : P_SPORTS;
        for (String k : new String[]{"live", "vod", "series"})
            for (Cat c : Repo.cats(k))
                if (pat.matcher(c.name).matches()) rows.add(new String[]{k, c.id, kindLabel(k) + " · " + c.name});
        if (!rows.isEmpty()) rows.add(0, new String[]{null, null, "Todos"});
    }

    private List<Item> itemsOfRows() {
        List<Item> out = new ArrayList<>();
        if (rows.isEmpty()) return out;
        String[] r = rows.get(Math.min(rowIndex, rows.size() - 1));
        if (r[0] != null) { out.addAll(Repo.items(r[0], r[1])); return out; }
        for (int i = 1; i < rows.size(); i++) out.addAll(Repo.items(rows.get(i)[0], rows.get(i)[1]));
        return out;
    }

    private void refresh() {
        String q = search.getText().toString().trim().toLowerCase();
        List<Item> src;
        String emptyMsg = T.t("Nenhum resultado.");
        switch (kind) {
            case "fav": src = withoutYoutube(Store.get(this).favorites(Repo.session(), null)); break;
            case "history":
                src = withoutYoutube(Store.get(this).history(Repo.session(), !allHistory));
                if (tabAll != null) { tabAll.setAlpha(allHistory ? 1f : 0.55f); tabProgress.setAlpha(allHistory ? 0.55f : 1f); }
                break;
            case "search": src = q.length() < 2 ? new ArrayList<Item>() : Repo.search(q); break;
            default:
                src = itemsOfRows();
                if (isGroup() && rows.isEmpty()) emptyMsg = "O seu servidor não tem categorias de " + titleFor(kind) + " (procuramos pelo nome da categoria).";
        }
        if (!kind.equals("search") && !q.isEmpty()) {
            List<Item> f = new ArrayList<>();
            for (Item i : src) if (i.name.toLowerCase().contains(q)) f.add(i);
            src = f;
        }
        current = src;
        adapter.set(src);
        count.setText(src.size() + "");
        empty.setText(emptyMsg);
        empty.setVisibility(src.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private static List<Item> withoutYoutube(List<Item> in) {
        List<Item> out = new ArrayList<>();
        for (Item i : in) if (!"yt".equals(i.kind)) out.add(i);
        return out;
    }

    private void toggleFav(Item it) {
        if ("episode".equals(it.kind)) return;
        boolean on = Store.get(this).toggleFavorite(Repo.session(), it);
        UI.toast(this, on ? "Adicionado aos favoritos" : "Removido dos favoritos");
        if (kind.equals("fav")) refresh();
    }

    private void openItem(final Item it) {
        if (Rules.adult(it.name) && Repo.hasPin() && !Repo.adultUnlocked) {
            UI.askPin(this, () -> doOpen(it));
            return;
        }
        doOpen(it);
    }

    private void doOpen(Item it) {
        if ("live".equals(it.kind)) {
            // troca de canal com cima/baixo entre os canais da lista atual
            List<Item> live = new ArrayList<>();
            for (Item i : current) if ("live".equals(i.kind)) live.add(i);
            Repo.playlist = live;
            Repo.playlistIndex = Math.max(0, live.indexOf(it));
            startActivity(new Intent(this, PlayerActivity.class));
        } else if ("episode".equals(it.kind)) {
            ArrayList<Item> one = new ArrayList<>();
            one.add(it);
            Repo.playlist = one; Repo.playlistIndex = 0;
            startActivity(new Intent(this, PlayerActivity.class));
        } else {
            Repo.selected = it;
            startActivity(new Intent(this, DetailsActivity.class));
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (kind.equals("fav") || kind.equals("history")) refresh();
    }

    // -------------------------------------------------- categorias
    private class CatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @NonNull @Override public RecyclerView.ViewHolder onCreateViewHolder(@NonNull android.view.ViewGroup p, int t) {
            TextView v = UI.text(p.getContext(), "", 14, UI.WHITE, false);
            int pad = UI.dp(p.getContext(), 12);
            v.setPadding(pad, pad, pad, pad);
            v.setFocusable(true); v.setClickable(true);
            v.setMaxLines(2);
            RecyclerView.LayoutParams rlp = new RecyclerView.LayoutParams(UI.phone() ? -2 : -1, -2);
            if (UI.phone()) rlp.rightMargin = UI.dp(p.getContext(), 6);
            v.setLayoutParams(rlp);
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder h, int pos) {
            TextView v = (TextView) h.itemView;
            v.setText(rows.get(pos)[2]);
            boolean sel = rowIndex == pos;
            v.setBackground(sel ? UI.round(v.getContext(), (0x33 << 24) | (Cfg.primary() & 0x00FFFFFF), 10) : UI.focusBg(v.getContext(), UI.SURFACE, 10));
            v.setTextColor(sel ? Cfg.primary() : UI.WHITE);
            v.setOnClickListener(x -> {
                final int p = h.getBindingAdapterPosition();
                if (p < 0) return;
                if (Rules.adult(rows.get(p)[2]) && Repo.hasPin() && !Repo.adultUnlocked) {
                    UI.askPin(BrowseActivity.this, () -> selectRow(p));
                } else selectRow(p);
            });
        }

        @Override public int getItemCount() { return rows.size(); }
    }

    private void selectRow(int index) {
        int old = rowIndex;
        rowIndex = index;
        catList.getAdapter().notifyItemChanged(old);
        catList.getAdapter().notifyItemChanged(index);
        refresh();
    }
}
