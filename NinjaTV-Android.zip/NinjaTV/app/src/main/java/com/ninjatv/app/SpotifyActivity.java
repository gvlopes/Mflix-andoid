package com.ninjatv.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/** Spotify: playlists, álbuns, músicas e artistas (busca pelo painel) e player oficial embutido. */
public class SpotifyActivity extends BaseActivity {
    private ItemAdapter adapter;
    private EditText search;
    private TextView status;
    private String type = "playlist";
    private long reqId = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        int p = UI.dp(this, 14);
        root.setPadding(p, p, p, 0);
        root.addView(UI.topBar(this, "Spotify"), new LinearLayout.LayoutParams(-1, -2));

        search = UI.input(this, "Buscar no Spotify", false);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                load();
                return true;
            }
            return false;
        });
        root.addView(search, UI.lp(-1, -2, 8, this));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tabs = new LinearLayout(this);
        hs.addView(tabs);
        tabs.addView(tab("Playlists", "playlist"));
        tabs.addView(tab("Álbuns", "album"));
        tabs.addView(tab("Músicas", "track"));
        tabs.addView(tab("Artistas", "artist"));
        root.addView(hs, UI.lp(-1, -2, 8, this));

        status = UI.text(this, "", 13, UI.MUTED, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, UI.lp(-1, -2, 8, this));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int cardDp = 150;
        int span = Math.max(2, (dm.widthPixels - UI.dp(this, 28)) / UI.dp(this, cardDp + 12));
        RecyclerView grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, span));
        adapter = new ItemAdapter(cardDp, (it, pos) -> play(it), null);
        grid.setAdapter(adapter);
        root.addView(grid, UI.lp(-1, 0, 8, this));
        ((LinearLayout.LayoutParams) grid.getLayoutParams()).weight = 1;
        setContentView(root);
        load();
    }

    private View tab(String label, final String t) {
        TextView v = UI.button(this, label, () -> { type = t; load(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = UI.dp(this, 8);
        v.setLayoutParams(lp);
        return v;
    }

    private void load() {
        final long id = ++reqId;
        final String q = search.getText().toString().trim();
        final String t = type;
        status.setText(T.t("Carregando..."));
        adapter.set(new ArrayList<Item>());
        Repo.async(() -> Spotify.search(q, t), new Repo.Result<List<Item>>() {
            @Override public void ok(List<Item> v) {
                if (id != reqId) return;
                adapter.set(v);
                status.setText(v.isEmpty() ? T.t("Nenhum resultado.") : "");
            }
            @Override public void fail(String e) { if (id == reqId) status.setText(e); }
        });
    }

    private void play(Item it) {
        Intent i = new Intent(this, SpotifyPlayerActivity.class);
        i.putExtra("type", it.ext);
        i.putExtra("id", it.id);
        i.putExtra("title", it.name);
        startActivity(i);
    }
}
