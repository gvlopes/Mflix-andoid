package com.ninjatv.app;

import android.graphics.Color;
import org.json.JSONObject;

/** Tema visual do app (vem do painel: api/theme.php) — cores, cantos, fonte, partículas e fundo. */
public final class Theme {
    private Theme() {}
    public static int primary = 0xFFFFB020, secondary = 0xFFFF6A00, background = 0xFF050505, surface = 0xFF111111,
            surface2 = 0xFF1C1C1C, text = 0xFFFFFFFF, muted = 0xFFB8B0A5, focus = 0xFFFFC857, bgTint = 0xFFFFB020,
            icon = 0xFFFFFFFF, iconAccent = 0xFFFFB020;
    public static float radius = 1f, carouselScale = 0.26f, particleSpeed = 1f;
    public static int particleCount = 45, particleColor = 0;
    public static String particleStyle = "embers", button = "gradient", font = "default", bgUrl = "", logoUrl = "", slug = "", rev = "";
    public static boolean bgImage = true;

    /** Lê o tema salvo (ou o padrão vermelho) e atualiza as cores globais da UI. */
    public static void load() {
        JSONObject j;
        try { j = new JSONObject(Prefs.get("theme_json", "{}")); } catch (Exception e) { j = new JSONObject(); }
        JSONObject c = obj(j, "colors"), st = obj(j, "style"), p = obj(j, "particles"), im = obj(j, "images");
        primary = col(c, "primary", 0xFFFFB020);
        secondary = col(c, "secondary", 0xFFFF6A00);
        background = col(c, "background", 0xFF050505);
        surface = col(c, "surface", 0xFF111111);
        surface2 = col(c, "surface2", 0xFF1C1C1C);
        text = col(c, "text", 0xFFFFFFFF);
        muted = col(c, "muted", 0xFFB8B0A5);
        focus = col(c, "focus", 0xFFFFC857);
        bgTint = col(c, "bg_tint", primary);
        icon = col(c, "icon", 0xFFFFFFFF);
        iconAccent = col(c, "icon_accent", primary);
        radius = (float) clamp(st.optDouble("radius", 1.0), 0, 2);
        carouselScale = (float) clamp(st.optDouble("carousel_scale", 0.26), 0, 0.5);
        button = st.optString("button", "gradient");
        font = st.optString("font", "default");
        bgImage = st.optBoolean("bg_image", true);
        particleStyle = p.optString("style", "embers");
        particleCount = (int) clamp(p.optInt("count", 45), 0, 120);
        particleSpeed = (float) clamp(p.optDouble("speed", 1.0), 0.2, 3);
        particleColor = col(p, "color", 0);
        bgUrl = im.optString("background", "");
        logoUrl = im.optString("logo", "");
        slug = j.optString("slug", "");
        rev = j.optString("rev", "");
        UI.BG = background; UI.SURFACE = surface; UI.SURFACE2 = surface2; UI.WHITE = text; UI.MUTED = muted;
    }

    /** Guarda o tema recebido do painel e aplica. */
    public static void save(JSONObject theme) {
        Prefs.put("theme_json", theme.toString());
        load();
    }

    private static JSONObject obj(JSONObject j, String k) { JSONObject o = j.optJSONObject(k); return o == null ? new JSONObject() : o; }
    private static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }
    private static int col(JSONObject o, String k, int def) {
        try { return Color.parseColor(o.optString(k, "")); } catch (Exception e) { return def; }
    }
}
