package com.ninjatv.app;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Base de todas as telas: tela 100% cheia (sem barra de status/navegação) e respeito ao recorte da câmera. */
public class BaseActivity extends AppCompatActivity {
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private View pending;
    private final Runnable applyPending = () -> {
        if (pending != null) { View v = pending; pending = null; apply(v); }
    };

    /** Telas de vídeo desligam o recuo do recorte para usar a tela inteira. */
    protected boolean padForCutout() { return true; }

    /** false nas telas de vídeo/web, que não são refeitas ao girar (usam configChanges). */
    protected boolean recreatesOnRotate() { return true; }

    /** Celular = vertical; TV/TV Box = horizontal; antes da escolha, segue o sensor. Telas de vídeo sobrescrevem. */
    protected int orientation() {
        String m = Prefs.get("device_mode", "");
        if ("phone".equals(m)) return ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
        if ("tv".equals(m)) return ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        return ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    }

    /** O app nasce na posição atual do aparelho; se ela difere da escolhida (TV = horizontal), o sistema vai girar e refazer a tela. */
    private boolean orientationMismatch() {
        int req = orientation(), cur = getResources().getConfiguration().orientation;
        if (req == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE) return cur != Configuration.ORIENTATION_LANDSCAPE;
        if (req == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) return cur != Configuration.ORIENTATION_PORTRAIT;
        return false;
    }

    @Override protected void onCreate(Bundle b) {
        setRequestedOrientation(orientation());
        super.onCreate(b);
        UI.fullscreen(this);
    }

    @Override public void setContentView(View v) {
        if (recreatesOnRotate() && orientationMismatch()) {
            // Não desenha nada agora (evita o "pisca" no modo errado): a tela será recriada já na orientação certa.
            // Se por algum motivo o sistema não girar (ex.: janela fixa), mostra mesmo assim após um instante.
            pending = v;
            UI.fullscreen(this);
            uiHandler.postDelayed(applyPending, 900);
            return;
        }
        apply(v);
    }

    private void apply(View v) {
        super.setContentView(v);
        UI.fullscreen(this);
        if (padForCutout()) {
            View content = findViewById(android.R.id.content);
            ViewCompat.setOnApplyWindowInsetsListener(content, (view, insets) -> {
                // só o recorte (notch) e o teclado: as barras do sistema ficam escondidas
                Insets i = insets.getInsets(WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
                int sh = UI.dp(BaseActivity.this, UI.phone() ? 8 : 14), sv = UI.dp(BaseActivity.this, UI.phone() ? 8 : 10);
                view.setPadding(Math.max(i.left, sh), Math.max(i.top, sv), Math.max(i.right, sh), Math.max(i.bottom, sv));
                return insets;
            });
            ViewCompat.requestApplyInsets(content);
        }
    }

    @Override protected void onResume() { super.onResume(); UI.fullscreen(this); }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) UI.fullscreen(this);
    }

    @Override protected void onDestroy() {
        uiHandler.removeCallbacks(applyPending);
        super.onDestroy();
    }
}
