package com.ninjatv.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Abre o site oficial do YouTube / Spotify dentro do app (interface original, sem chaves de API). */
public class WebAppActivity extends BaseActivity {
    private static final String UA_TV = "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Version/6.0 TV Safari/537.36";
    private static final String UA_DESKTOP = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private WebView web;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    public static void open(Context c, String kind) {
        c.startActivity(new Intent(c, WebAppActivity.class).putExtra("kind", kind));
    }

    @Override protected boolean padForCutout() { return false; }
    @Override protected boolean recreatesOnRotate() { return false; }
    @Override protected int orientation() {
        return UI.phone() ? ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String kind = getIntent().getStringExtra("kind");
        boolean spotify = "spotify".equals(kind);
        String url, ua;
        WebView probe = new WebView(this);
        String def = probe.getSettings().getUserAgentString();
        probe.destroy();
        if (spotify) { url = "https://open.spotify.com"; ua = UA_DESKTOP; }
        else if (UI.phone()) { url = "https://m.youtube.com"; ua = def.replace("; wv", "").replaceAll("Version/\\S+ ", ""); }
        else { url = "https://www.youtube.com/tv"; ua = UA_TV; }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(ua);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportMultipleWindows(false);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sch = r.getUrl().getScheme();
                return sch == null || !(sch.equals("http") || sch.equals("https"));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v; customCb = cb;
                web.setVisibility(View.GONE);
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                UI.fullscreen(WebAppActivity.this);
            }
            @Override public void onHideCustomView() { hideCustom(); }
            @Override public void onPermissionRequest(final PermissionRequest r) {
                // Vídeo/áudio protegido (DRM) usado pelo Spotify e pelo YouTube
                runOnUiThread(() -> {
                    java.util.ArrayList<String> ok = new java.util.ArrayList<>();
                    for (String res : r.getResources()) if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(res)) ok.add(res);
                    if (ok.isEmpty()) r.deny(); else r.grant(ok.toArray(new String[0]));
                });
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        if (UI.phone()) {
            // celular: botão de fechar (na TV usa-se o voltar do controle)
            TextView x = UI.text(this, "✕", 16, Color.WHITE, true);
            x.setGravity(Gravity.CENTER);
            x.setBackground(UI.round(this, 0xAA000000, 20));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(UI.dp(this, 40), UI.dp(this, 40), Gravity.BOTTOM | Gravity.END);
            lp.setMargins(0, 0, UI.dp(this, 14), UI.dp(this, 90));
            x.setOnClickListener(v -> finish());
            root.addView(x, lp);
        }
        setContentView(root);
        web.requestFocus(View.FOCUS_DOWN);
        web.loadUrl(url);
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        UI.fullscreen(this);
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (web != null && web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() {
        if (web != null) { root.removeView(web); web.destroy(); web = null; }
        super.onDestroy();
    }
}
