package com.ninjatv.app;

import android.app.Activity;
import android.content.Intent;

/** Teste de 7 dias / anuidade: se o painel disser que venceu, desloga e abre a tela de pagamento. */
final class LicenseGate {
    private LicenseGate() { }

    static void check(final Activity a) {
        if (!Panel.isConfigured()) return;
        Repo.async(() -> Panel.license(), new Repo.Result<Panel.License>() {
            @Override public void ok(Panel.License l) {
                if (!l.limited || !l.expired || a.isFinishing() || a.isDestroyed()) return;
                String tk = Prefs.get("activation_token", "");   // guarda o vínculo para reentrar sozinho após pagar
                Repo.logout(a);
                if (!tk.isEmpty()) Prefs.put("activation_token", tk);
                Intent i = new Intent(a, ExpiredActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                a.startActivity(i);
                a.finish();
            }
            @Override public void fail(String e) { /* sem rede: não bloqueia */ }
        });
    }
}
