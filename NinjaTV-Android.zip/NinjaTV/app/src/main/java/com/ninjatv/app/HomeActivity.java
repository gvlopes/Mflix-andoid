package com.ninjatv.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.core.widget.TextViewCompat;
import com.bumptech.glide.Glide;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Tela inicial Ninja TV: cabeçalho, menu lateral, destaque, assinatura, relógio/clima e as 6 estrelas ninja. */
public class HomeActivity extends BaseActivity {
    private float k = 1f;                       // escala conforme a altura da tela
    private TextView loading, weatherText, cityText, subTitle, subDetail, bLabel, bTitle, bMeta, bPlot, userValue;
    private View subDot, bellDot;
    private ImageView weatherIcon, bBg, bPoster;
    private IconView wifiIcon;
    private FrameLayout wifiRing;
    private LinearLayout dots;
    private final List<Item> featured = new ArrayList<>();
    private int fIndex = 0;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable rotate = new Runnable() {
        @Override public void run() {
            if (featured.size() > 1) showFeatured((fIndex + 1) % featured.size());
            h.postDelayed(this, 9_000);
        }
    };
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private View firstStar;
    private boolean phone = false, compactBanner = false;

    private int dpk(float v) { return UI.dp(this, v * k); }
    private float spk(float v) { return v * k; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float hDp = dm.heightPixels / dm.density;
        k = UI.phone() ? 0.95f : Math.max(0.72f, Math.min(1.35f, hDp / 480f));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        UI.background(bg);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{UI.alpha(0x88), UI.alpha(0x3A), UI.alpha(0xB4)}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        root.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));

        phone = UI.phone();
        if (phone) buildPhoneContent(root, dm); else buildTvContent(root, dm);

        loading = UI.text(this, T.t("Atualizando conteúdo..."), 15, UI.WHITE, true);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundColor(UI.alpha(0xE6));
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        updateSubscription();
        loadContent(false);
        refreshWeather();
        refreshAccount();
        checkRemote();
        Repo.async(Panel::config, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { }
            @Override public void fail(String e) { }
        });
    }

    // ================================================================== layout TV (horizontal)
    private void buildTvContent(FrameLayout root, DisplayMetrics dm) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = dpk(12);
        content.setPadding(p, p / 2, p, p / 2);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        content.addView(buildHeader(), new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, 0, 1);
        bl.topMargin = dpk(6);
        content.addView(body, bl);

        int sideW = (int) Math.max(UI.dp(this, 112), Math.min(UI.dp(this, 170), dm.widthPixels * 0.15f));
        body.addView(buildSidebar(), new LinearLayout.LayoutParams(sideW, -1));

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, -1, 1);
        ml.leftMargin = dpk(10);
        body.addView(main, ml);
        main.addView(buildBanner(), new LinearLayout.LayoutParams(-1, 0, 38));
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, 0, 13);
        il.topMargin = dpk(8);
        main.addView(buildInfoRow(), il);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, 0, 49);
        sl.topMargin = dpk(2);
        main.addView(buildStars(), sl);

    }

    // ================================================================== layout celular (vertical)
    private void buildPhoneContent(FrameLayout root, DisplayMetrics dm) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 12);
        col.setPadding(p, p, p, p * 2);
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        // cabeçalho: logo + conexão + sino
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView wm = new ImageView(this);
        wm.setImageResource(R.drawable.nt_wordmark);
        wm.setAdjustViewBounds(true);
        wm.setScaleType(ImageView.ScaleType.FIT_START);
        head.addView(wm, new LinearLayout.LayoutParams(0, UI.dp(this, 50), 1));
        addStatusButtons(head);
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // usuário + aviso do painel
        LinearLayout ur = new LinearLayout(this);
        ur.setGravity(Gravity.CENTER_VERTICAL);
        ur.addView(userBlock());
        View div = new View(this);
        div.setBackgroundColor(Theme.primary);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(UI.dp(this, 2), UI.dp(this, 24));
        dl.setMargins(UI.dp(this, 12), 0, UI.dp(this, 12), 0);
        ur.addView(div, dl);
        ur.addView(noticeView(), new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(ur, UI.lp(-1, -2, 4, this));

        // destaque
        int bannerH = (int) Math.max(UI.dp(this, 250), Math.min(UI.dp(this, 380), dm.widthPixels * 1.0f));
        col.addView(buildBanner(true), UI.lp(-1, bannerH, 10, this));

        // menu em fileira (substitui o menu lateral)
        col.addView(buildMenuChips(), UI.lp(-1, -2, 10, this));

        // assinatura e relógio/clima
        col.addView(subPanel(), UI.lp(-1, UI.dp(this, 62), 10, this));
        col.addView(clockPanel(), UI.lp(-1, UI.dp(this, 62), 8, this));

        // estrelas ninja: 3 por linha
        col.addView(buildStarGrid(dm), UI.lp(-1, -2, 8, this));
    }

    private View buildMenuChips() {
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        hs.addView(row);
        List<Object[]> items = menuItems();
        for (int i = 0; i < items.size(); i++) {
            Object[] it = items.get(i);
            final Runnable r = (Runnable) it[2];
            LinearLayout chip = new LinearLayout(this);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setFocusable(true); chip.setClickable(true);
            GradientDrawable g = new GradientDrawable();
            g.setColor(i == 0 ? 0x55FFB020 : 0x99000000);
            g.setCornerRadius(UI.dp(this, 20));
            g.setStroke(UI.dp(this, 2), i == 0 ? Theme.primary : 0x66FFB020);
            chip.setBackground(g);
            chip.setPadding(UI.dp(this, 12), UI.dp(this, 8), UI.dp(this, 14), UI.dp(this, 8));
            chip.addView(new IconView(this).set((String) it[1], 0xFFFFFFFF, Theme.primary), new LinearLayout.LayoutParams(UI.dp(this, 18), UI.dp(this, 18)));
            TextView t = UI.text(this, (String) it[0], 12, UI.WHITE, true);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
            tl.leftMargin = UI.dp(this, 7);
            chip.addView(t, tl);
            chip.setOnClickListener(v -> r.run());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = UI.dp(this, 8);
            row.addView(chip, lp);
        }
        return hs;
    }

    private View buildStarGrid(DisplayMetrics dm) {
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        int cell = (dm.widthPixels - UI.dp(this, 24)) / 3;
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            row.setClipChildren(false);
            for (int c = 0; c < 3; c++) {
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, (int) (cell * 0.92f), 1);
                tl.setMargins(UI.dp(this, 4), UI.dp(this, 4), UI.dp(this, 4), UI.dp(this, 4));
                row.addView(createStar(r * 3 + c), tl);
            }
            g.addView(row, new LinearLayout.LayoutParams(-1, (int) (cell * 0.92f) + UI.dp(this, 8)));
        }
        return g;
    }

    // ================================================================== cabeçalho
    private View buildHeader() {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView wm = new ImageView(this);
        wm.setImageResource(R.drawable.nt_wordmark);
        wm.setAdjustViewBounds(true);
        wm.setScaleType(ImageView.ScaleType.FIT_START);
        head.addView(wm, new LinearLayout.LayoutParams(-2, dpk(46)));

        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(-2, -2);
        ulp.leftMargin = dpk(18);
        head.addView(userBlock(), ulp);

        View div = new View(this);
        div.setBackgroundColor(Theme.primary);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(UI.dp(this, 2), dpk(28));
        dl.setMargins(dpk(14), 0, dpk(14), 0);
        head.addView(div, dl);

        head.addView(noticeView(), new LinearLayout.LayoutParams(0, -2, 1));
        addStatusButtons(head);
        return head;
    }

    /** Usuário real (usuário do servidor ou ID do aparelho). */
    private View userBlock() {
        LinearLayout user = new LinearLayout(this);
        user.setGravity(Gravity.CENTER_VERTICAL);
        user.addView(new IconView(this).set("user", 0xFFFFFFFF, Theme.primary), new LinearLayout.LayoutParams(dpk(26), dpk(26)));
        LinearLayout ut = new LinearLayout(this);
        ut.setOrientation(LinearLayout.VERTICAL);
        TextView ul = UI.text(this, "USUÁRIO", spk(9), UI.MUTED, true);
        userValue = UI.text(this, userLabel(), spk(14), UI.WHITE, true);
        userValue.setSingleLine(true);
        ut.addView(ul); ut.addView(userValue);
        LinearLayout.LayoutParams utl = new LinearLayout.LayoutParams(-2, -2);
        utl.leftMargin = dpk(8);
        user.addView(ut, utl);
        return user;
    }

    /** Mensagem enviada pelo painel (home_notice). */
    private View noticeView() {
        TextView notice = UI.text(this, Cfg.get("home_notice", ""), spk(13), UI.WHITE, true);
        notice.setSingleLine(true);
        notice.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        notice.setMarqueeRepeatLimit(-1);
        notice.setSelected(true);
        return notice;
    }

    /** Indicador de conexão e sino de notificações. */
    private void addStatusButtons(LinearLayout head) {
        wifiRing = new FrameLayout(this);
        wifiIcon = new IconView(this);
        wifiRing.addView(wifiIcon, new FrameLayout.LayoutParams(dpk(22), dpk(22), Gravity.CENTER));
        head.addView(circle(wifiRing, null), circleLp());
        FrameLayout bell = new FrameLayout(this);
        bell.addView(new IconView(this).set("bell", 0xFFFFFFFF, Theme.primary), new FrameLayout.LayoutParams(dpk(22), dpk(22), Gravity.CENTER));
        bellDot = new View(this);
        bellDot.setBackground(UI.round(this, 0xFFFF3B30, 6));
        FrameLayout.LayoutParams dotLp = new FrameLayout.LayoutParams(dpk(9), dpk(9), Gravity.TOP | Gravity.END);
        dotLp.setMargins(0, dpk(7), dpk(7), 0);
        bell.addView(bellDot, dotLp);
        head.addView(circle(bell, this::showNotifications), circleLp());
        setOnline(isOnline());
    }

    private LinearLayout.LayoutParams circleLp() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dpk(40), dpk(40));
        l.leftMargin = dpk(10);
        return l;
    }

    private View circle(FrameLayout inner, final Runnable r) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(UI.alpha(0xCC));
        g.setStroke(UI.dp(this, 2), Theme.primary);
        inner.setBackground(g);
        if (r != null) {
            inner.setFocusable(true); inner.setClickable(true);
            inner.setOnClickListener(v -> r.run());
            UI.scaleOnFocus(inner);
        }
        return inner;
    }

    private String userLabel() {
        if ("xtream".equals(Repo.mode())) { String u = Prefs.get("x_user", ""); if (!u.isEmpty()) return u; }
        return Panel.friendlyId();
    }

    // ================================================================== menu lateral
    /** Itens do menu: {rótulo, ícone, ação}. Usado pelo menu lateral (TV) e pela fileira de atalhos (celular). */
    private List<Object[]> menuItems() {
        List<Object[]> l = new ArrayList<>();
        l.add(new Object[]{"Início", "home", (Runnable) () -> { }});
        l.add(new Object[]{"Buscar", "search", (Runnable) () -> open("search")});
        l.add(new Object[]{"Histórico", "clock", (Runnable) () -> open("history")});
        l.add(new Object[]{T.t("Favoritos"), "heart", (Runnable) () -> open("fav")});
        if (YouTube.enabled()) l.add(new Object[]{"YouTube", "play_circle", (Runnable) () -> WebAppActivity.open(this, "youtube")});
        if (Spotify.enabled()) l.add(new Object[]{"Spotify", "music", (Runnable) () -> WebAppActivity.open(this, "spotify")});
        l.add(new Object[]{T.t("Suporte"), "headset", (Runnable) () -> startActivity(new Intent(this, SupportActivity.class))});
        l.add(new Object[]{"Perfil", "user", (Runnable) () -> startActivity(new Intent(this, AccountActivity.class))});
        l.add(new Object[]{T.t("Ajustes"), "gear", (Runnable) () -> startActivity(new Intent(this, SettingsActivity.class))});
        return l;
    }

    private View buildSidebar() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = dpk(8);
        col.setPadding(pad, pad, pad, pad);
        List<Object[]> items = menuItems();
        for (int i = 0; i < items.size(); i++) {
            Object[] it = items.get(i);
            sideRow(col, (String) it[0], (String) it[1], i == 0, (Runnable) it[2]);
        }

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC0B0B0B, 0xB0000000});
        g.setCornerRadius(UI.dp(this, 18 * Theme.radius));
        g.setStroke(UI.dp(this, 2), Theme.primary);
        sv.setBackground(g);
        return sv;
    }

    private void sideRow(LinearLayout col, String label, String icon, boolean selected, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true); row.setClickable(true);
        if (selected) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x55FFB020, 0x22FF6A00});
            g.setCornerRadius(UI.dp(this, 14 * Theme.radius));
            g.setStroke(UI.dp(this, 2), Theme.primary);
            row.setBackground(g);
        } else row.setBackground(UI.focusBg(this, 0x00000000, 14));
        int ph = dpk(10), pv = dpk(9);
        row.setPadding(ph, pv, ph, pv);
        row.addView(new IconView(this).set(icon, 0xFFFFFFFF, selected ? Theme.primary : IconSet.accentColor()), new LinearLayout.LayoutParams(dpk(21), dpk(21)));
        TextView t = UI.text(this, label, spk(13), UI.WHITE, true);
        t.setSingleLine(true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dpk(10);
        row.addView(t, tl);
        row.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(row);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dpk(3);
        col.addView(row, lp);
    }

    // ================================================================== destaque
    private View buildBanner() { return buildBanner(false); }

    private View buildBanner(boolean compact) {
        compactBanner = compact;
        final FrameLayout banner = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF000000);
        g.setCornerRadius(UI.dp(this, 18 * Theme.radius));
        g.setStroke(UI.dp(this, 2), Theme.primary);
        banner.setBackground(g);
        banner.setClipToOutline(true);

        bBg = new ImageView(this);
        bBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bBg.setVisibility(View.GONE);
        banner.addView(bBg, new FrameLayout.LayoutParams(-1, -1));
        bPoster = new ImageView(this);
        bPoster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(10, -1, Gravity.END);
        bPoster.setVisibility(View.GONE);   // a capa/backdrop cobre o banner inteiro (TV e celular)
        banner.addView(bPoster, pl);
        banner.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> {
            int w = compact ? 0 : (int) ((r - l) * 0.34f);
            if (pl.width != w) { pl.width = w; bPoster.setLayoutParams(pl); }
        });
        View grad = new View(this);
        grad.setBackground(compact
                ? new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x22000000, 0x55000000, 0xF5000000})
                : new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF2000000, 0xCC000000, 0x00000000}));
        banner.addView(grad, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(compact ? Gravity.BOTTOM : Gravity.CENTER_VERTICAL);
        int pad = dpk(14);
        col.setPadding(pad, dpk(8), pad, dpk(18));
        banner.addView(col, new FrameLayout.LayoutParams(-1, -1));

        bLabel = UI.text(this, "FILME EM DESTAQUE", spk(10), UI.WHITE, true);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0x99000000);
        pill.setCornerRadius(UI.dp(this, 14));
        pill.setStroke(UI.dp(this, 2), Theme.primary);
        bLabel.setBackground(pill);
        bLabel.setPadding(dpk(12), dpk(3), dpk(12), dpk(3));
        col.addView(bLabel, new LinearLayout.LayoutParams(-2, -2));
        bTitle = UI.text(this, "", spk(21), UI.WHITE, true);
        bTitle.setMaxLines(2);
        bTitle.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(bTitle, UI.lp(-2, -2, 4, this));
        bMeta = UI.text(this, "", spk(11), 0xFFEADFC9, false);
        bMeta.setSingleLine(true);
        col.addView(bMeta, new LinearLayout.LayoutParams(-2, -2));
        bPlot = UI.text(this, "", spk(11), 0xFFD7D0C4, false);
        bPlot.setMaxLines(compact ? 2 : 3);
        if (compact) bPlot.setVisibility(View.GONE);
        bPlot.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2);
        plp.topMargin = dpk(3);
        col.addView(bPlot, plp);
        LinearLayout btns = new LinearLayout(this);
        btns.addView(ninjaButton("▶  ASSISTIR AGORA", true, this::watchFeatured));
        btns.addView(ninjaButton(compact ? "ⓘ  DETALHES" : "ⓘ  MAIS INFORMAÇÕES", false, this::infoFeatured));
        col.addView(btns, UI.lp(-2, -2, 6, this));

        dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2, compact ? (Gravity.TOP | Gravity.END) : (Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));
        if (compact) { dlp.topMargin = dpk(14); dlp.rightMargin = dpk(10); } else dlp.bottomMargin = dpk(6);
        banner.addView(dots, dlp);
        return banner;
    }

    private View ninjaButton(String label, boolean strong, final Runnable r) {
        TextView t = UI.text(this, label, spk(11), UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setFocusable(true); t.setClickable(true);
        int ph = dpk(14), pv = dpk(7);
        t.setPadding(ph, pv, ph, pv);
        GradientDrawable g = new GradientDrawable();
        g.setColor(strong ? 0x66FF8A00 : 0x99000000);
        g.setCornerRadius(UI.dp(this, 18 * Theme.radius));
        g.setStroke(UI.dp(this, 2), strong ? Theme.primary : 0xCCFFFFFF);
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dpk(10);
        t.setLayoutParams(lp);
        return t;
    }

    /** Destaques reais: filmes mais recentes do servidor (os 5 melhores avaliados entre os 30 últimos). */
    private void loadFeatured() {
        Repo.async(() -> {
            List<Item> out = new ArrayList<>();
            for (String kind : new String[]{"vod", "series"}) {
                List<Item> src = new ArrayList<>();
                for (Item i : Repo.items(kind, null)) if (i.cover != null && !i.cover.isEmpty()) src.add(i);
                Collections.sort(src, (a, b2) -> Long.compare(b2.added, a.added));
                List<Item> top = new ArrayList<>(src.subList(0, Math.min(30, src.size())));
                Collections.sort(top, (a, b2) -> Double.compare(b2.rating, a.rating));
                for (Item i : top) { if (out.size() < 5) out.add(i); }
                if (out.size() >= 5) break;
            }
            return out;
        }, new Repo.Result<List<Item>>() {
            @Override public void ok(List<Item> v) {
                featured.clear(); featured.addAll(v);
                buildDots();
                h.removeCallbacks(rotate);
                if (featured.isEmpty()) { bLabel.setVisibility(View.GONE); bTitle.setText(""); bMeta.setText(""); bPlot.setText(""); return; }
                showFeatured(0);
                h.postDelayed(rotate, 9_000);
            }
            @Override public void fail(String e) { }
        });
    }

    private void buildDots() {
        dots.removeAllViews();
        for (int i = 0; i < featured.size(); i++) {
            final int idx = i;
            View d = new View(this);
            d.setFocusable(true);
            d.setOnClickListener(v -> showFeatured(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpk(8), dpk(8));
            lp.setMargins(dpk(4), 0, dpk(4), 0);
            dots.addView(d, lp);
        }
    }

    private void paintDots() {
        for (int i = 0; i < dots.getChildCount(); i++)
            dots.getChildAt(i).setBackground(UI.round(this, i == fIndex ? Theme.primary : 0x66FFFFFF, 8));
    }

    private void showFeatured(int i) {
        if (i < 0 || i >= featured.size()) return;
        fIndex = i;
        final Item it = featured.get(i);
        paintDots();
        bLabel.setVisibility(View.VISIBLE);
        bLabel.setText("series".equals(it.kind) ? "SÉRIE EM DESTAQUE" : "FILME EM DESTAQUE");
        bTitle.setText(it.name);
        bMeta.setText(it.rating > 0 ? "★ " + String.format(Locale.US, "%.1f", it.rating) : "");
        bPlot.setText(it.plot == null ? "" : it.plot);
        // capa ocupa o banner inteiro (depois troca pelo backdrop widescreen, se o servidor tiver)
        bPoster.setVisibility(View.GONE);
        bBg.setVisibility(View.VISIBLE);
        Glide.with(this).load(it.cover).centerCrop().into(bBg);

        final Xtream x = Repo.xtream();
        if (x == null) return;
        Repo.async(() -> "series".equals(it.kind) ? x.seriesInfo(it.id) : x.vodInfo(it.id), new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject j) {
                if (featured.isEmpty() || fIndex >= featured.size() || featured.get(fIndex) != it) return;
                JSONObject info = j.optJSONObject("info");
                if (info == null) return;
                String plot = info.optString("plot", info.optString("description", ""));
                if (!plot.isEmpty()) bPlot.setText(plot);
                String genre = info.optString("genre", "");
                String rel = info.optString("releasedate", info.optString("releaseDate", info.optString("year", "")));
                String year = rel.length() >= 4 ? rel.substring(0, 4) : "";
                String rating = info.optString("rating", "");
                StringBuilder m = new StringBuilder();
                if (!genre.isEmpty()) m.append(genre);
                try { double rv = Double.parseDouble(rating); if (rv > 0) { if (m.length() > 0) m.append("  •  "); m.append("★ ").append(String.format(Locale.US, "%.1f", rv > 5.5 ? rv / 2 : rv)); } } catch (Exception ignored) { }
                if (m.length() > 0) bMeta.setText(m.toString());
                if (!year.isEmpty() && !it.name.contains(year)) bTitle.setText(it.name + " (" + year + ")");
                String back = "";
                JSONArray bd = info.optJSONArray("backdrop_path");
                if (bd != null && bd.length() > 0) back = bd.optString(0, "");
                if (!back.isEmpty()) {
                    bBg.setVisibility(View.VISIBLE);
                    bPoster.setVisibility(View.GONE);
                    Glide.with(HomeActivity.this).load(back).centerCrop().into(bBg);
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void watchFeatured() {
        if (featured.isEmpty()) return;
        Item it = featured.get(fIndex);
        if ("series".equals(it.kind)) { infoFeatured(); return; }
        ArrayList<Item> one = new ArrayList<>();
        one.add(it);
        Repo.playlist = one; Repo.playlistIndex = 0;
        startActivity(new Intent(this, PlayerActivity.class));
    }

    private void infoFeatured() {
        if (featured.isEmpty()) return;
        Repo.selected = featured.get(fIndex);
        startActivity(new Intent(this, DetailsActivity.class));
    }

    // ================================================================== assinatura + relógio/clima
    private View buildInfoRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(subPanel(), new LinearLayout.LayoutParams(0, -1, 1.55f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -1, 1f);
        cl.leftMargin = dpk(10);
        row.addView(clockPanel(), cl);
        return row;
    }

    private View subPanel() {
        LinearLayout sub = new LinearLayout(this);
        sub.setGravity(Gravity.CENTER_VERTICAL);
        sub.setFocusable(true); sub.setClickable(true);
        sub.setBackground(panel(true));
        sub.setPadding(dpk(14), dpk(4), dpk(14), dpk(4));
        sub.addView(new IconView(this).set("crown", Theme.primary, 0xFFFFE08A), new LinearLayout.LayoutParams(dpk(30), dpk(30)));
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        subTitle = UI.text(this, "", spk(14), Theme.primary, true);
        subTitle.setSingleLine(true);
        subDetail = UI.text(this, "", spk(11), UI.WHITE, false);
        subDetail.setSingleLine(true);
        st.addView(subTitle); st.addView(subDetail);
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(0, -2, 1);
        stl.leftMargin = dpk(10);
        sub.addView(st, stl);
        subDot = new View(this);
        sub.addView(subDot, new LinearLayout.LayoutParams(dpk(12), dpk(12)));
        sub.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        UI.scaleOnFocus(sub);
        return sub;
    }

    private View clockPanel() {
        LinearLayout clk = new LinearLayout(this);
        clk.setGravity(Gravity.CENTER_VERTICAL);
        clk.setBackground(panel(false));
        clk.setPadding(dpk(14), dpk(4), dpk(14), dpk(4));
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm a");
        clock.setTextColor(UI.WHITE); clock.setTextSize(spk(19)); clock.setTypeface(UI.font(true));
        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEE, d MMM"); date.setFormat12Hour("EEE, d MMM");
        date.setTextColor(UI.MUTED); date.setTextSize(spk(10)); date.setTypeface(UI.font(false));
        tcol.addView(clock); tcol.addView(date);
        clk.addView(tcol, new LinearLayout.LayoutParams(0, -2, 1));
        weatherIcon = new ImageView(this);
        clk.addView(weatherIcon, new LinearLayout.LayoutParams(dpk(26), dpk(26)));
        LinearLayout wcol = new LinearLayout(this);
        wcol.setOrientation(LinearLayout.VERTICAL);
        weatherText = UI.text(this, "--°C", spk(14), UI.WHITE, true);
        cityText = UI.text(this, "", spk(9), UI.MUTED, false);
        cityText.setSingleLine(true);
        wcol.addView(weatherText); wcol.addView(cityText);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.leftMargin = dpk(6);
        clk.addView(wcol, wl);
        return clk;
    }

    private GradientDrawable panel(boolean gold) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC0B0B0B, 0xB0000000});
        g.setCornerRadius(UI.dp(this, 16 * Theme.radius));
        g.setStroke(UI.dp(this, gold ? 2 : 1), gold ? Theme.primary : 0x55FFB020);
        return g;
    }

    private static final SimpleDateFormat FMT = new SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", new Locale("pt", "BR"));

    /** Status real da assinatura (dados do servidor IPTV salvos no login e atualizados ao abrir). */
    private void updateSubscription() {
        boolean xt = "xtream".equals(Repo.mode());
        String st = Prefs.get("acc_status", ""), exp = Prefs.get("acc_exp", "");
        boolean unlimited = exp.isEmpty() || exp.equals("null");
        long expMs = 0;
        try { if (!unlimited) expMs = Long.parseLong(exp) * 1000L; } catch (Exception e) { unlimited = true; }
        boolean expired = !unlimited && expMs < System.currentTimeMillis();
        boolean active = !xt || (!expired && (st.isEmpty() || st.equalsIgnoreCase("active")));
        String title = active ? "ASSINATURA ATIVA" : (expired ? "ASSINATURA VENCIDA" : "ASSINATURA " + st.toUpperCase());
        String detail = !xt ? "Acesso por lista ativada" : (unlimited ? "Sem data de vencimento" : (expired ? "Venceu em " : "Válida até ") + FMT.format(new Date(expMs)));
        subTitle.setText(title);
        subTitle.setTextColor(active ? Theme.primary : 0xFFFF5A5F);
        subDetail.setText(detail);
        subDot.setBackground(UI.round(this, active ? 0xFF2FD27A : 0xFFFF5A5F, 12));
        bellDot.setVisibility(notifications().isEmpty() ? View.GONE : View.VISIBLE);
    }

    /** Atualiza validade/status direto no servidor IPTV. */
    private void refreshAccount() {
        final Xtream x = Repo.xtream();
        if (x == null) return;
        Repo.async(x::auth, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject j) {
                JSONObject ui = j.optJSONObject("user_info");
                if (ui == null) return;
                Prefs.put("acc_status", ui.optString("status"));
                Prefs.put("acc_exp", ui.optString("exp_date"));
                Prefs.put("acc_maxcon", ui.optString("max_connections"));
                updateSubscription();
            }
            @Override public void fail(String e) { }
        });
    }

    // ================================================================== notificações e conexão
    private List<String> notifications() {
        List<String> l = new ArrayList<>();
        String n = Cfg.get("home_notice", "");
        if (!n.isEmpty()) l.add("📢  " + n);
        if ("xtream".equals(Repo.mode())) {
            String exp = Prefs.get("acc_exp", "");
            try {
                long ms = Long.parseLong(exp) * 1000L;
                long left = ms - System.currentTimeMillis();
                if (left < 0) l.add("⚠  Sua assinatura venceu em " + FMT.format(new Date(ms)) + ".");
                else if (left <= 7L * 86_400_000L) {
                    long days = Math.max(1, left / 86_400_000L);
                    l.add("⏳  Sua assinatura vence em " + days + (days == 1 ? " dia" : " dias") + " (" + FMT.format(new Date(ms)) + ").");
                }
            } catch (Exception ignored) { }
        }
        return l;
    }

    private void showNotifications() {
        List<String> l = notifications();
        String msg = l.isEmpty() ? "Sem notificações." : TextUtils.join("\n\n", l);
        new AlertDialog.Builder(this).setTitle("Notificações").setMessage(msg).setPositiveButton(T.t("Fechar"), null).show();
    }

    private boolean isOnline() {
        try {
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) { return true; }
    }

    private void setOnline(boolean on) {
        if (wifiIcon == null) return;
        wifiIcon.set(on ? "wifi" : "wifi_off", on ? 0xFFFFFFFF : 0xFFFF5A5F, on ? Theme.primary : 0xFFFF5A5F);
    }

    // ================================================================== estrelas ninja
    private static final String[] STAR_KIND = {"live", "vod", "series", "anime", "kids", "sports"};
    private static final String[] STAR_LABEL = {"TV AO VIVO", "FILMES", "SÉRIES", "ANIMES", "KIDS", "ESPORTES"};
    private static final String[] STAR_ICON = {"tv_play", "clapper", "play_square", "eye", "smile", "ball"};

    private Drawable tileLayers(boolean on) {
        float r = UI.dp(this, 18 * Theme.radius);
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xE0161006, 0xF0050403});
        base.setCornerRadius(r);
        base.setStroke(UI.dp(this, on ? 3 : 2), on ? 0xFFFFD27A : 0xCCFFB020);
        GradientDrawable glow = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0x00000000, 0x00000000, on ? 0x99FF8A00 : 0x55FF8A00});
        glow.setCornerRadius(r);
        return new LayerDrawable(new Drawable[]{base, glow});
    }

    private Drawable tileBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, tileLayers(true));
        sl.addState(new int[]{android.R.attr.state_pressed}, tileLayers(true));
        sl.addState(new int[]{}, tileLayers(false));
        return sl;
    }

    /** Botão de categoria: cartão arredondado com borda dourada, ícone e nome (como na tela de referência). */
    private View createStar(int i) {
        final String kind = STAR_KIND[i];
        FrameLayout tile = new FrameLayout(this);
        tile.setFocusable(true); tile.setClickable(true);
        tile.setBackground(tileBg());
        tile.setContentDescription(STAR_LABEL[i]);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int pad = dpk(8);
        col.setPadding(pad, pad, pad, pad);
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dpk(8), dpk(4), dpk(8), 0);
        wrap.addView(new IconView(this).set(STAR_ICON[i], Theme.primary, 0xFFFFE08A), new FrameLayout.LayoutParams(-1, -1));
        col.addView(wrap, new LinearLayout.LayoutParams(-1, 0, 3));
        TextView lab = UI.text(this, STAR_LABEL[i], 13, UI.WHITE, true);
        lab.setGravity(Gravity.CENTER);
        lab.setSingleLine(true);
        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(lab, 8, 15, 1, TypedValue.COMPLEX_UNIT_SP);
        col.addView(lab, new LinearLayout.LayoutParams(-1, 0, 1));
        tile.addView(col, new FrameLayout.LayoutParams(-1, -1));
        tile.setOnClickListener(v -> open(kind));
        tile.setOnFocusChangeListener((v, f) -> v.animate().scaleX(f ? 1.07f : 1f).scaleY(f ? 1.07f : 1f).setDuration(140).start());
        if (i == 0) firstStar = tile;
        return tile;
    }

    private View buildStars() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setClipChildren(false);
        for (int i = 0; i < STAR_KIND.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.setMargins(dpk(5), dpk(4), dpk(5), dpk(4));
            row.addView(createStar(i), lp);
        }
        return row;
    }

    // ================================================================== ações
    private void open(String kind) {
        if (!Repo.loaded) { UI.toast(this, T.t("Atualizando conteúdo...")); return; }
        Intent i = new Intent(this, BrowseActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void loadContent(boolean force) {
        loading.setVisibility(View.VISIBLE);
        loading.setText(T.t("Atualizando conteúdo..."));
        Repo.load(this, force, new Repo.Listener() {
            @Override public void progress(String m) { loading.setText(T.t("Atualizando conteúdo...") + "\n" + m); }
            @Override public void done(String err) {
                if (err != null) {
                    new AlertDialog.Builder(HomeActivity.this).setMessage(err).setCancelable(false)
                            .setPositiveButton(T.t("Tentar novamente"), (d, w) -> loadContent(true))
                            .setNegativeButton(T.t("Sair da conta"), (d, w) -> logout()).show();
                    return;
                }
                loading.setVisibility(View.GONE);
                loadFeatured();
                if (firstStar != null) firstStar.requestFocus();
            }
        });
    }

    private void refreshWeather() {
        Repo.async(Weather::fetch, new Repo.Result<Weather.Info>() {
            @Override public void ok(Weather.Info w) {
                weatherText.setText(w.temp + "°C");
                cityText.setText(w.city);
                weatherIcon.setImageResource(Weather.icon(w));
            }
            @Override public void fail(String e) { weatherText.setText("--°C"); }
        });
    }

    /** Ativação remota: confere se o painel mudou a lista (DNS/URL) ou desativou o ID. */
    private void checkRemote() {
        if (!Prefs.bool("activated_remote", false)) return;
        Repo.async(Panel::activation, new Repo.Result<Panel.Activation>() {
            @Override public void ok(Panel.Activation a) {
                if (!a.active) { UI.toast(HomeActivity.this, "Ativação removida pelo painel."); logout(); return; }
                String rev = String.valueOf(a.revision);
                if (!rev.equals(Prefs.get("activation_rev", ""))) {
                    Prefs.put("activation_rev", rev);
                    final String url = a.m3u;
                    Repo.async(() -> { LoginActivity.completeFromUrl(url, true); return true; }, new Repo.Result<Boolean>() {
                        @Override public void ok(Boolean v) { loadContent(true); }
                        @Override public void fail(String e) { UI.toast(HomeActivity.this, e); }
                    });
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void logout() {
        Repo.logout(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override protected void onStart() {
        super.onStart();
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        setOnline(isOnline());
        try {
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { runOnUiThread(() -> setOnline(true)); }
                @Override public void onLost(Network n) { runOnUiThread(() -> setOnline(isOnline())); }
            };
            cm.registerNetworkCallback(new NetworkRequest.Builder().addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb);
        } catch (Exception e) { netCb = null; }
    }

    @Override protected void onStop() {
        try { if (cm != null && netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        netCb = null;
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        h.removeCallbacks(licTick);
        h.post(licTick);
        updateSubscription();
        if (!Repo.loaded && loading.getVisibility() != View.VISIBLE) loadContent(false);
        h.removeCallbacks(rotate);
        if (featured.size() > 1) h.postDelayed(rotate, 9_000);
    }

    private final Runnable licTick = new Runnable() {
        @Override public void run() { LicenseGate.check(HomeActivity.this); h.postDelayed(this, 300_000); }
    };
    @Override protected void onPause() { h.removeCallbacks(rotate); h.removeCallbacks(licTick); super.onPause(); }

    @Override protected void onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy(); }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Fechar " + Cfg.appName() + "?")
                .setPositiveButton(T.t("Fechar"), (d, w) -> finishAffinity())
                .setNegativeButton(T.t("Cancelar"), null).show();
    }
}
