package com.ninjatv.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import com.bumptech.glide.Glide;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Tela inicial Ninja TV: cabeçalho, menu lateral, destaque, assinatura, relógio/clima e as 6 estrelas ninja. */
public class HomeActivity extends BaseActivity {
    private float k = 1f;                       // escala conforme a altura da tela
    private TextView loading, weatherText, cityText, subTitle, subDetail, bLabel, bTitle, bMeta, bPlot, userValue;
    private View subDot, bellDot;
    private ImageView weatherIcon, bBg, bPoster;
    private IconView wifiIcon;
    private FrameLayout wifiRing;
    private LinearLayout dots;
    private final List<Item> featured = new ArrayList<>();
    private int fIndex = 0;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable rotate = new Runnable() {
        @Override public void run() {
            if (featured.size() > 1) showFeatured((fIndex + 1) % featured.size());
            h.postDelayed(this, 9_000);
        }
    };
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback netCb;
    private View firstStar;

    private int dpk(float v) { return UI.dp(this, v * k); }
    private float spk(float v) { return v * k; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float hDp = dm.heightPixels / dm.density;
        k = Math.max(0.72f, Math.min(1.35f, hDp / 480f));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        UI.background(bg);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{UI.alpha(0xB0), UI.alpha(0x66), UI.alpha(0xCC)}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        root.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = dpk(12);
        content.setPadding(p, p / 2, p, p / 2);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        content.addView(buildHeader(), new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, 0, 1);
        bl.topMargin = dpk(6);
        content.addView(body, bl);

        int sideW = (int) Math.max(UI.dp(this, 112), Math.min(UI.dp(this, 170), dm.widthPixels * 0.15f));
        body.addView(buildSidebar(), new LinearLayout.LayoutParams(sideW, -1));

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, -1, 1);
        ml.leftMargin = dpk(10);
        body.addView(main, ml);
        main.addView(buildBanner(), new LinearLayout.LayoutParams(-1, 0, 38));
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, 0, 13);
        il.topMargin = dpk(8);
        main.addView(buildInfoRow(), il);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, 0, 49);
        sl.topMargin = dpk(2);
        main.addView(buildStars(), sl);

        loading = UI.text(this, T.t("Atualizando conteúdo..."), 15, UI.WHITE, true);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundColor(UI.alpha(0xE6));
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        updateSubscription();
        loadContent(false);
        refreshWeather();
        refreshAccount();
        checkRemote();
        Repo.async(Panel::config, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { }
            @Override public void fail(String e) { }
        });
    }

    // ================================================================== cabeçalho
    private View buildHeader() {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView wm = new ImageView(this);
        wm.setImageResource(R.drawable.nt_wordmark);
        wm.setAdjustViewBounds(true);
        wm.setScaleType(ImageView.ScaleType.FIT_START);
        head.addView(wm, new LinearLayout.LayoutParams(-2, dpk(46)));

        // usuário (dado real da conta)
        LinearLayout user = new LinearLayout(this);
        user.setGravity(Gravity.CENTER_VERTICAL);
        user.addView(new IconView(this).set("user", 0xFFFFFFFF, Theme.primary), new LinearLayout.LayoutParams(dpk(26), dpk(26)));
        LinearLayout ut = new LinearLayout(this);
        ut.setOrientation(LinearLayout.VERTICAL);
        TextView ul = UI.text(this, "USUÁRIO", spk(9), UI.MUTED, true);
        userValue = UI.text(this, userLabel(), spk(14), UI.WHITE, true);
        userValue.setSingleLine(true);
        ut.addView(ul); ut.addView(userValue);
        LinearLayout.LayoutParams utl = new LinearLayout.LayoutParams(-2, -2);
        utl.leftMargin = dpk(8);
        user.addView(ut, utl);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(-2, -2);
        ulp.leftMargin = dpk(18);
        head.addView(user, ulp);

        // divisor dourado
        View div = new View(this);
        div.setBackgroundColor(Theme.primary);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(UI.dp(this, 2), dpk(28));
        dl.setMargins(dpk(14), 0, dpk(14), 0);
        head.addView(div, dl);

        // mensagem enviada pelo painel (home_notice)
        TextView notice = UI.text(this, Cfg.get("home_notice", ""), spk(13), UI.WHITE, true);
        notice.setSingleLine(true);
        notice.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        notice.setMarqueeRepeatLimit(-1);
        notice.setSelected(true);
        head.addView(notice, new LinearLayout.LayoutParams(0, -2, 1));

        // conexão + notificações
        wifiRing = new FrameLayout(this);
        wifiIcon = new IconView(this);
        wifiRing.addView(wifiIcon, new FrameLayout.LayoutParams(dpk(22), dpk(22), Gravity.CENTER));
        head.addView(circle(wifiRing, null), circleLp());
        FrameLayout bell = new FrameLayout(this);
        bell.addView(new IconView(this).set("bell", 0xFFFFFFFF, Theme.primary), new FrameLayout.LayoutParams(dpk(22), dpk(22), Gravity.CENTER));
        bellDot = new View(this);
        bellDot.setBackground(UI.round(this, 0xFFFF3B30, 6));
        FrameLayout.LayoutParams dotLp = new FrameLayout.LayoutParams(dpk(9), dpk(9), Gravity.TOP | Gravity.END);
        dotLp.setMargins(0, dpk(7), dpk(7), 0);
        bell.addView(bellDot, dotLp);
        head.addView(circle(bell, this::showNotifications), circleLp());
        setOnline(isOnline());
        return head;
    }

    private LinearLayout.LayoutParams circleLp() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dpk(40), dpk(40));
        l.leftMargin = dpk(10);
        return l;
    }

    private View circle(FrameLayout inner, final Runnable r) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(UI.alpha(0xCC));
        g.setStroke(UI.dp(this, 2), Theme.primary);
        inner.setBackground(g);
        if (r != null) {
            inner.setFocusable(true); inner.setClickable(true);
            inner.setOnClickListener(v -> r.run());
            UI.scaleOnFocus(inner);
        }
        return inner;
    }

    private String userLabel() {
        if ("xtream".equals(Repo.mode())) { String u = Prefs.get("x_user", ""); if (!u.isEmpty()) return u; }
        return Panel.friendlyId();
    }

    // ================================================================== menu lateral
    private View buildSidebar() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = dpk(8);
        col.setPadding(pad, pad, pad, pad);
        sideRow(col, "Início", "home", true, () -> { });
        sideRow(col, T.t("Busca").equals("Busca") ? "Buscar" : T.t("Busca"), "search", false, () -> open("search"));
        sideRow(col, "Histórico", "clock", false, () -> open("history"));
        sideRow(col, T.t("Favoritos"), "heart", false, () -> open("fav"));
        if (YouTube.enabled()) sideRow(col, "YouTube", "play_circle", false, () -> startActivity(new Intent(this, YouTubeActivity.class)));
        sideRow(col, T.t("Suporte"), "headset", false, () -> startActivity(new Intent(this, SupportActivity.class)));
        sideRow(col, "Perfil", "user", false, () -> startActivity(new Intent(this, AccountActivity.class)));
        sideRow(col, T.t("Ajustes"), "gear", false, () -> startActivity(new Intent(this, SettingsActivity.class)));

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC0B0B0B, 0xB0000000});
        g.setCornerRadius(UI.dp(this, 18 * Theme.radius));
        g.setStroke(UI.dp(this, 2), Theme.primary);
        sv.setBackground(g);
        return sv;
    }

    private void sideRow(LinearLayout col, String label, String icon, boolean selected, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true); row.setClickable(true);
        if (selected) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x55FFB020, 0x22FF6A00});
            g.setCornerRadius(UI.dp(this, 14 * Theme.radius));
            g.setStroke(UI.dp(this, 2), Theme.primary);
            row.setBackground(g);
        } else row.setBackground(UI.focusBg(this, 0x00000000, 14));
        int ph = dpk(10), pv = dpk(9);
        row.setPadding(ph, pv, ph, pv);
        row.addView(new IconView(this).set(icon, 0xFFFFFFFF, selected ? Theme.primary : IconSet.accentColor()), new LinearLayout.LayoutParams(dpk(21), dpk(21)));
        TextView t = UI.text(this, label, spk(13), UI.WHITE, true);
        t.setSingleLine(true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dpk(10);
        row.addView(t, tl);
        row.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(row);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dpk(3);
        col.addView(row, lp);
    }

    // ================================================================== destaque
    private View buildBanner() {
        final FrameLayout banner = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF000000);
        g.setCornerRadius(UI.dp(this, 18 * Theme.radius));
        g.setStroke(UI.dp(this, 2), Theme.primary);
        banner.setBackground(g);
        banner.setClipToOutline(true);

        bBg = new ImageView(this);
        bBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bBg.setVisibility(View.GONE);
        banner.addView(bBg, new FrameLayout.LayoutParams(-1, -1));
        bPoster = new ImageView(this);
        bPoster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(10, -1, Gravity.END);
        banner.addView(bPoster, pl);
        banner.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> {
            int w = (int) ((r - l) * 0.34f);
            if (pl.width != w) { pl.width = w; bPoster.setLayoutParams(pl); }
        });
        View grad = new View(this);
        grad.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF2000000, 0xCC000000, 0x00000000}));
        banner.addView(grad, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        int pad = dpk(14);
        col.setPadding(pad, dpk(8), pad, dpk(18));
        banner.addView(col, new FrameLayout.LayoutParams(-1, -1));

        bLabel = UI.text(this, "FILME EM DESTAQUE", spk(10), UI.WHITE, true);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0x99000000);
        pill.setCornerRadius(UI.dp(this, 14));
        pill.setStroke(UI.dp(this, 2), Theme.primary);
        bLabel.setBackground(pill);
        bLabel.setPadding(dpk(12), dpk(3), dpk(12), dpk(3));
        col.addView(bLabel, new LinearLayout.LayoutParams(-2, -2));
        bTitle = UI.text(this, "", spk(21), UI.WHITE, true);
        bTitle.setMaxLines(2);
        bTitle.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(bTitle, UI.lp(-2, -2, 4, this));
        bMeta = UI.text(this, "", spk(11), 0xFFEADFC9, false);
        bMeta.setSingleLine(true);
        col.addView(bMeta, new LinearLayout.LayoutParams(-2, -2));
        bPlot = UI.text(this, "", spk(11), 0xFFD7D0C4, false);
        bPlot.setMaxLines(3);
        bPlot.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2);
        plp.topMargin = dpk(3);
        col.addView(bPlot, plp);
        LinearLayout btns = new LinearLayout(this);
        btns.addView(ninjaButton("▶  ASSISTIR AGORA", true, this::watchFeatured));
        btns.addView(ninjaButton("ⓘ  MAIS INFORMAÇÕES", false, this::infoFeatured));
        col.addView(btns, UI.lp(-2, -2, 6, this));

        dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dlp.bottomMargin = dpk(6);
        banner.addView(dots, dlp);
        return banner;
    }

    private View ninjaButton(String label, boolean strong, final Runnable r) {
        TextView t = UI.text(this, label, spk(11), UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setFocusable(true); t.setClickable(true);
        int ph = dpk(14), pv = dpk(7);
        t.setPadding(ph, pv, ph, pv);
        GradientDrawable g = new GradientDrawable();
        g.setColor(strong ? 0x66FF8A00 : 0x99000000);
        g.setCornerRadius(UI.dp(this, 18 * Theme.radius));
        g.setStroke(UI.dp(this, 2), strong ? Theme.primary : 0xCCFFFFFF);
        t.setBackground(g);
        t.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dpk(10);
        t.setLayoutParams(lp);
        return t;
    }

    /** Destaques reais: filmes mais recentes do servidor (os 5 melhores avaliados entre os 30 últimos). */
    private void loadFeatured() {
        Repo.async(() -> {
            List<Item> out = new ArrayList<>();
            for (String kind : new String[]{"vod", "series"}) {
                List<Item> src = new ArrayList<>();
                for (Item i : Repo.items(kind, null)) if (i.cover != null && !i.cover.isEmpty()) src.add(i);
                Collections.sort(src, (a, b2) -> Long.compare(b2.added, a.added));
                List<Item> top = new ArrayList<>(src.subList(0, Math.min(30, src.size())));
                Collections.sort(top, (a, b2) -> Double.compare(b2.rating, a.rating));
                for (Item i : top) { if (out.size() < 5) out.add(i); }
                if (out.size() >= 5) break;
            }
            return out;
        }, new Repo.Result<List<Item>>() {
            @Override public void ok(List<Item> v) {
                featured.clear(); featured.addAll(v);
                buildDots();
                h.removeCallbacks(rotate);
                if (featured.isEmpty()) { bLabel.setVisibility(View.GONE); bTitle.setText(""); bMeta.setText(""); bPlot.setText(""); return; }
                showFeatured(0);
                h.postDelayed(rotate, 9_000);
            }
            @Override public void fail(String e) { }
        });
    }

    private void buildDots() {
        dots.removeAllViews();
        for (int i = 0; i < featured.size(); i++) {
            final int idx = i;
            View d = new View(this);
            d.setFocusable(true);
            d.setOnClickListener(v -> showFeatured(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpk(8), dpk(8));
            lp.setMargins(dpk(4), 0, dpk(4), 0);
            dots.addView(d, lp);
        }
    }

    private void paintDots() {
        for (int i = 0; i < dots.getChildCount(); i++)
            dots.getChildAt(i).setBackground(UI.round(this, i == fIndex ? Theme.primary : 0x66FFFFFF, 8));
    }

    private void showFeatured(int i) {
        if (i < 0 || i >= featured.size()) return;
        fIndex = i;
        final Item it = featured.get(i);
        paintDots();
        bLabel.setVisibility(View.VISIBLE);
        bLabel.setText("series".equals(it.kind) ? "SÉRIE EM DESTAQUE" : "FILME EM DESTAQUE");
        bTitle.setText(it.name);
        bMeta.setText(it.rating > 0 ? "★ " + String.format(Locale.US, "%.1f", it.rating) : "");
        bPlot.setText(it.plot == null ? "" : it.plot);
        bBg.setVisibility(View.GONE);
        bPoster.setVisibility(View.VISIBLE);
        Glide.with(this).load(it.cover).centerCrop().into(bPoster);

        final Xtream x = Repo.xtream();
        if (x == null) return;
        Repo.async(() -> "series".equals(it.kind) ? x.seriesInfo(it.id) : x.vodInfo(it.id), new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject j) {
                if (featured.isEmpty() || fIndex >= featured.size() || featured.get(fIndex) != it) return;
                JSONObject info = j.optJSONObject("info");
                if (info == null) return;
                String plot = info.optString("plot", info.optString("description", ""));
                if (!plot.isEmpty()) bPlot.setText(plot);
                String genre = info.optString("genre", "");
                String rel = info.optString("releasedate", info.optString("releaseDate", info.optString("year", "")));
                String year = rel.length() >= 4 ? rel.substring(0, 4) : "";
                String rating = info.optString("rating", "");
                StringBuilder m = new StringBuilder();
                if (!genre.isEmpty()) m.append(genre);
                try { double rv = Double.parseDouble(rating); if (rv > 0) { if (m.length() > 0) m.append("  •  "); m.append("★ ").append(String.format(Locale.US, "%.1f", rv > 5.5 ? rv / 2 : rv)); } } catch (Exception ignored) { }
                if (m.length() > 0) bMeta.setText(m.toString());
                if (!year.isEmpty() && !it.name.contains(year)) bTitle.setText(it.name + " (" + year + ")");
                String back = "";
                JSONArray bd = info.optJSONArray("backdrop_path");
                if (bd != null && bd.length() > 0) back = bd.optString(0, "");
                if (!back.isEmpty()) {
                    bBg.setVisibility(View.VISIBLE);
                    bPoster.setVisibility(View.GONE);
                    Glide.with(HomeActivity.this).load(back).centerCrop().into(bBg);
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void watchFeatured() {
        if (featured.isEmpty()) return;
        Item it = featured.get(fIndex);
        if ("series".equals(it.kind)) { infoFeatured(); return; }
        ArrayList<Item> one = new ArrayList<>();
        one.add(it);
        Repo.playlist = one; Repo.playlistIndex = 0;
        startActivity(new Intent(this, PlayerActivity.class));
    }

    private void infoFeatured() {
        if (featured.isEmpty()) return;
        Repo.selected = featured.get(fIndex);
        startActivity(new Intent(this, DetailsActivity.class));
    }

    // ================================================================== assinatura + relógio/clima
    private View buildInfoRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout sub = new LinearLayout(this);
        sub.setGravity(Gravity.CENTER_VERTICAL);
        sub.setFocusable(true); sub.setClickable(true);
        sub.setBackground(panel(true));
        sub.setPadding(dpk(14), dpk(4), dpk(14), dpk(4));
        sub.addView(new IconView(this).set("crown", Theme.primary, 0xFFFFE08A), new LinearLayout.LayoutParams(dpk(30), dpk(30)));
        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        subTitle = UI.text(this, "", spk(14), Theme.primary, true);
        subTitle.setSingleLine(true);
        subDetail = UI.text(this, "", spk(11), UI.WHITE, false);
        subDetail.setSingleLine(true);
        st.addView(subTitle); st.addView(subDetail);
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(0, -2, 1);
        stl.leftMargin = dpk(10);
        sub.addView(st, stl);
        subDot = new View(this);
        sub.addView(subDot, new LinearLayout.LayoutParams(dpk(12), dpk(12)));
        sub.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        UI.scaleOnFocus(sub);
        row.addView(sub, new LinearLayout.LayoutParams(0, -1, 1.55f));

        LinearLayout clk = new LinearLayout(this);
        clk.setGravity(Gravity.CENTER_VERTICAL);
        clk.setBackground(panel(false));
        clk.setPadding(dpk(14), dpk(4), dpk(14), dpk(4));
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm a");
        clock.setTextColor(UI.WHITE); clock.setTextSize(spk(19)); clock.setTypeface(UI.font(true));
        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEE, d MMM"); date.setFormat12Hour("EEE, d MMM");
        date.setTextColor(UI.MUTED); date.setTextSize(spk(10)); date.setTypeface(UI.font(false));
        tcol.addView(clock); tcol.addView(date);
        clk.addView(tcol, new LinearLayout.LayoutParams(0, -2, 1));
        weatherIcon = new ImageView(this);
        clk.addView(weatherIcon, new LinearLayout.LayoutParams(dpk(26), dpk(26)));
        LinearLayout wcol = new LinearLayout(this);
        wcol.setOrientation(LinearLayout.VERTICAL);
        weatherText = UI.text(this, "--°C", spk(14), UI.WHITE, true);
        cityText = UI.text(this, "", spk(9), UI.MUTED, false);
        cityText.setSingleLine(true);
        wcol.addView(weatherText); wcol.addView(cityText);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.leftMargin = dpk(6);
        clk.addView(wcol, wl);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -1, 1f);
        cl.leftMargin = dpk(10);
        row.addView(clk, cl);
        return row;
    }

    private GradientDrawable panel(boolean gold) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC0B0B0B, 0xB0000000});
        g.setCornerRadius(UI.dp(this, 16 * Theme.radius));
        g.setStroke(UI.dp(this, gold ? 2 : 1), gold ? Theme.primary : 0x55FFB020);
        return g;
    }

    private static final SimpleDateFormat FMT = new SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", new Locale("pt", "BR"));

    /** Status real da assinatura (dados do servidor IPTV salvos no login e atualizados ao abrir). */
    private void updateSubscription() {
        boolean xt = "xtream".equals(Repo.mode());
        String st = Prefs.get("acc_status", ""), exp = Prefs.get("acc_exp", "");
        boolean unlimited = exp.isEmpty() || exp.equals("null");
        long expMs = 0;
        try { if (!unlimited) expMs = Long.parseLong(exp) * 1000L; } catch (Exception e) { unlimited = true; }
        boolean expired = !unlimited && expMs < System.currentTimeMillis();
        boolean active = !xt || (!expired && (st.isEmpty() || st.equalsIgnoreCase("active")));
        String title = active ? "ASSINATURA ATIVA" : (expired ? "ASSINATURA VENCIDA" : "ASSINATURA " + st.toUpperCase());
        String detail = !xt ? "Acesso por lista ativada" : (unlimited ? "Sem data de vencimento" : (expired ? "Venceu em " : "Válida até ") + FMT.format(new Date(expMs)));
        subTitle.setText(title);
        subTitle.setTextColor(active ? Theme.primary : 0xFFFF5A5F);
        subDetail.setText(detail);
        subDot.setBackground(UI.round(this, active ? 0xFF2FD27A : 0xFFFF5A5F, 12));
        bellDot.setVisibility(notifications().isEmpty() ? View.GONE : View.VISIBLE);
    }

    /** Atualiza validade/status direto no servidor IPTV. */
    private void refreshAccount() {
        final Xtream x = Repo.xtream();
        if (x == null) return;
        Repo.async(x::auth, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject j) {
                JSONObject ui = j.optJSONObject("user_info");
                if (ui == null) return;
                Prefs.put("acc_status", ui.optString("status"));
                Prefs.put("acc_exp", ui.optString("exp_date"));
                Prefs.put("acc_maxcon", ui.optString("max_connections"));
                updateSubscription();
            }
            @Override public void fail(String e) { }
        });
    }

    // ================================================================== notificações e conexão
    private List<String> notifications() {
        List<String> l = new ArrayList<>();
        String n = Cfg.get("home_notice", "");
        if (!n.isEmpty()) l.add("📢  " + n);
        if ("xtream".equals(Repo.mode())) {
            String exp = Prefs.get("acc_exp", "");
            try {
                long ms = Long.parseLong(exp) * 1000L;
                long left = ms - System.currentTimeMillis();
                if (left < 0) l.add("⚠  Sua assinatura venceu em " + FMT.format(new Date(ms)) + ".");
                else if (left <= 7L * 86_400_000L) {
                    long days = Math.max(1, left / 86_400_000L);
                    l.add("⏳  Sua assinatura vence em " + days + (days == 1 ? " dia" : " dias") + " (" + FMT.format(new Date(ms)) + ").");
                }
            } catch (Exception ignored) { }
        }
        return l;
    }

    private void showNotifications() {
        List<String> l = notifications();
        String msg = l.isEmpty() ? "Sem notificações." : TextUtils.join("\n\n", l);
        new AlertDialog.Builder(this).setTitle("Notificações").setMessage(msg).setPositiveButton(T.t("Fechar"), null).show();
    }

    private boolean isOnline() {
        try {
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) { return true; }
    }

    private void setOnline(boolean on) {
        if (wifiIcon == null) return;
        wifiIcon.set(on ? "wifi" : "wifi_off", on ? 0xFFFFFFFF : 0xFFFF5A5F, on ? Theme.primary : 0xFFFF5A5F);
    }

    // ================================================================== estrelas ninja
    private View buildStars() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setClipChildren(false);
        String[] kinds = {"live", "vod", "series", "anime", "kids", "sports"};
        int[] art = {R.drawable.star_live, R.drawable.star_vod, R.drawable.star_series, R.drawable.star_anime, R.drawable.star_kids, R.drawable.star_sports};
        String[] desc = {"TV ao vivo", "Filmes", "Séries", "Animes", "Kids", "Esportes"};
        for (int i = 0; i < kinds.length; i++) {
            final String kind = kinds[i];
            ImageView iv = new ImageView(this);
            iv.setImageResource(art[i]);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setAdjustViewBounds(false);
            iv.setFocusable(true); iv.setClickable(true);
            iv.setContentDescription(desc[i]);
            iv.setOnClickListener(v -> open(kind));
            iv.setOnFocusChangeListener((v, f) -> v.animate().scaleX(f ? 1.12f : 1f).scaleY(f ? 1.12f : 1f).setDuration(140).start());
            if (i == 0) firstStar = iv;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.setMargins(dpk(1), 0, dpk(1), 0);
            row.addView(iv, lp);
        }
        return row;
    }

    // ================================================================== ações
    private void open(String kind) {
        if (!Repo.loaded) { UI.toast(this, T.t("Atualizando conteúdo...")); return; }
        Intent i = new Intent(this, BrowseActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void loadContent(boolean force) {
        loading.setVisibility(View.VISIBLE);
        loading.setText(T.t("Atualizando conteúdo..."));
        Repo.load(this, force, new Repo.Listener() {
            @Override public void progress(String m) { loading.setText(T.t("Atualizando conteúdo...") + "\n" + m); }
            @Override public void done(String err) {
                if (err != null) {
                    new AlertDialog.Builder(HomeActivity.this).setMessage(err).setCancelable(false)
                            .setPositiveButton(T.t("Tentar novamente"), (d, w) -> loadContent(true))
                            .setNegativeButton(T.t("Sair da conta"), (d, w) -> logout()).show();
                    return;
                }
                loading.setVisibility(View.GONE);
                loadFeatured();
                if (firstStar != null) firstStar.requestFocus();
            }
        });
    }

    private void refreshWeather() {
        Repo.async(Weather::fetch, new Repo.Result<Weather.Info>() {
            @Override public void ok(Weather.Info w) {
                weatherText.setText(w.temp + "°C");
                cityText.setText(w.city);
                weatherIcon.setImageResource(Weather.icon(w));
            }
            @Override public void fail(String e) { weatherText.setText("--°C"); }
        });
    }

    /** Ativação remota: confere se o painel mudou a lista (DNS/URL) ou desativou o ID. */
    private void checkRemote() {
        if (!Prefs.bool("activated_remote", false)) return;
        Repo.async(Panel::activation, new Repo.Result<Panel.Activation>() {
            @Override public void ok(Panel.Activation a) {
                if (!a.active) { UI.toast(HomeActivity.this, "Ativação removida pelo painel."); logout(); return; }
                String rev = String.valueOf(a.revision);
                if (!rev.equals(Prefs.get("activation_rev", ""))) {
                    Prefs.put("activation_rev", rev);
                    final String url = a.m3u;
                    Repo.async(() -> { LoginActivity.completeFromUrl(url, true); return true; }, new Repo.Result<Boolean>() {
                        @Override public void ok(Boolean v) { loadContent(true); }
                        @Override public void fail(String e) { UI.toast(HomeActivity.this, e); }
                    });
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void logout() {
        Repo.logout(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override protected void onStart() {
        super.onStart();
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        setOnline(isOnline());
        try {
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { runOnUiThread(() -> setOnline(true)); }
                @Override public void onLost(Network n) { runOnUiThread(() -> setOnline(isOnline())); }
            };
            cm.registerNetworkCallback(new NetworkRequest.Builder().addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCb);
        } catch (Exception e) { netCb = null; }
    }

    @Override protected void onStop() {
        try { if (cm != null && netCb != null) cm.unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        netCb = null;
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        updateSubscription();
        if (!Repo.loaded && loading.getVisibility() != View.VISIBLE) loadContent(false);
        h.removeCallbacks(rotate);
        if (featured.size() > 1) h.postDelayed(rotate, 9_000);
    }

    @Override protected void onPause() { h.removeCallbacks(rotate); super.onPause(); }

    @Override protected void onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy(); }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Fechar " + Cfg.appName() + "?")
                .setPositiveButton(T.t("Fechar"), (d, w) -> finishAffinity())
                .setNegativeButton(T.t("Cancelar"), null).show();
    }
}
