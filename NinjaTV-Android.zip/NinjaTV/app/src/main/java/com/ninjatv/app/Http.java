package com.ninjatv.app;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import okhttp3.Dns;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Cliente HTTP compartilhado. */
public final class Http {
    public static final String UA = "NinjaTV/" + BuildConfig.VERSION_NAME + " (Android)";
    /**
     * Em dados móveis (4G/5G) muitas operadoras entregam IPv6; se o servidor IPTV/painel não atende IPv6 direito,
     * a conexão trava ou falha. Tentamos os endereços IPv4 primeiro e deixamos o IPv6 como reserva.
     */
    private static final Dns IPV4_FIRST = hostname -> {
        List<InetAddress> all = Dns.SYSTEM.lookup(hostname);
        List<InetAddress> out = new ArrayList<>(), v6 = new ArrayList<>();
        for (InetAddress a : all) { if (a instanceof Inet4Address) out.add(a); else v6.add(a); }
        out.addAll(v6);
        return out;
    };

    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .dns(IPV4_FIRST)
            .connectTimeout(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .readTimeout(45, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .connectionPool(new okhttp3.ConnectionPool(8, 5, TimeUnit.MINUTES))
            .build();
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private Http() {}
    public static OkHttpClient client() { return CLIENT; }

    public static class Result { public int code; public String body; }

    public static Result get(String url, String bearer) throws IOException {
        Request.Builder b = new Request.Builder().url(url).header("User-Agent", UA).header("Accept", "*/*");
        if (bearer != null && !bearer.isEmpty()) b.header("Authorization", "Bearer " + bearer);
        return run(b.build());
    }

    public static Result postJson(String url, String json, String bearer) throws IOException {
        Request.Builder b = new Request.Builder().url(url).header("User-Agent", UA)
                .post(RequestBody.create(json, JSON));
        if (bearer != null && !bearer.isEmpty()) b.header("Authorization", "Bearer " + bearer);
        return run(b.build());
    }

    private static Result run(Request req) throws IOException {
        try (Response r = CLIENT.newCall(req).execute()) {
            Result res = new Result();
            res.code = r.code();
            res.body = r.body() != null ? r.body().string() : "";
            return res;
        }
    }
}
