package com.ninjatv.app;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Depois do login: a pessoa escolhe se está no celular (vertical) ou na TV/TV Box (horizontal). */
public class DeviceActivity extends BaseActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final boolean change = getIntent().getBooleanExtra("change", false);
        boolean isTv = false;
        try {
            UiModeManager um = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
            isTv = um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
        } catch (Exception ignored) { }
        String current = Prefs.get("device_mode", "");

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        UI.background(bg);
        bg.setAlpha(0.45f);
        frame.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        frame.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        int p = UI.dp(this, 20);
        col.setPadding(p, p, p, p);
        sv.addView(col, new ScrollView.LayoutParams(-1, -1));
        frame.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        TextView title = UI.text(this, "Qual aparelho você está usando?", 22, UI.WHITE, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, new LinearLayout.LayoutParams(-2, -2));
        TextView sub = UI.text(this, "O app se adapta à sua tela. Você pode mudar isso depois em Ajustes.", 13, UI.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub, UI.lp(-2, -2, 6, this));

        // lado a lado na horizontal; empilhados na vertical
        boolean wide = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        LinearLayout opts = new LinearLayout(this);
        opts.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        opts.setGravity(Gravity.CENTER);
        col.addView(opts, UI.lp(-2, -2, 22, this));
        opts.addView(option("phone", "Celular", "Tela vertical, toque na tela", !isTv && !"tv".equals(current), "phone", wide), optLp(wide));
        opts.addView(option("tv", "TV / TV Box", "Tela horizontal, controle remoto", isTv || "tv".equals(current), "tv_play", wide), optLp(wide));
        setContentView(frame);
    }

    private LinearLayout.LayoutParams optLp(boolean wide) {
        int w = Math.min(UI.dp(this, 240), getResources().getDisplayMetrics().widthPixels - UI.dp(this, 48));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, -2);
        if (wide) lp.leftMargin = lp.rightMargin = UI.dp(this, 12); else lp.topMargin = lp.bottomMargin = UI.dp(this, 8);
        return lp;
    }

    private View option(final String mode, String label, String hint, boolean recommended, String icon, boolean wide) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setFocusable(true); c.setClickable(true);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC0B0B0B, 0xB0000000});
        g.setCornerRadius(UI.dp(this, 20 * Theme.radius));
        g.setStroke(UI.dp(this, 2), recommended ? Theme.primary : 0x44FFFFFF);
        c.setBackground(g);
        int p = UI.dp(this, 18);
        c.setPadding(p, p, p, p);
        c.addView(new IconView(this).set(icon, 0xFFFFFFFF, Theme.primary), new LinearLayout.LayoutParams(UI.dp(this, 64), UI.dp(this, 64)));
        TextView t = UI.text(this, label, 18, UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t, UI.lp(-2, -2, 8, this));
        TextView h = UI.text(this, hint, 12, UI.MUTED, false);
        h.setGravity(Gravity.CENTER);
        c.addView(h, UI.lp(-2, -2, 2, this));
        if (recommended) {
            TextView r = UI.text(this, "SUGERIDO", 10, Theme.primary, true);
            r.setGravity(Gravity.CENTER);
            c.addView(r, UI.lp(-2, -2, 6, this));
        }
        c.setOnClickListener(v -> choose(mode));
        UI.scaleOnFocus(c);
        return c;
    }

    private void choose(String mode) {
        Prefs.put("device_mode", mode);
        boolean change = getIntent().getBooleanExtra("change", false);
        Intent i = new Intent(this, (change || Repo.loggedIn()) ? HomeActivity.class : LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
