package com.ninjatv.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Player oficial do Spotify (embed). Sem conta, toca prévias; para ouvir completo, a pessoa entra
 * na conta Spotify (Premium) dentro do próprio player. O app não toca áudio do Spotify por conta própria.
 */
public class SpotifyPlayerActivity extends BaseActivity {
    private WebView web;
    private LinearLayout root;
    private String type = "", id = "";

    @Override protected boolean recreatesOnRotate() { return false; }

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        type = String.valueOf(getIntent().getStringExtra("type"));
        id = String.valueOf(getIntent().getStringExtra("id"));
        if (!type.matches("^(playlist|album|track|artist)$") || !id.matches("^[A-Za-z0-9]{22}$")) { finish(); return; }
        String title = getIntent().getStringExtra("title");

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        int p = UI.dp(this, 12);
        root.setPadding(p, p, p, p);
        LinearLayout bar = UI.topBar(this, title == null || title.isEmpty() ? "Spotify" : title);
        TextView open = UI.button(this, "Abrir no Spotify", () -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/" + type + "/" + id))); } catch (Exception e) { UI.toast(this, "https://open.spotify.com/" + type + "/" + id); }
        });
        bar.addView(open);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = UI.text(this, "Sem conta, toca prévias. Para ouvir completo, entre na sua conta Spotify Premium aqui no player.", 11, UI.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, UI.lp(-1, -2, 6, this));

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setBackgroundColor(0xFF000000);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                String host = r.getUrl().getHost();
                boolean ok = host != null && (host.endsWith("spotify.com") || host.endsWith("scdn.co") || host.endsWith("spotifycdn.com"));
                if (ok) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) { }
                return true;
            }
        });
        root.addView(web, UI.lp(-1, 0, 8, this));
        ((LinearLayout.LayoutParams) web.getLayoutParams()).weight = 1;
        setContentView(root);
        web.loadUrl("https://open.spotify.com/embed/" + type + "/" + id + "?utm_source=generator&theme=0");
    }

    @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

    @Override protected void onDestroy() {
        if (web != null) { root.removeView(web); web.destroy(); web = null; }
        super.onDestroy();
    }
}
