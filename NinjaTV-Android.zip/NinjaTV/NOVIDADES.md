# Novidades
- Login com cartão translúcido (vidro) sobre o vídeo de fundo.
- YouTube e Spotify abrem o site oficial dentro do app (WebAppActivity): TV usa youtube.com/tv; celular m.youtube.com; Spotify usa open.spotify.com. Sem chaves de API; o usuário entra na própria conta.
- Destaque da Home na TV: capa/backdrop cobrindo o banner inteiro.
- Teste/anuidade: LicenseGate consulta api/license.php; se vencido, desloga e abre ExpiredActivity (QR + ID).
- Aba "Ativar por código" do login agora aponta para SEU-PAINEL/cliente.
- Não foi compilado (sem Android SDK aqui). Se o Gradle apontar erro, envie a mensagem.
