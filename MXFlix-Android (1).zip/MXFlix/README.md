# MXFlix — projeto Android Studio

Player IPTV (Xtream Codes / M3U) para celular, tablet e Android TV, integrado ao painel web **MXFlix Painel**.

## 1) Abrir e configurar
1. Android Studio (Koala 2024.1 ou mais novo, JDK 17) → **Open** → pasta `MXFlix`.
2. Aguarde o *Gradle Sync* (baixa o Gradle 8.7 e as dependências; precisa de internet).
3. Em `app/build.gradle`, troque a linha:
   `buildConfigField "String", "PANEL_URL", "\"https://SEU-PAINEL.com\""`
   pela URL do seu painel (sem barra no final). Se deixar o padrão, o app pergunta a URL na 1ª abertura.
4. Se quiser outro nome de pacote: `applicationId` em `app/build.gradle` (o código usa `com.mxflix.app`).

## 2) Gerar APK e AAB
- **APK de teste:** Build → Build Bundle(s)/APK(s) → Build APK(s).
- **Release assinado (APK/AAB):** Build → Generate Signed Bundle / APK (cria o `.jks`), ou copie
  `keystore.properties.example` para `keystore.properties`, preencha e rode
  `Build → Generate Signed App Bundle`. Guarde o `.jks` e as senhas: sem eles não há como atualizar o app na Play Store.

## 3) O que o app faz
- Login por **usuário/senha** (servidores vêm do painel), **lista M3U**, **ativação remota por ID** (7 caracteres) e **teste grátis**.
- Ao Vivo (zapping cima/baixo, EPG agora/depois, fallback m3u8↔ts), Filmes, Séries (temporadas/episódios, próximo episódio automático), Favoritos, Continuar assistindo, Busca global.
- Controle parental com PIN (sincronizado com o painel), categorias ocultas, conteúdo adulto protegido.
- Clima (Open-Meteo), aviso/marquee, cores, logo, fundo, suporte (WhatsApp/Telegram/QR) controlados pelo painel.
- Senha IPTV guardada com AES-GCM no Android Keystore; cache do catálogo em SQLite.
- Funciona com toque e com controle remoto (Android TV).

## 4) Observações
- O projeto foi escrito sem acesso ao SDK Android neste ambiente: **não foi compilado**. Se o Sync/Build apontar algum erro, me envie a mensagem que eu corrijo.
- O app **não traz nenhum conteúdo**: ele reproduz a lista/servidor que você cadastrar no painel. Use apenas conteúdo que você tem direito de distribuir.
- Para Play Store: política de privacidade, ícone/screenshots e declaração de conteúdo são por sua conta.

## Linha de comando (gradlew)
- Linux/macOS: `./gradlew assembleDebug` (APK) ou `./gradlew bundleRelease` (AAB)
- Windows: `gradlew.bat assembleDebug`
Na 1ª execução o script baixa o Gradle 8.7 sozinho (precisa de internet e JDK 17+).
APK debug: `app/build/outputs/apk/debug/app-debug.apk` · AAB: `app/build/outputs/bundle/release/app-release.aab`
