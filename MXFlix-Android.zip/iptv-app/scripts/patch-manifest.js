// Permite conexões http:// (a maioria dos servidores IPTV não usa https)
const fs = require('fs');
const p = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(p, 'utf8');
if (!x.includes('usesCleartextTraffic')) {
  x = x.replace('<application', '<application android:usesCleartextTraffic="true"');
  fs.writeFileSync(p, x);
}
console.log('Manifest OK');
