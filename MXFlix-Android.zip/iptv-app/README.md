# IPTV Info (app Android)

## Jeito mais fácil: gerar o APK na nuvem (sem instalar nada)
1. Crie uma conta grátis em github.com e um repositório novo (pode ser privado).
2. Envie TODOS os arquivos desta pasta para o repositório (botão "Add file > Upload files"). Mantenha a pasta `.github`.
3. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow**.
4. Espere uns 5 a 10 minutos, abra a execução concluída e baixe **IPTV-Info-APK** no fim da página.
5. Descompacte, passe o `app-debug.apk` para o celular e instale (permita "fontes desconhecidas").

## Jeito local (PC com Node 20, Java 17 e Android Studio/SDK)
```
npm install
npx cap add android
node scripts/patch-manifest.js
npx cap sync android
cd android && ./gradlew assembleDebug
```
O APK fica em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- O app faz as consultas direto do celular, por isso não há bloqueio de CORS.
- As listas salvas ficam apenas no aparelho. Use "Copiar backup" na aba Salvas.
- Para mudar o visual, edite `www/index.html`.
