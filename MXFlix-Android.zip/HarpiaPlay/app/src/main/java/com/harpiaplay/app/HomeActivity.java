package com.harpiaplay.app;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

/** Tela inicial: cards lado a lado; o selecionado "levanta", com ícones em vez de imagens. */
public class HomeActivity extends AppCompatActivity {
    private static final class Card {
        String kind; FrameLayout root; TextView title, sub, foot; IconView icon; View tab;
    }

    private final List<Card> cards = new ArrayList<>();
    private int selected = 0, lift;
    private TextView loading, weatherText, cityText;
    private ImageView weatherIcon;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        lift = UI.dp(this, 18);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        UI.background(bg);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{UI.alpha(0xCC), UI.alpha(0xF2)}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        root.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 18);
        content.setPadding(p, p / 2, p, p / 2);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        // ---- cabeçalho: logo no centro; ajustes e perfil à direita
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        UI.logo(logo);
        brand.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 40), UI.dp(this, 40)));
        TextView name = UI.text(this, Cfg.appName(), 20, UI.WHITE, true);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
        nl.leftMargin = UI.dp(this, 10);
        brand.addView(name, nl);
        head.addView(brand);
        LinearLayout right = new LinearLayout(this);
        right.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        right.addView(roundIcon("gear", () -> startActivity(new Intent(this, SettingsActivity.class))));
        right.addView(roundIcon("user", () -> startActivity(new Intent(this, AccountActivity.class))));
        head.addView(right, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // ---- aviso do painel
        String notice = Cfg.get("home_notice", "");
        if (!notice.isEmpty()) {
            TextView n = UI.text(this, "📢  " + notice, 13, Cfg.primary(), false);
            n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.MARQUEE);
            n.setMarqueeRepeatLimit(-1); n.setSelected(true);
            content.addView(n, UI.lp(-1, -2, 6, this));
        }

        // ---- cards lado a lado (o 4º aparece "espiando" para indicar que dá para rolar)
        int cardW = (int) Math.max(UI.dp(this, 150), Math.min(UI.dp(this, 240), (dm.widthPixels - 2 * p) / 3.35f));
        int cardH = (int) Math.min(cardW * 1.02f, dm.heightPixels * 0.5f);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, lift + UI.dp(this, 8), 0, UI.dp(this, 10));
        LinearLayout row = new LinearLayout(this);
        row.setClipChildren(false);
        scroll.addView(row, new FrameLayout.LayoutParams(-2, -2));

        List<String> kinds = new ArrayList<>();
        kinds.add("live"); kinds.add("vod"); kinds.add("series");
        if (YouTube.enabled()) kinds.add("youtube");
        kinds.add("fav"); kinds.add("history");
        for (int i = 0; i < kinds.size(); i++) {
            Card c = makeCard(kinds.get(i), i, cardW, cardH);
            cards.add(c);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cardW, cardH);
            lp.rightMargin = UI.dp(this, 14);
            row.addView(c.root, lp);
        }
        FrameLayout holder = new FrameLayout(this);
        holder.setClipChildren(false);
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(-1, -2);
        sl.gravity = Gravity.CENTER_VERTICAL;
        holder.addView(scroll, sl);
        content.addView(holder, new LinearLayout.LayoutParams(-1, 0, 1));

        // ---- barra inferior: busca à esquerda; hora, data e clima à direita
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(searchPill());
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        weatherIcon = new ImageView(this);
        bar.addView(weatherIcon, new LinearLayout.LayoutParams(UI.dp(this, 26), UI.dp(this, 26)));
        LinearLayout wcol = new LinearLayout(this);
        wcol.setOrientation(LinearLayout.VERTICAL);
        weatherText = UI.text(this, "--°C", 14, UI.WHITE, true);
        cityText = UI.text(this, "", 10, UI.MUTED, false);
        wcol.addView(weatherText); wcol.addView(cityText);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.leftMargin = UI.dp(this, 6); wl.rightMargin = UI.dp(this, 18);
        bar.addView(wcol, wl);
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.setGravity(Gravity.END);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm a");
        clock.setTextColor(UI.WHITE); clock.setTextSize(22); clock.setTypeface(UI.font(true));
        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEE, d MMM"); date.setFormat12Hour("EEE, d MMM");
        date.setTextColor(UI.MUTED); date.setTextSize(11); date.setTypeface(UI.font(false));
        tcol.addView(clock); tcol.addView(date);
        bar.addView(tcol);
        content.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        loading = UI.text(this, T.t("Atualizando conteúdo..."), 15, UI.WHITE, true);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundColor(UI.alpha(0xE6));
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        select(0, false);
        updateCards();
        loadContent(false);
        refreshWeather();
        checkRemote();
        Repo.async(Panel::config, new Repo.Result<org.json.JSONObject>() {
            @Override public void ok(org.json.JSONObject v) { }
            @Override public void fail(String e) { }
        });
    }

    // ------------------------------------------------------------------ componentes
    private View roundIcon(String icon, final Runnable r) {
        FrameLayout f = new FrameLayout(this);
        f.setFocusable(true); f.setClickable(true);
        f.setBackground(UI.focusBg(this, UI.SURFACE2, 20));
        IconView iv = new IconView(this).set(icon, IconSet.mainColor(), IconSet.accentColor());
        f.addView(iv, new FrameLayout.LayoutParams(UI.dp(this, 22), UI.dp(this, 22), Gravity.CENTER));
        f.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UI.dp(this, 40), UI.dp(this, 40));
        lp.leftMargin = UI.dp(this, 10);
        f.setLayoutParams(lp);
        return f;
    }

    private View searchPill() {
        LinearLayout l = new LinearLayout(this);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setFocusable(true); l.setClickable(true);
        l.setBackground(UI.focusBg(this, UI.SURFACE2, 20));
        int ph = UI.dp(this, 14), pv = UI.dp(this, 9);
        l.setPadding(ph, pv, ph + UI.dp(this, 4), pv);
        l.addView(new IconView(this).set("search", IconSet.mainColor(), IconSet.accentColor()), new LinearLayout.LayoutParams(UI.dp(this, 20), UI.dp(this, 20)));
        TextView t = UI.text(this, T.t("Busca"), 13, UI.WHITE, true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = UI.dp(this, 8);
        l.addView(t, tl);
        l.setOnClickListener(v -> open("search"));
        UI.scaleOnFocus(l);
        return l;
    }

    private GradientDrawable glass(boolean sel) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{(0xCC << 24) | (UI.SURFACE2 & 0xFFFFFF), (0xB4 << 24) | (UI.SURFACE & 0xFFFFFF)});
        g.setCornerRadius(UI.dp(this, 20 * Theme.radius));
        if (sel) g.setStroke(UI.dp(this, 2), Theme.primary); else g.setStroke(UI.dp(this, 1), 0x26FFFFFF);
        return g;
    }

    private Card makeCard(final String kind, final int index, int w, int h) {
        final Card c = new Card();
        c.kind = kind;
        FrameLayout f = new FrameLayout(this);
        f.setFocusable(true); f.setClickable(true);
        f.setClipChildren(false);
        c.root = f;
        int pad = UI.dp(this, 14);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        c.title = UI.text(this, titleFor(kind), 17, 0xFFFFFFFF, true);
        c.title.setMaxLines(2); c.title.setEllipsize(TextUtils.TruncateAt.END);
        c.sub = UI.text(this, "", 12, UI.MUTED, false);
        texts.addView(c.title); texts.addView(c.sub);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.START);
        tl.setMargins(pad, pad, pad, 0);
        f.addView(texts, tl);

        int isz = (int) (w * 0.4f);
        c.icon = new IconView(this).set(IconSet.idFor(kind), IconSet.mainColor(), IconSet.accentColor());
        FrameLayout.LayoutParams il = new FrameLayout.LayoutParams(isz, isz, Gravity.BOTTOM | Gravity.END);
        il.setMargins(0, 0, pad, pad + UI.dp(this, 6));
        f.addView(c.icon, il);

        c.foot = UI.text(this, "", 10, UI.MUTED, false);
        c.foot.setSingleLine(true);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        fl.setMargins(pad, 0, 0, pad);
        f.addView(c.foot, fl);

        // "aba" de destaque que aparece no card selecionado
        c.tab = new View(this);
        c.tab.setBackground(UI.round(this, Theme.primary, 3));
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams((int) (w * 0.38f), UI.dp(this, 5), Gravity.TOP | Gravity.START);
        bl.leftMargin = pad;
        c.tab.setLayoutParams(bl);
        c.tab.setTranslationY(-UI.dp(this, 3));
        c.tab.setVisibility(View.GONE);
        f.addView(c.tab);

        f.setBackground(glass(false));
        f.setOnClickListener(v -> { select(index, true); open(kind); });
        f.setOnFocusChangeListener((v, focused) -> { if (focused) select(index, true); });
        f.setOnTouchListener((v, e) -> { if (e.getAction() == MotionEvent.ACTION_DOWN) select(index, true); return false; });
        return c;
    }

    private String titleFor(String kind) {
        switch (kind) {
            case "live": return T.t("Ao Vivo");
            case "vod": return T.t("Filmes");
            case "series": return T.t("Séries");
            case "youtube": return "YouTube";
            case "fav": return T.t("Favoritos");
            default: return T.t("Continuar assistindo");
        }
    }

    /** O card selecionado "levanta", cresce um pouco e ganha contorno e aba coloridos. */
    private void select(int index, boolean animate) {
        selected = index;
        for (int i = 0; i < cards.size(); i++) {
            Card c = cards.get(i);
            boolean s = i == index;
            float ty = s ? -lift : 0f, sc = s ? 1.05f : 1f;
            if (animate) c.root.animate().translationY(ty).scaleX(sc).scaleY(sc).setDuration(170).start();
            else { c.root.setTranslationY(ty); c.root.setScaleX(sc); c.root.setScaleY(sc); }
            c.root.setBackground(glass(s));
            c.tab.setVisibility(s ? View.VISIBLE : View.GONE);
            c.root.setElevation(s ? UI.dp(this, 6) : 0f);
        }
    }

    private String ago() {
        long t = Prefs.lng("net_loaded_at", 0);
        if (t == 0) return "";
        long m = (System.currentTimeMillis() - t) / 60000;
        if (m < 1) return "Atualizado agora";
        if (m < 60) return "Atualizado há " + m + " min";
        long h = m / 60;
        if (h < 48) return "Atualizado há " + h + " h";
        return "Atualizado há " + (h / 24) + " d";
    }

    private static String fmt(int n, String one, String many, String zero) {
        if (n < 0) return "—";
        if (n == 0 && zero != null) return zero;
        String num = java.text.NumberFormat.getIntegerInstance(new java.util.Locale("pt", "BR")).format(n);
        return num + " " + (n == 1 ? one : many);
    }

    /** Rodapés e contagens reais dos cards (calculadas fora da tela principal). */
    private void updateCards() {
        for (Card c : cards) {
            switch (c.kind) {
                case "live": case "vod": case "series": c.foot.setText(ago()); break;
                case "youtube": c.sub.setText("Vídeos e trailers"); break;
                default: break;
            }
        }
        Repo.async(() -> {
            int[] n = new int[5];
            n[0] = Repo.loaded ? Repo.items("live", null).size() : -1;
            n[1] = Repo.loaded ? Repo.items("vod", null).size() : -1;
            n[2] = Repo.loaded ? Repo.items("series", null).size() : -1;
            n[3] = Repo.loggedIn() ? Store.get(this).favorites(Repo.session(), null).size() : -1;
            n[4] = Repo.loggedIn() ? Store.get(this).history(Repo.session(), true).size() : -1;
            return n;
        }, new Repo.Result<int[]>() {
            @Override public void ok(int[] n) {
                for (Card c : cards) {
                    switch (c.kind) {
                        case "live": c.sub.setText(fmt(n[0], "canal", "canais", null)); break;
                        case "vod": c.sub.setText(fmt(n[1], "filme", "filmes", null)); break;
                        case "series": c.sub.setText(fmt(n[2], "série", "séries", null)); break;
                        case "fav": c.sub.setText(fmt(n[3], "favorito", "favoritos", null)); break;
                        case "history": c.sub.setText(fmt(n[4], "em andamento", "em andamento", "nenhum em andamento")); break;
                        default: break;
                    }
                }
            }
            @Override public void fail(String e) { }
        });
    }

    // ------------------------------------------------------------------ ações
    private void open(String kind) {
        if ("youtube".equals(kind)) { startActivity(new Intent(this, YouTubeActivity.class)); return; }
        if (!Repo.loaded) { UI.toast(this, T.t("Atualizando conteúdo...")); return; }
        Intent i = new Intent(this, BrowseActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void loadContent(boolean force) {
        loading.setVisibility(View.VISIBLE);
        loading.setText(T.t("Atualizando conteúdo..."));
        Repo.load(this, force, new Repo.Listener() {
            @Override public void progress(String m) { loading.setText(T.t("Atualizando conteúdo...") + "\n" + m); }
            @Override public void done(String err) {
                if (err != null) {
                    new AlertDialog.Builder(HomeActivity.this).setMessage(err).setCancelable(false)
                            .setPositiveButton(T.t("Tentar novamente"), (d, w) -> loadContent(true))
                            .setNegativeButton(T.t("Sair da conta"), (d, w) -> logout()).show();
                    return;
                }
                loading.setVisibility(View.GONE);
                updateCards();
                if (!cards.isEmpty()) cards.get(selected).root.requestFocus();
            }
        });
    }

    private void refreshWeather() {
        Repo.async(Weather::fetch, new Repo.Result<Weather.Info>() {
            @Override public void ok(Weather.Info w) {
                weatherText.setText(w.temp + "°C");
                cityText.setText(w.city);
                weatherIcon.setImageResource(Weather.icon(w));
            }
            @Override public void fail(String e) { weatherText.setText("--°C"); }
        });
    }

    /** Ativação remota: confere se o painel mudou a lista (DNS/URL) ou desativou o ID. */
    private void checkRemote() {
        if (!Prefs.bool("activated_remote", false)) return;
        Repo.async(Panel::activation, new Repo.Result<Panel.Activation>() {
            @Override public void ok(Panel.Activation a) {
                if (!a.active) { UI.toast(HomeActivity.this, "Ativação removida pelo painel."); logout(); return; }
                String rev = String.valueOf(a.revision);
                if (!rev.equals(Prefs.get("activation_rev", ""))) {
                    Prefs.put("activation_rev", rev);
                    final String url = a.m3u;
                    Repo.async(() -> { LoginActivity.completeFromUrl(url, true); return true; }, new Repo.Result<Boolean>() {
                        @Override public void ok(Boolean v) { loadContent(true); }
                        @Override public void fail(String e) { UI.toast(HomeActivity.this, e); }
                    });
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void logout() {
        Repo.logout(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        updateCards();
        if (!Repo.loaded && loading.getVisibility() != View.VISIBLE) loadContent(false);
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Fechar " + Cfg.appName() + "?")
                .setPositiveButton(T.t("Fechar"), (d, w) -> finishAffinity())
                .setNegativeButton(T.t("Cancelar"), null).show();
    }
}
