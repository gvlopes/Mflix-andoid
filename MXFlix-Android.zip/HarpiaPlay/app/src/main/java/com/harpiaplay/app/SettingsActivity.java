package com.harpiaplay.app;

import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Ajustes organizados por seção. */
public class SettingsActivity extends BaseActivity {
    private LinearLayout col;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(UI.BG);
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(outer, new ScrollView.LayoutParams(-1, -2));
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        col.setPadding(p, p, p, p * 2);
        outer.addView(col, new LinearLayout.LayoutParams(UI.dp(this, 620), -2));
        setContentView(sv);
        build();
    }

    private LinearLayout section(String title) {
        TextView h = UI.text(this, title.toUpperCase(), 11, Cfg.primary(), true);
        h.setLetterSpacing(0.12f);
        col.addView(h, UI.lp(-2, -2, 22, this));
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(UI.round(this, UI.SURFACE, 16));
        col.addView(g, UI.lp(-1, -2, 8, this));
        return g;
    }

    private void row(LinearLayout group, String title, String subtitle, String value, final Runnable r) {
        if (group.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(0x1AFFFFFF);
            group.addView(d, new LinearLayout.LayoutParams(-1, 1));
        }
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true); row.setClickable(true);
        row.setBackground(UI.focusBg(this, 0x00000000, 16));
        int pad = UI.dp(this, 16);
        row.setPadding(pad, UI.dp(this, 14), pad, UI.dp(this, 14));
        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.addView(UI.text(this, title, 15, UI.WHITE, true));
        if (subtitle != null) txt.addView(UI.text(this, subtitle, 12, UI.MUTED, false));
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1));
        if (value != null) {
            TextView chip = UI.text(this, value, 12, Cfg.primary(), true);
            chip.setBackground(UI.round(this, UI.SURFACE2, 10));
            int cp = UI.dp(this, 10);
            chip.setPadding(cp, UI.dp(this, 5), cp, UI.dp(this, 5));
            row.addView(chip);
        }
        row.setOnClickListener(v -> r.run());
        group.addView(row);
    }

    private void build() {
        col.removeAllViews();
        col.addView(UI.topBar(this, T.t("Ajustes")));

        LinearLayout content = section("Conteúdo");
        row(content, T.t("Atualizar conteúdo"), "Baixa de novo canais, filmes e séries", null, () -> {
            UI.toast(this, T.t("Atualizando conteúdo..."));
            Repo.load(this, true, new Repo.Listener() {
                @Override public void progress(String m) { }
                @Override public void done(String err) { UI.toast(SettingsActivity.this, err == null ? "OK ✓" : err); }
            });
        });
        row(content, T.t("Categorias ocultas"), "Escolha o que não quer ver nas listas", null, this::hiddenCategories);
        row(content, T.t("Limpar cache"), "Favoritos e histórico são preservados", null, () -> { Store.get(this).clearCache(); UI.toast(this, "Cache limpo."); });
        row(content, T.t("Limpar histórico"), "Apaga o “continuar assistindo”", null, () -> { Store.get(this).clearHistory(Repo.session()); UI.toast(this, "OK ✓"); });

        LinearLayout play = section("Reprodução");
        row(play, T.t("Formato ao vivo"), "TS inicia mais rápido; M3U8 é o mais compatível", Repo.liveFormat().toUpperCase(), () -> {
            Prefs.put("live_format", "m3u8".equals(Repo.liveFormat()) ? "ts" : "m3u8");
            build();
        });
        row(play, T.t("Avançar episódio automaticamente"), "Toca o próximo episódio ao terminar", Prefs.bool("autoplay_next", true) ? "LIGADO" : "DESLIGADO", () -> {
            Prefs.putBool("autoplay_next", !Prefs.bool("autoplay_next", true));
            build();
        });

        LinearLayout parental = section(T.t("Controle parental"));
        row(parental, "PIN", "Protege conteúdo adulto", Repo.hasPin() ? "DEFINIDO" : "NÃO DEFINIDO", this::changePin);
        if (Repo.hasPin()) row(parental, "Remover PIN", null, null, () -> UI.askPin(this, () -> { Prefs.remove("pin_hash"); build(); }));
        row(parental, T.t("Conteúdo adulto"), "Mostra categorias adultas nas listas", Prefs.bool("show_adult", false) ? "LIGADO" : "DESLIGADO", () -> {
            if (Prefs.bool("show_adult", false)) { Prefs.putBool("show_adult", false); build(); return; }
            UI.askPin(this, () -> { Prefs.putBool("show_adult", true); build(); });
        });

        LinearLayout about = section("Sobre");
        row(about, Cfg.appName(), "ID do aparelho: " + Panel.friendlyId(), "v" + BuildConfig.VERSION_NAME, () -> new AlertDialog.Builder(this)
                .setMessage(Cfg.appName() + " " + BuildConfig.VERSION_NAME + "\nPainel: " + Panel.baseUrl() + "\n" + T.t("ID do aparelho") + ": " + Panel.friendlyId())
                .setPositiveButton(T.t("Fechar"), null).show());
    }

    private void changePin() {
        if (Repo.hasPin()) UI.askPin(this, this::newPin); else newPin();
    }

    private void newPin() {
        final EditText e = UI.input(this, "4-8", true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("PIN").setView(UI.pad(this, e))
                .setPositiveButton(T.t("Confirmar"), (d, w) -> {
                    String pin = e.getText().toString().trim();
                    if (!pin.matches("\\d{4,8}")) { UI.toast(this, "PIN: 4 a 8 dígitos."); return; }
                    Prefs.put("pin_hash", Repo.sha256(pin));
                    Panel.syncPin(pin);
                    build();
                }).setNegativeButton(T.t("Cancelar"), null).show();
    }

    private void hiddenCategories() {
        final List<String> keys = new ArrayList<>(), labels = new ArrayList<>();
        for (Cat c : Repo.liveCats) { keys.add("live:" + c.id); labels.add(T.t("Ao Vivo") + " · " + c.name); }
        for (Cat c : Repo.vodCats) { keys.add("vod:" + c.id); labels.add(T.t("Filmes") + " · " + c.name); }
        for (Cat c : Repo.seriesCats) { keys.add("series:" + c.id); labels.add(T.t("Séries") + " · " + c.name); }
        if (keys.isEmpty()) { UI.toast(this, T.t("Nenhum resultado.")); return; }
        final Set<String> hidden = Repo.hiddenCats();
        final boolean[] checked = new boolean[keys.size()];
        for (int i = 0; i < keys.size(); i++) checked[i] = hidden.contains(keys.get(i));
        new AlertDialog.Builder(this).setTitle(T.t("Categorias ocultas"))
                .setMultiChoiceItems(labels.toArray(new String[0]), checked, (d, i, on) -> checked[i] = on)
                .setPositiveButton(T.t("Confirmar"), (d, w) -> {
                    Set<String> s = new HashSet<>();
                    for (int i = 0; i < keys.size(); i++) if (checked[i]) s.add(keys.get(i));
                    Repo.setHiddenCats(s);
                }).setNegativeButton(T.t("Cancelar"), null).show();
    }
}
