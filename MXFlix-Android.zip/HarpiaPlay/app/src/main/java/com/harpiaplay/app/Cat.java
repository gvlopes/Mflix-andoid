package com.harpiaplay.app;

public class Cat {
    public final String id;
    public final String name;
    public Cat(String id, String name) { this.id = id; this.name = name; }
}
