package com.harpiaplay.app;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Tradução simples: o texto-base é português; en/es são opcionais (fallback = português). */
public final class T {
    private static final Map<String, String[]> M = new HashMap<>();
    private static void a(String pt, String en, String es) { M.put(pt, new String[]{en, es}); }
    static {
        a("Ao Vivo", "Live TV", "En vivo");
        a("Filmes", "Movies", "Películas");
        a("Séries", "Series", "Series");
        a("Favoritos", "Favorites", "Favoritos");
        a("Continuar assistindo", "Continue watching", "Continuar viendo");
        a("Busca", "Search", "Buscar");
        a("Ajustes", "Settings", "Ajustes");
        a("Conta", "Account", "Cuenta");
        a("Entrar", "Sign in", "Entrar");
        a("ENTRAR", "SIGN IN", "ENTRAR");
        a("Usuário", "Username", "Usuario");
        a("Senha", "Password", "Contraseña");
        a("Servidor", "Server", "Servidor");
        a("Lista M3U", "M3U list", "Lista M3U");
        a("Ativação por ID", "Activate by ID", "Activación por ID");
        a("Usuário e senha", "Username & password", "Usuario y contraseña");
        a("GERAR TESTE GRÁTIS", "GET FREE TRIAL", "PRUEBA GRATIS");
        a("Carregando...", "Loading...", "Cargando...");
        a("Atualizando conteúdo...", "Updating content...", "Actualizando contenido...");
        a("Atualizar conteúdo", "Refresh content", "Actualizar contenido");
        a("Limpar cache", "Clear cache", "Borrar caché");
        a("Limpar histórico", "Clear history", "Borrar historial");
        a("Cancelar", "Cancel", "Cancelar");
        a("Confirmar", "Confirm", "Confirmar");
        a("Fechar", "Close", "Cerrar");
        a("Sair da conta", "Sign out", "Cerrar sesión");
        a("Assistir", "Watch", "Ver");
        a("Continuar", "Continue", "Continuar");
        a("Favoritar", "Add to favorites", "Añadir a favoritos");
        a("Favorito ✓", "Favorite ✓", "Favorito ✓");
        a("Temporada", "Season", "Temporada");
        a("Episódio", "Episode", "Episodio");
        a("Buscar canais, filmes e séries", "Search channels, movies and series", "Buscar canales, películas y series");
        a("Nenhum resultado.", "No results.", "Sin resultados.");
        a("Controle parental", "Parental control", "Control parental");
        a("PIN incorreto.", "Wrong PIN.", "PIN incorrecto.");
        a("Digite o PIN", "Enter PIN", "Introduce el PIN");
        a("Formato ao vivo", "Live format", "Formato en vivo");
        a("Avançar episódio automaticamente", "Auto-play next episode", "Reproducir siguiente episodio");
        a("Conteúdo adulto", "Adult content", "Contenido adulto");
        a("Categorias ocultas", "Hidden categories", "Categorías ocultas");
        a("Suporte", "Support", "Soporte");
        a("Expiração", "Expiration", "Vencimiento");
        a("Status", "Status", "Estado");
        a("ID do aparelho", "Device ID", "ID del dispositivo");
        a("Falha de conexão. Verifique a internet.", "Connection failed. Check your internet.", "Fallo de conexión. Revisa tu internet.");
        a("Falha na reprodução.", "Playback failed.", "Fallo de reproducción.");
        a("Tentar novamente", "Try again", "Reintentar");
        a("Áudio e legendas", "Audio & subtitles", "Audio y subtítulos");
        a("Agora", "Now", "Ahora");
        a("A seguir", "Next", "Siguiente");
        a("Sem programação", "No schedule", "Sin programación");
    }
    private T() {}
    public static String t(String pt) {
        String l = Locale.getDefault().getLanguage();
        String[] v = M.get(pt);
        if (v == null) return pt;
        if ("en".equals(l) && v[0] != null) return v[0];
        if ("es".equals(l) && v[1] != null) return v[1];
        return pt;
    }
}
