package com.harpiaplay.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/** Busca de vídeos do YouTube (início, busca, favoritos e histórico). */
public class YouTubeActivity extends BaseActivity {
    private ItemAdapter adapter;
    private EditText search;
    private TextView status;
    private String mode = "home";
    private long reqId = 0;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        int p = UI.dp(this, 14);
        root.setPadding(p, p, p, 0);

        root.addView(UI.topBar(this, "YouTube"), new LinearLayout.LayoutParams(-1, -2));

        search = UI.input(this, "Buscar no YouTube", false);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setOnEditorActionListener((v, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER && ev.getAction() == KeyEvent.ACTION_DOWN)) {
                doSearch();
                return true;
            }
            return false;
        });
        root.addView(search, UI.lp(-1, -2, 8, this));

        LinearLayout tabs = new LinearLayout(this);
        tabs.addView(tab("Início", () -> { mode = "home"; load(); }));
        tabs.addView(tab(T.t("Favoritos"), () -> { mode = "fav"; load(); }));
        tabs.addView(tab("Histórico", () -> { mode = "history"; load(); }));
        root.addView(tabs, UI.lp(-2, -2, 8, this));

        status = UI.text(this, "", 13, UI.MUTED, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, UI.lp(-1, -2, 8, this));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int cardDp = 200;
        int span = Math.max(2, (dm.widthPixels - UI.dp(this, 28)) / UI.dp(this, cardDp + 12));
        RecyclerView grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, span));
        adapter = new ItemAdapter(cardDp, (it, pos) -> play(it), (it, pos) -> toggleFav(it));
        grid.setAdapter(adapter);
        root.addView(grid, UI.lp(-1, 0, 8, this));
        ((LinearLayout.LayoutParams) grid.getLayoutParams()).weight = 1;
        setContentView(root);
        load();
    }

    private View tab(String label, Runnable r) {
        TextView t = UI.button(this, label, r);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = UI.dp(this, 8);
        t.setLayoutParams(lp);
        return t;
    }

    private void doSearch() {
        String q = search.getText().toString().trim();
        if (q.length() < 2) { UI.toast(this, "Digite pelo menos 2 letras."); return; }
        mode = "search";
        load();
    }

    private void load() {
        final long id = ++reqId;
        if ("fav".equals(mode) || "history".equals(mode)) {
            List<Item> src = "fav".equals(mode) ? Store.get(this).favorites(Repo.session(), "yt") : new ArrayList<Item>();
            if ("history".equals(mode)) for (Item i : Store.get(this).history(Repo.session(), false)) if ("yt".equals(i.kind)) src.add(i);
            adapter.set(src);
            status.setText(src.isEmpty() ? T.t("Nenhum resultado.") : "");
            return;
        }
        final String q = "search".equals(mode) ? search.getText().toString().trim() : "";
        status.setText(T.t("Carregando..."));
        adapter.set(new ArrayList<Item>());
        Repo.async(() -> YouTube.search(q), new Repo.Result<List<Item>>() {
            @Override public void ok(List<Item> v) {
                if (id != reqId) return;
                adapter.set(v);
                status.setText(v.isEmpty() ? T.t("Nenhum resultado.") : "");
            }
            @Override public void fail(String e) { if (id == reqId) status.setText(e); }
        });
    }

    private void play(Item it) {
        Store.get(this).progress(Repo.session(), it, 0, 0);       // entra no histórico
        Intent i = new Intent(this, YouTubePlayerActivity.class);
        i.putExtra("id", it.id);
        i.putExtra("title", it.name);
        startActivity(i);
    }

    private void toggleFav(Item it) {
        boolean on = Store.get(this).toggleFavorite(Repo.session(), it);
        UI.toast(this, on ? "Adicionado aos favoritos" : "Removido dos favoritos");
        if ("fav".equals(mode)) load();
    }
}
