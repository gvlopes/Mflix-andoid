package com.harpiaplay.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;

public class App extends Application {
    private static final long CHECK_MS = 10_000;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Activity current;
    private boolean checking = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() { check(); handler.postDelayed(this, CHECK_MS); }
    };

    @Override public void onCreate() {
        super.onCreate();
        Prefs.init(this);
        AppConfig.init(this);
        Theme.load();
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityResumed(Activity a) {
                current = a;
                handler.removeCallbacks(tick);
                handler.postDelayed(tick, 1500);
            }
            @Override public void onActivityPaused(Activity a) {
                if (current == a) { current = null; handler.removeCallbacks(tick); }
            }
            @Override public void onActivityCreated(Activity a, Bundle b) { }
            @Override public void onActivityStarted(Activity a) { }
            @Override public void onActivityStopped(Activity a) { }
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
            @Override public void onActivityDestroyed(Activity a) { }
        });
    }

    private static String sig() {
        StringBuilder sb = new StringBuilder();
        for (String k : new String[]{"card_live", "card_vod", "card_series", "card_fav", "card_history", "logo", "background", "app_name"}) sb.append(Cfg.get(k, "")).append('|');
        return sb.toString();
    }

    /** Enquanto o app está aberto, confere o painel (tema e imagens); se algo mudou, aplica e redesenha a tela. */
    private void check() {
        if (checking || current == null || !Panel.isConfigured()) return;
        checking = true;
        Repo.async(() -> {
            boolean changed = false;
            try {
                JSONObject t = Panel.theme();
                if (!t.optString("rev", "").equals(Theme.rev)) { Theme.save(t); changed = true; }
            } catch (Exception ignored) { }
            try {
                String before = sig();
                Panel.config();
                if (!before.equals(sig())) changed = true;
            } catch (Exception ignored) { }
            return changed;
        }, new Repo.Result<Boolean>() {
            @Override public void ok(Boolean changed) {
                checking = false;
                Activity a = current;
                // não interrompe o vídeo nem a digitação do login; essas telas pegam as mudanças na próxima abertura
                if (changed && a != null && !(a instanceof PlayerActivity) && !(a instanceof LoginActivity) && !(a instanceof SplashActivity)) a.recreate();
            }
            @Override public void fail(String e) { checking = false; }
        });
    }
}
