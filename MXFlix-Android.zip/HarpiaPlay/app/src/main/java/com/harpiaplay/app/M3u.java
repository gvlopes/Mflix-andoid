package com.harpiaplay.app;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parser de listas M3U/M3U8 (#EXTINF). */
public final class M3u {
    private M3u() {}
    public static class Result {
        public final List<Item> live = new ArrayList<>(), vod = new ArrayList<>(), series = new ArrayList<>();
        public final Map<String, Cat> liveCats = new LinkedHashMap<>(), vodCats = new LinkedHashMap<>(), seriesCats = new LinkedHashMap<>();
    }
    private static final Pattern ATTR = Pattern.compile("([a-zA-Z0-9_-]+)=\"([^\"]*)\"");
    private static final Pattern SERIES_G = Pattern.compile(".*(s[eé]rie|series|novela|anime|doram).*", Pattern.CASE_INSENSITIVE);
    private static final Pattern VOD_G = Pattern.compile(".*(filme|movie|vod|cinema|lan[cç]amento).*", Pattern.CASE_INSENSITIVE);

    public static Result parse(String text) {
        Result r = new Result();
        String[] lines = text.split("\\r?\\n");
        String name = null, logo = "", group = "", tvgId = "";
        int n = 0;
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF:")) {
                logo = ""; group = ""; tvgId = "";
                Matcher m = ATTR.matcher(line);
                while (m.find()) {
                    String k = m.group(1).toLowerCase();
                    if (k.equals("tvg-logo")) logo = m.group(2);
                    else if (k.equals("group-title")) group = m.group(2);
                    else if (k.equals("tvg-id")) tvgId = m.group(2);
                }
                int c = line.lastIndexOf(',');
                name = c >= 0 ? line.substring(c + 1).trim() : "Canal";
            } else if (!line.startsWith("#") && name != null) {
                Item it = new Item();
                it.id = String.valueOf(++n);
                it.name = name.isEmpty() ? "Canal " + n : name;
                it.cover = logo;
                it.url = line;
                it.epgId = tvgId;
                if (group.isEmpty()) group = "Geral";
                it.catId = group;
                String low = line.toLowerCase();
                if (low.contains("/series/") || SERIES_G.matcher(group).matches()) {
                    it.kind = "series"; r.series.add(it); r.seriesCats.put(group, new Cat(group, group));
                } else if (low.contains("/movie/") || VOD_G.matcher(group).matches() || low.matches(".*\\.(mp4|mkv|avi)(\\?.*)?$")) {
                    it.kind = "vod"; r.vod.add(it); r.vodCats.put(group, new Cat(group, group));
                } else {
                    it.kind = "live"; r.live.add(it); r.liveCats.put(group, new Cat(group, group));
                }
                name = null;
            }
        }
        return r;
    }

    /** Se a URL for get.php?username=&password=, devolve {base, user, pass}; senão null. */
    public static String[] xtreamFromUrl(String url) {
        try {
            android.net.Uri u = android.net.Uri.parse(url);
            String path = u.getPath() == null ? "" : u.getPath();
            String user = u.getQueryParameter("username"), pass = u.getQueryParameter("password");
            if (user == null || pass == null || !path.toLowerCase().endsWith("/get.php")) return null;
            String base = u.getScheme() + "://" + u.getAuthority() + path.substring(0, path.length() - "/get.php".length());
            return new String[]{base, user, pass};
        } catch (Exception e) { return null; }
    }
}
