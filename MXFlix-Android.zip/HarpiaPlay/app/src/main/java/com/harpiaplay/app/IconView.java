package com.harpiaplay.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Desenha um ícone do IconSet em duas cores (principal + destaque). */
public class IconView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private IconSet.Def def;
    private int main = 0xFFFFFFFF, accent = 0xFFFFC400;

    public IconView(Context c) {
        super(c);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(1.6f);
    }

    public IconView set(String id, int mainColor, int accentColor) {
        def = IconSet.get(id);
        main = mainColor; accent = accentColor;
        invalidate();
        return this;
    }

    @Override protected void onDraw(Canvas c) {
        if (def == null) return;
        float s = Math.min(getWidth(), getHeight()) / 24f;
        c.save();
        c.translate((getWidth() - 24f * s) / 2f, (getHeight() - 24f * s) / 2f);
        c.scale(s, s);
        paint.setColor(main);
        for (Path p : def.main) c.drawPath(p, paint);
        paint.setColor(accent);
        for (Path p : def.accent) c.drawPath(p, paint);
        c.restore();
    }
}
