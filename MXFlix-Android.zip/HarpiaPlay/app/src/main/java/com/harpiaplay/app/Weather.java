package com.harpiaplay.app;

import android.net.Uri;
import org.json.JSONObject;

/** Clima atual via Open-Meteo (cidade do painel ou localização por IP). */
public final class Weather {
    private Weather() {}
    public static class Info { public int temp; public int code; public boolean day; public String city = ""; }

    public static Info fetch() throws Exception {
        long last = Prefs.lng("w_time", 0);
        if (System.currentTimeMillis() - last < 20 * 60_000L) {
            String c = Prefs.get("w_json", "");
            if (!c.isEmpty()) return parse(new JSONObject(c));
        }
        double lat, lon; String city = Cfg.get("weather_city", "");
        if (!city.isEmpty()) {
            Http.Result g = Http.get("https://geocoding-api.open-meteo.com/v1/search?name=" + Uri.encode(city) + "&count=1&language=pt", null);
            org.json.JSONArray r = new JSONObject(g.body).optJSONArray("results");
            if (r == null || r.length() == 0) throw new Exception("City not found");
            lat = r.getJSONObject(0).getDouble("latitude"); lon = r.getJSONObject(0).getDouble("longitude");
        } else {
            JSONObject ip = new JSONObject(Http.get("https://ipapi.co/json/", null).body);
            lat = ip.getDouble("latitude"); lon = ip.getDouble("longitude"); city = ip.optString("city", "");
        }
        Http.Result w = Http.get("https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon + "&current=temperature_2m,weather_code,is_day&timezone=auto", null);
        JSONObject j = new JSONObject(w.body); j.put("_city", city);
        Prefs.put("w_json", j.toString()); Prefs.putLong("w_time", System.currentTimeMillis());
        return parse(j);
    }

    private static Info parse(JSONObject j) throws Exception {
        JSONObject c = j.getJSONObject("current");
        Info i = new Info();
        i.temp = (int) Math.round(c.getDouble("temperature_2m"));
        i.code = c.optInt("weather_code", -1);
        i.day = c.optInt("is_day", 1) == 1;
        i.city = j.optString("_city", "");
        return i;
    }

    public static int icon(Info i) {
        int c = i.code;
        if (c == 0 || c == 1) return i.day ? R.drawable.weather_sun : R.drawable.weather_moon;
        if (c == 2 || c == 3) return R.drawable.weather_cloud;
        if (c == 45 || c == 48) return R.drawable.weather_fog;
        if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return R.drawable.weather_rain;
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return R.drawable.weather_snow;
        if (c >= 95) return R.drawable.weather_storm;
        return R.drawable.weather_unknown;
    }
}
