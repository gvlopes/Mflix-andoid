package com.harpiaplay.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.TrackSelectionDialogBuilder;
import java.util.ArrayList;
import java.util.List;

/** Player (Media3/ExoPlayer) para canais, filmes e episódios, com retomada e próximo episódio. */
@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends BaseActivity {
    private ExoPlayer player;
    private PlayerView view;
    private TextView title, overlay, errorText, nextBtn, seekInfo;
    private LinearLayout topBar, errorBox;
    private List<Item> list = new ArrayList<>();
    private int index = 0;
    private Item cur;
    private boolean live = false, retriedFormat = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable saver = new Runnable() {
        @Override public void run() { saveProgress(); h.postDelayed(this, 5_000); }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() { updateNext(); h.postDelayed(this, 1_000); }
    };
    private final Runnable hideSeekInfo = () -> { if (seekInfo != null) seekInfo.setVisibility(View.GONE); };
    private final Runnable hideOverlay = () -> overlay.setVisibility(View.GONE);

    @Override protected boolean padForCutout() { return false; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        UI.fullscreen(this);
        list = new ArrayList<>(Repo.playlist);
        index = Repo.playlistIndex;
        if (list.isEmpty() || index < 0 || index >= list.size()) { finish(); return; }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        view = new PlayerView(this);
        view.setUseController(true);
        view.setControllerShowTimeoutMs(4000);
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        view.setShowRewindButton(true);
        view.setShowFastForwardButton(true);
        view.setShowNextButton(false);
        view.setShowPreviousButton(false);
        root.addView(view, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(0x99000000);
        int p = UI.dp(this, 12);
        topBar.setPadding(p, p / 2, p, p / 2);
        topBar.addView(UI.button(this, "←", this::finish));
        title = UI.text(this, "", 16, UI.WHITE, true);
        title.setSingleLine(true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1);
        tl.leftMargin = p;
        topBar.addView(title, tl);
        topBar.addView(UI.button(this, "🔊 " + T.t("Áudio e legendas"), this::trackMenu));
        FrameLayout.LayoutParams tbl = new FrameLayout.LayoutParams(-1, -2);
        tbl.gravity = Gravity.TOP;
        root.addView(topBar, tbl);
        topBar.setVisibility(View.GONE);
        view.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) vis -> topBar.setVisibility(vis == View.VISIBLE ? View.VISIBLE : View.GONE));

        overlay = UI.text(this, "", 16, UI.WHITE, true);
        overlay.setBackgroundColor(UI.alpha(0xCC));
        overlay.setPadding(p * 2, p, p * 2, p);
        overlay.setVisibility(View.GONE);
        FrameLayout.LayoutParams ol = new FrameLayout.LayoutParams(-2, -2);
        ol.gravity = Gravity.BOTTOM | Gravity.START;
        ol.setMargins(p * 2, 0, 0, p * 4);
        root.addView(overlay, ol);

        errorBox = new LinearLayout(this);
        errorBox.setOrientation(LinearLayout.VERTICAL);
        errorBox.setGravity(Gravity.CENTER);
        errorBox.setBackgroundColor(0xDD000000);
        errorText = UI.text(this, "", 15, UI.WHITE, false);
        errorText.setGravity(Gravity.CENTER);
        errorBox.addView(errorText);
        errorBox.addView(UI.primaryButton(this, T.t("Tentar novamente"), () -> playIndex(index)), UI.lp(-2, -2, 14, this));
        errorBox.addView(UI.button(this, T.t("Fechar"), this::finish), UI.lp(-2, -2, 8, this));
        errorBox.setVisibility(View.GONE);
        root.addView(errorBox, new FrameLayout.LayoutParams(-1, -1));

        // aviso rápido ao avançar/voltar 10 s
        seekInfo = UI.text(this, "", 22, 0xFFFFFFFF, true);
        seekInfo.setBackgroundColor(0xAA000000);
        seekInfo.setPadding(p * 2, p, p * 2, p);
        seekInfo.setVisibility(View.GONE);
        root.addView(seekInfo, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        // botão "Próximo episódio" (aparece nos últimos segundos do episódio)
        nextBtn = UI.primaryButton(this, "Próximo episódio ▶", () -> {
            nextBtn.setVisibility(View.GONE);
            retriedFormat = false;
            playIndex(index + 1);
        });
        nextBtn.setVisibility(View.GONE);
        FrameLayout.LayoutParams nbl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        nbl.setMargins(0, 0, p * 2, p * 6);
        root.addView(nextBtn, nbl);

        // toque duplo: esquerda volta 10 s, direita avança 10 s (filmes e episódios)
        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (live) return false;
                seekBy(e.getX() > view.getWidth() / 2f ? 10_000 : -10_000);
                return true;
            }
        });
        view.setOnTouchListener((v, e) -> { gd.onTouchEvent(e); return false; });
        setContentView(root);

        // Início quase instantâneo: conexões OkHttp reaproveitadas (keep-alive/HTTP2) e buffer mínimo
        // de apenas 0,4 s para começar (1,2 s após travar), mantendo até 50 s à frente.
        OkHttpDataSource.Factory http = new OkHttpDataSource.Factory(Http.client()).setUserAgent(Http.UA);
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(12_000, 50_000, 400, 1_200)
                .setPrioritizeTimeOverSizeThresholds(true)
                .setBackBuffer(0, false)
                .build();
        DefaultRenderersFactory rf = new DefaultRenderersFactory(this).setEnableDecoderFallback(true);
        player = new ExoPlayer.Builder(this, rf)
                .setLoadControl(lc)
                .setSeekBackIncrementMs(10_000)
                .setSeekForwardIncrementMs(10_000)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(new DefaultDataSource.Factory(this, http)))
                .setAudioAttributes(AudioAttributes.DEFAULT, true)
                .setHandleAudioBecomingNoisy(true)
                .build();
        view.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) errorBox.setVisibility(View.GONE);
                if (state == Player.STATE_ENDED) onEnded();
            }
            @Override public void onPlayerError(PlaybackException e) { onError(e); }
        });
        playIndex(index);
    }

    private void playIndex(int i) {
        if (i < 0 || i >= list.size()) return;
        saveProgress();
        index = i;
        cur = list.get(i);
        live = "live".equals(cur.kind);
        errorBox.setVisibility(View.GONE);
        nextBtn.setVisibility(View.GONE);
        title.setText(cur.name);
        String url = Repo.playUrl(cur);
        if (url.isEmpty()) { showError(T.t("Falha na reprodução.")); return; }
        long pos = live ? 0 : Store.get(this).position(Repo.session(), cur.kind, cur.id);
        player.setMediaItem(new MediaItem.Builder().setUri(url).build(), pos > 5000 ? pos - 3000 : 0);
        player.prepare();
        player.setPlayWhenReady(true);
        final Item ci = cur; final long cp = pos; final String sess = Repo.session();
        new Thread(() -> Store.get(PlayerActivity.this).progress(sess, ci, cp, 0)).start();
        h.removeCallbacks(saver);
        h.removeCallbacks(tick);
        if (!live) { h.postDelayed(saver, 5_000); h.postDelayed(tick, 1_000); }
        if (live) showChannelInfo();
    }

    private void showChannelInfo() {
        final String head = (index + 1) + "  " + cur.name;
        overlay.setText(head);
        overlay.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideOverlay);
        h.postDelayed(hideOverlay, 5000);
        final Xtream x = Repo.xtream();
        if (x == null) return;
        final Item it = cur;
        Repo.async(() -> x.shortEpg(it.id), new Repo.Result<String[]>() {
            @Override public void ok(String[] e) {
                if (it != cur) return;
                StringBuilder sb = new StringBuilder(head);
                if (e.length > 0 && !e[0].isEmpty()) sb.append("\n").append(T.t("Agora")).append(": ").append(e[0]);
                if (e.length > 1 && !e[1].isEmpty()) sb.append("\n").append(T.t("A seguir")).append(": ").append(e[1]);
                overlay.setText(sb.toString());
            }
            @Override public void fail(String er) { }
        });
    }

    private void onEnded() {
        if (live) return;
        saveProgress();
        boolean auto = Prefs.bool("autoplay_next", true);
        if (auto && index + 1 < list.size()) playIndex(index + 1); else finish();
    }

    private void onError(PlaybackException e) {
        if (live && !retriedFormat && cur != null && cur.url.isEmpty() && "xtream".equals(Repo.mode())) {
            // tenta o outro formato de transmissão ao vivo (ts <-> m3u8) uma única vez
            retriedFormat = true;
            String other = "m3u8".equals(Repo.liveFormat()) ? "ts" : "m3u8";
            Xtream x = Repo.xtream();
            if (x != null) {
                player.setMediaItem(MediaItem.fromUri(x.liveUrl(cur.id, other)));
                player.prepare(); player.setPlayWhenReady(true);
                return;
            }
        }
        showError(T.t("Falha na reprodução.") + "\n" + (e.getErrorCodeName() == null ? "" : e.getErrorCodeName()));
        Panel.log("playback_error");
    }

    private void showError(String m) {
        errorText.setText(m);
        errorBox.setVisibility(View.VISIBLE);
        retriedFormat = false;
    }

    private void saveProgress() {
        if (cur == null || player == null || live) return;
        long dur = player.getDuration();
        long pos = player.getCurrentPosition();
        if (pos <= 0) return;
        // mesmo sem a duração (alguns servidores não informam), a posição é guardada
        Store.get(this).progress(Repo.session(), cur, pos, dur == C.TIME_UNSET ? 0 : dur);
    }

    /** Avança (+) ou volta (-) em milissegundos, com aviso na tela. */
    private void seekBy(long ms) {
        if (player == null || live) return;
        long t = player.getCurrentPosition() + ms;
        long dur = player.getDuration();
        if (dur != C.TIME_UNSET && dur > 0) t = Math.min(t, Math.max(0, dur - 1000));
        player.seekTo(Math.max(0, t));
        seekInfo.setText(ms > 0 ? "10 s ⏩" : "⏪ 10 s");
        seekInfo.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideSeekInfo);
        h.postDelayed(hideSeekInfo, 700);
    }

    /** Mostra "Próximo episódio" nos últimos 45 s do episódio (se houver um próximo). */
    private void updateNext() {
        if (player == null || live || cur == null || nextBtn == null) return;
        boolean hasNext = "episode".equals(cur.kind) && index + 1 < list.size();
        long dur = player.getDuration(), pos = player.getCurrentPosition();
        boolean near = hasNext && dur != C.TIME_UNSET && dur > 0 && dur - pos <= 45_000 && player.getPlaybackState() != Player.STATE_IDLE;
        if (near && nextBtn.getVisibility() != View.VISIBLE) { nextBtn.setVisibility(View.VISIBLE); nextBtn.requestFocus(); }
        else if (!near && nextBtn.getVisibility() == View.VISIBLE) nextBtn.setVisibility(View.GONE);
    }

    private void trackMenu() {
        final String[] opts = {"Áudio", "Legendas", "Qualidade"};
        new AlertDialog.Builder(this).setTitle(T.t("Áudio e legendas")).setItems(opts, (d, which) -> {
            int type = which == 0 ? C.TRACK_TYPE_AUDIO : which == 1 ? C.TRACK_TYPE_TEXT : C.TRACK_TYPE_VIDEO;
            new TrackSelectionDialogBuilder(this, opts[which], player, type).build().show();
        }).show();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            int k = e.getKeyCode();
            boolean ctrl = view.isControllerFullyVisible();
            if (live && (k == KeyEvent.KEYCODE_CHANNEL_UP || (!ctrl && k == KeyEvent.KEYCODE_DPAD_UP))) {
                if (index + 1 < list.size()) { retriedFormat = false; playIndex(index + 1); }
                return true;
            }
            if (live && (k == KeyEvent.KEYCODE_CHANNEL_DOWN || (!ctrl && k == KeyEvent.KEYCODE_DPAD_DOWN))) {
                if (index > 0) { retriedFormat = false; playIndex(index - 1); }
                return true;
            }
            if (!live && !ctrl && k == KeyEvent.KEYCODE_DPAD_LEFT) { seekBy(-10_000); return true; }
            if (!live && !ctrl && k == KeyEvent.KEYCODE_DPAD_RIGHT) { seekBy(10_000); return true; }
            if (k == KeyEvent.KEYCODE_BACK && ctrl) { view.hideController(); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override protected void onResume() { super.onResume(); UI.fullscreen(this); if (player != null) player.setPlayWhenReady(true); }

    @Override protected void onPause() {
        saveProgress();
        if (player != null) player.setPlayWhenReady(false);
        super.onPause();
    }

    @Override protected void onStop() {
        saveProgress();   // garante o ponto salvo mesmo se o app for fechado depois
        super.onStop();
    }

    @Override protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (player != null) { saveProgress(); player.release(); player = null; }
        super.onDestroy();
    }
}
