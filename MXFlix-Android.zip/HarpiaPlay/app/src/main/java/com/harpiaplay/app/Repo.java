package com.harpiaplay.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Repositório central: sessão, catálogo (Xtream ou M3U), filtros, URLs de reprodução. */
public final class Repo {
    private Repo() {}

    public interface Listener { void progress(String msg); void done(String error); }
    public interface Task<T> { T run() throws Exception; }
    public interface Result<T> { void ok(T value); void fail(String error); }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static final List<Cat> liveCats = new ArrayList<>(), vodCats = new ArrayList<>(), seriesCats = new ArrayList<>();
    public static final List<Item> live = new ArrayList<>(), vod = new ArrayList<>(), series = new ArrayList<>();
    public static boolean loaded = false;
    public static boolean adultUnlocked = false;

    /** Item selecionado para a tela de detalhes e playlist atual do player (evita Parcelable gigante). */
    public static Item selected;
    public static List<Item> playlist = new ArrayList<>();
    public static int playlistIndex = 0;

    public static <T> void async(final Task<T> t, final Result<T> r) {
        POOL.execute(() -> {
            try {
                final T v = t.run();
                MAIN.post(() -> r.ok(v));
            } catch (final Exception e) {
                final String m = e.getMessage() == null ? e.toString() : e.getMessage();
                MAIN.post(() -> r.fail(m));
            }
        });
    }

    // ------------------------------------------------------------ sessão
    public static boolean loggedIn() { return !Prefs.get("mode", "").isEmpty(); }
    public static String mode() { return Prefs.get("mode", ""); }

    public static Xtream xtream() {
        if (!"xtream".equals(mode())) return null;
        return new Xtream(Prefs.get("x_base", ""), Prefs.get("x_user", ""), Vault.decrypt(Prefs.get("x_pass", "")));
    }

    public static String session() {
        String raw = "xtream".equals(mode()) ? "x|" + Prefs.get("x_base", "") + "|" + Prefs.get("x_user", "") : "m|" + Prefs.get("m_url", "");
        try {
            byte[] h = MessageDigest.getInstance("SHA-1").digest(raw.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format("%02x", h[i]));
            return sb.toString();
        } catch (Exception e) { return "default"; }
    }

    public static void saveXtream(String base, String user, String pass) {
        Prefs.put("mode", "xtream");
        Prefs.put("x_base", base);
        Prefs.put("x_user", user);
        Prefs.put("x_pass", Vault.encrypt(pass));
        Prefs.remove("m_url");
    }

    public static void saveM3u(String url) {
        Prefs.put("mode", "m3u");
        Prefs.put("m_url", Vault.encrypt(url));
        Prefs.put("m_url_plain_hash", String.valueOf(url.hashCode()));
    }

    public static String m3uUrl() { return Vault.decrypt(Prefs.get("m_url", "")); }

    public static void logout(Context c) {
        Panel.log("logout");
        Prefs.remove("mode"); Prefs.remove("x_base"); Prefs.remove("x_user"); Prefs.remove("x_pass");
        Prefs.remove("m_url"); Prefs.remove("activation_rev"); Prefs.remove("acc_status"); Prefs.remove("acc_exp");
        Prefs.putBool("activated_remote", false);
        Prefs.remove("activation_token");
        clearMemory();
        Store.get(c).clearCache();
    }

    public static void clearMemory() {
        live.clear(); vod.clear(); series.clear(); liveCats.clear(); vodCats.clear(); seriesCats.clear();
        loaded = false; adultUnlocked = false;
    }

    // ------------------------------------------------------------ carga
    public static void load(final Context ctx, final boolean force, final Listener l) {
        POOL.execute(() -> {
            String err = null;
            try { doLoad(ctx.getApplicationContext(), force, l); }
            catch (Exception e) { err = e.getMessage() == null ? e.toString() : e.getMessage(); }
            final String fe = err;
            MAIN.post(() -> l.done(fe));
        });
    }

    private static void post(final Listener l, final String m) { MAIN.post(() -> l.progress(m)); }

    private static long ttl() {
        long h = 12;
        try { h = Long.parseLong(Cfg.get("refresh_hours", "12")); } catch (Exception ignored) { }
        if (h < 1) h = 1;
        return h * 3600_000L;
    }

    private static String fetchCached(Store st, String s, String ep, boolean force, Task<String> net) throws Exception {
        if (!force) { String c = st.getCache(s, ep, ttl()); if (c != null) return c; }
        try {
            String body = net.run();
            st.putCache(s, ep, body);
            Prefs.putLong("net_loaded_at", System.currentTimeMillis());
            return body;
        } catch (Exception e) {
            String stale = st.getCache(s, ep, Long.MAX_VALUE);
            if (stale != null) return stale;
            throw e;
        }
    }

    private static synchronized void doLoad(Context ctx, boolean force, Listener l) throws Exception {
        Store st = Store.get(ctx);
        String s = session();
        clearMemory();
        if ("xtream".equals(mode())) {
            final Xtream x = xtream();
            post(l, T.t("Carregando...") + " (1/6)");
            JSONArray lc = new JSONArray(fetchCached(st, s, "live_cats", force, () -> x.raw("get_live_categories", null)));
            post(l, "Canais (2/6)");
            JSONArray ls = new JSONArray(fetchCached(st, s, "live", force, () -> x.raw("get_live_streams", null)));
            post(l, "Filmes (3/6)");
            JSONArray vc = new JSONArray(fetchCached(st, s, "vod_cats", force, () -> x.raw("get_vod_categories", null)));
            JSONArray vs = new JSONArray(fetchCached(st, s, "vod", force, () -> x.raw("get_vod_streams", null)));
            post(l, "Séries (5/6)");
            JSONArray sc = new JSONArray(fetchCached(st, s, "series_cats", force, () -> x.raw("get_series_categories", null)));
            JSONArray ss = new JSONArray(fetchCached(st, s, "series", force, () -> x.raw("get_series", null)));
            cats(lc, liveCats); cats(vc, vodCats); cats(sc, seriesCats);
            for (int i = 0; i < ls.length(); i++) {
                JSONObject o = ls.optJSONObject(i); if (o == null) continue;
                Item it = new Item(); it.kind = "live"; it.id = o.optString("stream_id"); it.name = o.optString("name");
                it.cover = o.optString("stream_icon"); it.catId = o.optString("category_id"); it.epgId = o.optString("epg_channel_id");
                it.archive = o.optInt("tv_archive", 0) == 1;
                live.add(it);
            }
            for (int i = 0; i < vs.length(); i++) {
                JSONObject o = vs.optJSONObject(i); if (o == null) continue;
                Item it = new Item(); it.kind = "vod"; it.id = o.optString("stream_id"); it.name = o.optString("name");
                it.cover = o.optString("stream_icon"); it.catId = o.optString("category_id");
                it.ext = o.optString("container_extension", "mp4"); it.rating = o.optDouble("rating", 0);
                it.added = o.optLong("added", 0);
                vod.add(it);
            }
            for (int i = 0; i < ss.length(); i++) {
                JSONObject o = ss.optJSONObject(i); if (o == null) continue;
                Item it = new Item(); it.kind = "series"; it.id = o.optString("series_id"); it.name = o.optString("name");
                it.cover = o.optString("cover"); it.catId = o.optString("category_id"); it.plot = o.optString("plot");
                it.rating = o.optDouble("rating", 0); it.added = o.optLong("last_modified", 0);
                series.add(it);
            }
        } else if ("m3u".equals(mode())) {
            final String url = m3uUrl();
            post(l, T.t("Carregando...") + " M3U");
            String text = fetchCached(st, s, "m3u", force, () -> {
                Http.Result r = Http.get(url, null);
                if (r.code < 200 || r.code >= 300) throw new Exception("HTTP " + r.code);
                if (!r.body.contains("#EXTINF")) throw new Exception("Lista M3U inválida.");
                return r.body;
            });
            M3u.Result r = M3u.parse(text);
            live.addAll(r.live); vod.addAll(r.vod); series.addAll(r.series);
            liveCats.addAll(r.liveCats.values()); vodCats.addAll(r.vodCats.values()); seriesCats.addAll(r.seriesCats.values());
        } else {
            throw new Exception("Sem sessão ativa.");
        }
        loaded = true;
    }

    private static void cats(JSONArray a, List<Cat> out) {
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            out.add(new Cat(o.optString("category_id"), o.optString("category_name")));
        }
    }

    // ------------------------------------------------------------ filtros
    public static Set<String> hiddenCats() {
        Set<String> s = new HashSet<>();
        String raw = Prefs.get("hidden_" + session(), "");
        if (!raw.isEmpty()) for (String p : raw.split("\\|")) s.add(p);
        return s;
    }

    public static void setHiddenCats(Set<String> s) {
        StringBuilder sb = new StringBuilder();
        for (String p : s) { if (sb.length() > 0) sb.append('|'); sb.append(p); }
        Prefs.put("hidden_" + session(), sb.toString());
    }

    public static boolean showAdult() { return adultUnlocked || Prefs.bool("show_adult", false); }

    private static boolean catVisible(String kind, Cat c, Set<String> hidden) {
        if (hidden.contains(kind + ":" + c.id)) return false;
        return showAdult() || !Rules.adult(c.name);
    }

    public static List<Cat> cats(String kind) {
        List<Cat> src = "live".equals(kind) ? liveCats : "vod".equals(kind) ? vodCats : seriesCats;
        Set<String> h = hiddenCats();
        List<Cat> out = new ArrayList<>();
        for (Cat c : src) if (catVisible(kind, c, h)) out.add(c);
        return out;
    }

    private static String catName(String kind, String id) {
        List<Cat> src = "live".equals(kind) ? liveCats : "vod".equals(kind) ? vodCats : seriesCats;
        for (Cat c : src) if (c.id.equals(id)) return c.name;
        return "";
    }

    /** catId == null → todos os itens visíveis do tipo. */
    public static List<Item> items(String kind, String catId) {
        List<Item> src = "live".equals(kind) ? live : "vod".equals(kind) ? vod : series;
        Set<String> h = hiddenCats();
        boolean adultOk = showAdult();
        List<Item> out = new ArrayList<>();
        java.util.Map<String, Boolean> vis = new java.util.HashMap<>();
        for (Item i : src) {
            if (catId != null && !catId.equals(i.catId)) continue;
            Boolean v = vis.get(i.catId);
            if (v == null) {
                v = !h.contains(kind + ":" + i.catId) && (adultOk || !Rules.adult(catName(kind, i.catId)));
                vis.put(i.catId, v);
            }
            if (v) out.add(i);
        }
        return out;
    }

    public static List<Item> search(String q) {
        List<Item> out = new ArrayList<>();
        String n = q.toLowerCase(Locale.ROOT).trim();
        if (n.isEmpty()) return out;
        for (String k : new String[]{"live", "vod", "series"}) {
            for (Item i : items(k, null)) {
                if (i.name.toLowerCase(Locale.ROOT).contains(n)) { out.add(i); if (out.size() >= 300) return out; }
            }
        }
        return out;
    }

    // ------------------------------------------------------------ reprodução
    public static String liveFormat() { return Prefs.get("live_format", "ts"); }

    public static String playUrl(Item i) {
        if (i.url != null && !i.url.isEmpty()) return i.url;
        Xtream x = xtream();
        if (x == null) return "";
        if ("live".equals(i.kind)) return x.liveUrl(i.id, liveFormat());
        if ("episode".equals(i.kind)) return x.seriesUrl(i.id, i.ext);
        return x.movieUrl(i.id, i.ext);
    }

    // ------------------------------------------------------------ PIN
    public static String sha256(String s) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
    public static boolean hasPin() { return !Prefs.get("pin_hash", "").isEmpty(); }
    public static boolean checkPin(String pin) { return sha256(pin).equals(Prefs.get("pin_hash", "")); }
}
