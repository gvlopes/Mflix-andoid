package com.harpiaplay.app;

import android.net.Uri;
import android.text.Html;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Busca de vídeos do YouTube via painel (a chave da API fica no servidor, com cache). */
public final class YouTube {
    private YouTube() {}

    public static boolean enabled() { return !"0".equals(Cfg.get("youtube_enabled", "1")); }
    public static String homeQuery() { return Cfg.get("youtube_home_query", "filmes e séries trailers"); }

    /** query vazia = busca inicial configurada no painel. */
    public static List<Item> search(String query) throws Exception {
        String q = query == null ? "" : query.trim();
        JSONObject j = Panel.youtube(q);
        JSONObject d = j.optJSONObject("data");
        JSONArray a = d == null ? null : d.optJSONArray("items");
        List<Item> out = new ArrayList<>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String id = o.optString("id", "");
            if (!id.matches("^[A-Za-z0-9_-]{11}$")) continue;
            Item it = new Item();
            it.kind = "yt";
            it.id = id;
            it.name = Html.fromHtml(o.optString("title", "")).toString();
            it.plot = Html.fromHtml(o.optString("channel", "")).toString();
            it.cover = o.optString("thumb", "");
            out.add(it);
        }
        return out;
    }

    public static String watchUrl(String id) { return "https://www.youtube.com/watch?v=" + Uri.encode(id); }
}
