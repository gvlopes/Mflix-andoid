package com.harpiaplay.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DateFormat;
import java.util.Date;

public class AccountActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(UI.BG);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        col.setPadding(p, p, p, p);
        sv.addView(col);
        setContentView(sv);

        col.addView(UI.text(this, T.t("Conta"), 22, UI.WHITE, true));
        boolean xt = "xtream".equals(Repo.mode());
        if (xt) {
            info(col, T.t("Servidor"), Prefs.get("x_base", ""));
            info(col, T.t("Usuário"), Prefs.get("x_user", ""));
            info(col, T.t("Status"), Prefs.get("acc_status", "—"));
            info(col, T.t("Expiração"), expiration(Prefs.get("acc_exp", "")));
            String mc = Prefs.get("acc_maxcon", "");
            if (!mc.isEmpty()) info(col, "Conexões", mc);
        } else {
            info(col, T.t("Lista M3U"), "ativa");
        }
        info(col, T.t("ID do aparelho"), Panel.friendlyId());

        // suporte
        col.addView(UI.text(this, Cfg.get("support_name", T.t("Suporte")), 16, Cfg.primary(), true), UI.lp(-2, -2, 22, this));
        String text = Cfg.get("support_text", "");
        if (!text.isEmpty()) col.addView(UI.text(this, text, 13, UI.MUTED, false), UI.lp(-1, -2, 4, this));
        String qr = Cfg.get("support_qr", "");
        if (!qr.isEmpty()) {
            ImageView iv = new ImageView(this);
            iv.setBackgroundColor(0xFFFFFFFF);
            iv.setPadding(UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6));
            UI.image(iv, qr, R.drawable.hp_logo);
            LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(UI.dp(this, 150), UI.dp(this, 150));
            ql.topMargin = UI.dp(this, 10);
            col.addView(iv, ql);
        }
        String phone = Cfg.get("support_phone", "");
        String wa = !phone.isEmpty() ? "https://wa.me/" + phone : Cfg.get("support_whatsapp", "");
        if (!wa.isEmpty()) link(col, "WhatsApp", wa);
        String tg = Cfg.get("support_telegram_user", "");
        String tgUrl = !tg.isEmpty() ? "https://t.me/" + tg : Cfg.get("support_telegram", "");
        if (!tgUrl.isEmpty()) link(col, "Telegram", tgUrl);
        String lk = Cfg.get("support_link", "");
        if (!lk.isEmpty()) link(col, T.t("Suporte"), lk);

        col.addView(UI.button(this, T.t("Sair da conta"), () -> {
            Repo.logout(this);
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }), UI.lp(-1, -2, 26, this));
    }

    private void link(LinearLayout col, String label, final String url) {
        col.addView(UI.button(this, label, () -> UI.openUrl(this, url)), UI.lp(-1, -2, 10, this));
    }

    private void info(LinearLayout col, String k, String v) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(UI.text(this, k, 13, UI.MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(UI.text(this, v == null || v.isEmpty() ? "—" : v, 14, UI.WHITE, true));
        col.addView(r, UI.lp(-1, -2, 12, this));
    }

    private String expiration(String exp) {
        if (exp == null || exp.isEmpty() || exp.equals("null")) return "Ilimitado";
        try {
            long e = Long.parseLong(exp) * 1000L;
            String d = DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(e));
            return e < System.currentTimeMillis() ? "Expirou em " + d : d;
        } catch (Exception ex) { return exp; }
    }
}
