package com.harpiaplay.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;

/** Conta: perfil, dados da assinatura e suporte. */
public class AccountActivity extends BaseActivity {
    private LinearLayout col;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(UI.BG);
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(outer, new ScrollView.LayoutParams(-1, -2));
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        col.setPadding(p, p, p, p * 2);
        outer.addView(col, new LinearLayout.LayoutParams(UI.dp(this, 620), -2));
        setContentView(sv);

        col.addView(UI.topBar(this, T.t("Conta")));
        boolean xt = "xtream".equals(Repo.mode());

        // cartão do perfil
        LinearLayout prof = new LinearLayout(this);
        prof.setGravity(Gravity.CENTER_VERTICAL);
        prof.setBackground(UI.round(this, UI.SURFACE, 16));
        int pp = UI.dp(this, 18);
        prof.setPadding(pp, pp, pp, pp);
        LinearLayout av = new LinearLayout(this);
        av.setGravity(Gravity.CENTER);
        av.setBackground(UI.round(this, UI.SURFACE2, 30));
        av.addView(new IconView(this).set("user", IconSet.mainColor(), IconSet.accentColor()), new LinearLayout.LayoutParams(UI.dp(this, 30), UI.dp(this, 30)));
        prof.addView(av, new LinearLayout.LayoutParams(UI.dp(this, 56), UI.dp(this, 56)));
        LinearLayout who = new LinearLayout(this);
        who.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(0, -2, 1);
        wl.leftMargin = UI.dp(this, 14);
        prof.addView(who, wl);
        who.addView(UI.text(this, xt ? Prefs.get("x_user", "") : "Lista ativada", 18, UI.WHITE, true));
        String st = xt ? Prefs.get("acc_status", "") : "Ativa";
        who.addView(UI.text(this, expiration(Prefs.get("acc_exp", "")).isEmpty() || !xt ? st : st + " · " + expiration(Prefs.get("acc_exp", "")), 12, UI.MUTED, false));
        col.addView(prof, UI.lp(-1, -2, 18, this));

        // dados
        LinearLayout info = group("Assinatura");
        if (xt) {
            info(info, T.t("Status"), Prefs.get("acc_status", ""));
            info(info, T.t("Expiração"), expiration(Prefs.get("acc_exp", "")));
            String mc = Prefs.get("acc_maxcon", "");
            if (!mc.isEmpty()) info(info, "Conexões", mc);
            info(info, T.t("Servidor"), Prefs.get("x_base", ""));
        } else {
            info(info, T.t("Lista M3U"), "ativa");
        }
        info(info, T.t("ID do aparelho"), Panel.friendlyId());

        // suporte
        LinearLayout sup = group(Cfg.get("support_name", T.t("Suporte")));
        String text = Cfg.get("support_text", "");
        if (!text.isEmpty()) {
            TextView t = UI.text(this, text, 13, UI.MUTED, false);
            int tp = UI.dp(this, 16);
            t.setPadding(tp, tp, tp, UI.dp(this, 4));
            sup.addView(t);
        }
        String qr = Cfg.get("support_qr", "");
        if (!qr.isEmpty()) {
            ImageView iv = new ImageView(this);
            iv.setBackgroundColor(0xFFFFFFFF);
            iv.setPadding(UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6));
            UI.image(iv, qr, R.drawable.hp_logo);
            LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(UI.dp(this, 150), UI.dp(this, 150));
            ql.setMargins(UI.dp(this, 16), UI.dp(this, 8), 0, UI.dp(this, 8));
            sup.addView(iv, ql);
        }
        String phone = Cfg.get("support_phone", "");
        String wa = !phone.isEmpty() ? "https://wa.me/" + phone : Cfg.get("support_whatsapp", "");
        if (!wa.isEmpty()) link(sup, "WhatsApp", wa);
        String tg = Cfg.get("support_telegram_user", "");
        String tgUrl = !tg.isEmpty() ? "https://t.me/" + tg : Cfg.get("support_telegram", "");
        if (!tgUrl.isEmpty()) link(sup, "Telegram", tgUrl);
        String lk = Cfg.get("support_link", "");
        if (!lk.isEmpty()) link(sup, T.t("Suporte"), lk);

        TextView out = UI.button(this, T.t("Sair da conta"), () -> {
            Repo.logout(this);
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });
        out.setTextColor(0xFFFF8D90);
        col.addView(out, UI.lp(-1, -2, 26, this));
    }

    private LinearLayout group(String title) {
        TextView h = UI.text(this, title.toUpperCase(), 11, Cfg.primary(), true);
        h.setLetterSpacing(0.12f);
        col.addView(h, UI.lp(-2, -2, 22, this));
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(UI.round(this, UI.SURFACE, 16));
        col.addView(g, UI.lp(-1, -2, 8, this));
        return g;
    }

    private void link(LinearLayout g, String label, final String url) {
        View d = new View(this);
        d.setBackgroundColor(0x1AFFFFFF);
        g.addView(d, new LinearLayout.LayoutParams(-1, 1));
        TextView t = UI.text(this, label + "  ›", 15, UI.WHITE, true);
        int p = UI.dp(this, 16);
        t.setPadding(p, UI.dp(this, 14), p, UI.dp(this, 14));
        t.setFocusable(true); t.setClickable(true);
        t.setBackground(UI.focusBg(this, 0x00000000, 16));
        t.setOnClickListener(v -> UI.openUrl(this, url));
        g.addView(t);
    }

    private void info(LinearLayout g, String k, String v) {
        if (g.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(0x1AFFFFFF);
            g.addView(d, new LinearLayout.LayoutParams(-1, 1));
        }
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        int p = UI.dp(this, 16);
        r.setPadding(p, UI.dp(this, 13), p, UI.dp(this, 13));
        r.addView(UI.text(this, k, 13, UI.MUTED, false), new LinearLayout.LayoutParams(0, -2, 1));
        TextView val = UI.text(this, v == null || v.isEmpty() ? "—" : v, 14, UI.WHITE, true);
        val.setGravity(Gravity.END);
        val.setMaxWidth(UI.dp(this, 360));
        r.addView(val);
        g.addView(r);
    }

    private String expiration(String exp) {
        if (exp == null || exp.isEmpty() || exp.equals("null")) return "Ilimitado";
        try {
            long e = Long.parseLong(exp) * 1000L;
            String d = DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(e));
            return e < System.currentTimeMillis() ? "Expirou em " + d : d;
        } catch (Exception ex) { return exp; }
    }
}
