package com.harpiaplay.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import org.json.JSONTokener;

/** Player oficial do YouTube (IFrame API embutida em WebView). Reprodução e anúncios seguem as regras do YouTube. */
public class YouTubePlayerActivity extends AppCompatActivity {
    private WebView web;
    private FrameLayout root;
    private LinearLayout errorBox;
    private TextView errorText;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private String videoId = "";
    private final Handler h = new Handler(Looper.getMainLooper());
    private int polls = 0;
    private final Runnable poll = new Runnable() {
        @Override public void run() { snapshot(); polls++; h.postDelayed(this, polls < 15 ? 1000 : 4000); }
    };

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        UI.fullscreen(this);
        videoId = getIntent().getStringExtra("id");
        if (videoId == null || !videoId.matches("^[A-Za-z0-9_-]{11}$")) { finish(); return; }

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        web.setBackgroundColor(0xFF000000);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                String host = r.getUrl().getHost();
                return host == null || !(host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") || host.endsWith("google.com") || host.endsWith("gstatic.com"));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                customView = v; customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
            }
            @Override public void onHideCustomView() { hideCustom(); }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        TextView back = UI.button(this, "←", this::finish);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-2, -2);
        bl.gravity = Gravity.TOP | Gravity.START; bl.setMargins(UI.dp(this, 10), UI.dp(this, 10), 0, 0);
        root.addView(back, bl);

        errorBox = new LinearLayout(this);
        errorBox.setOrientation(LinearLayout.VERTICAL);
        errorBox.setGravity(Gravity.CENTER);
        errorBox.setBackgroundColor(0xE6000000);
        errorText = UI.text(this, "", 15, 0xFFFFFFFF, false);
        errorText.setGravity(Gravity.CENTER);
        int pad = UI.dp(this, 24);
        errorText.setPadding(pad, 0, pad, 0);
        errorBox.addView(errorText);
        errorBox.addView(UI.primaryButton(this, "Abrir no YouTube", () -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(YouTube.watchUrl(videoId)))); } catch (Exception e) { UI.toast(this, YouTube.watchUrl(videoId)); }
        }), UI.lp(-2, -2, 14, this));
        errorBox.addView(UI.button(this, T.t("Fechar"), this::finish), UI.lp(-2, -2, 8, this));
        errorBox.setVisibility(View.GONE);
        root.addView(errorBox, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        String origin = "https://" + getPackageName();       // identificação do app para o player do YouTube
        web.loadDataWithBaseURL(origin, html(videoId, origin), "text/html", "UTF-8", null);
        h.postDelayed(poll, 1500);
    }

    private static String html(String id, String origin) {
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<meta name='referrer' content='strict-origin-when-cross-origin'>"
                + "<style>html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden}iframe{border:0;width:100%;height:100%}</style></head><body>"
                + "<iframe id='player' title='YouTube player' referrerpolicy='strict-origin-when-cross-origin' src='https://www.youtube.com/embed/" + id
                + "?enablejsapi=1&origin=" + origin + "&autoplay=1&controls=1&rel=0&playsinline=1&fs=1' "
                + "allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe>"
                + "<script>var player;var st={ready:false,state:-1,error:0,autoplayBlocked:false};"
                + "function onYouTubeIframeAPIReady(){player=new YT.Player('player',{events:{onReady:function(){st.ready=true;},"
                + "onStateChange:function(e){st.state=e.data;},onError:function(e){st.error=e.data;},onAutoplayBlocked:function(){st.autoplayBlocked=true;}}});}"
                + "window.ytSnapshot=function(){var s=Object.assign({},st);if(st.ready){try{s.time=player.getCurrentTime();s.duration=player.getDuration();s.state=player.getPlayerState();}catch(e){}}return s;};"
                + "window.ytCommand=function(a){if(!st.ready)return;if(a==='toggle'){player.getPlayerState()===1?player.pauseVideo():player.playVideo();}"
                + "else if(a==='forward'){player.seekTo(player.getCurrentTime()+10,true);}else if(a==='rewind'){player.seekTo(Math.max(0,player.getCurrentTime()-10),true);}else if(a==='pause'){player.pauseVideo();}};"
                + "</script><script src='https://www.youtube.com/iframe_api'></script></body></html>";
    }

    private void cmd(String a) { if (web != null) web.evaluateJavascript("window.ytCommand&&window.ytCommand('" + a + "')", null); }

    /** Lê o estado do player; mostra mensagem se o YouTube recusou a reprodução. */
    private void snapshot() {
        if (web == null) return;
        web.evaluateJavascript("window.ytSnapshot?JSON.stringify(window.ytSnapshot()):'{}'", value -> {
            try {
                Object o = new JSONTokener(value).nextValue();
                JSONObject j = new JSONObject(String.valueOf(o));
                int err = j.optInt("error", 0);
                if (err > 0) showError(err);
                else if (errorBox.getVisibility() == View.VISIBLE && j.optInt("state", -1) == 1) errorBox.setVisibility(View.GONE);
            } catch (Exception ignored) { }
        });
    }

    private void showError(int code) {
        String m;
        if (code == 101 || code == 150 || code == 153) m = "O dono deste vídeo não permite a reprodução dentro de outros aplicativos.";
        else if (code == 100) m = "Este vídeo está indisponível ou é privado.";
        else if (code == 2) m = "Identificador de vídeo inválido.";
        else m = "O YouTube não conseguiu reproduzir este vídeo neste aparelho (código " + code + ").";
        errorText.setText(m);
        errorBox.setVisibility(View.VISIBLE);
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getAction() == KeyEvent.ACTION_DOWN && errorBox != null && errorBox.getVisibility() != View.VISIBLE) {
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                case KeyEvent.KEYCODE_MEDIA_PLAY: case KeyEvent.KEYCODE_MEDIA_PAUSE: cmd("toggle"); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: cmd("forward"); return true;
                case KeyEvent.KEYCODE_DPAD_LEFT: case KeyEvent.KEYCODE_MEDIA_REWIND: cmd("rewind"); return true;
                default: break;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override public void onBackPressed() { if (customView != null) hideCustom(); else super.onBackPressed(); }

    @Override protected void onPause() { cmd("pause"); if (web != null) web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); UI.fullscreen(this); if (web != null) web.onResume(); }

    @Override protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (web != null) { root.removeView(web); web.destroy(); web = null; }
        super.onDestroy();
    }
}
