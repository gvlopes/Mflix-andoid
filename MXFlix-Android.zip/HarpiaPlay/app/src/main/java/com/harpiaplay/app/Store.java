package com.harpiaplay.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

/** SQLite local: favoritos, histórico/progresso e cache do catálogo (em partes). */
public class Store extends SQLiteOpenHelper {
    private static Store inst;
    private static final int PART = 400_000;

    public static synchronized Store get(Context c) {
        if (inst == null) inst = new Store(c.getApplicationContext());
        return inst;
    }

    private Store(Context c) { super(c, "harpiaplay.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE favorites(session TEXT,kind TEXT,id TEXT,item TEXT,PRIMARY KEY(session,kind,id))");
        db.execSQL("CREATE TABLE history(session TEXT,kind TEXT,id TEXT,item TEXT,position INTEGER,duration INTEGER,completed INTEGER,accessed INTEGER,PRIMARY KEY(session,kind,id))");
        db.execSQL("CREATE INDEX history_recent ON history(session,accessed DESC)");
        db.execSQL("CREATE TABLE cache(session TEXT,endpoint TEXT,updated INTEGER,PRIMARY KEY(session,endpoint))");
        db.execSQL("CREATE TABLE cache_parts(session TEXT,endpoint TEXT,part INTEGER,payload TEXT,PRIMARY KEY(session,endpoint,part))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int o, int n) { }

    // ---- cache ----
    public synchronized void putCache(String s, String ep, String payload) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("cache_parts", "session=? AND endpoint=?", new String[]{s, ep});
            int part = 0;
            for (int i = 0; i < payload.length(); i += PART) {
                ContentValues v = new ContentValues();
                v.put("session", s); v.put("endpoint", ep); v.put("part", part++);
                v.put("payload", payload.substring(i, Math.min(payload.length(), i + PART)));
                db.insert("cache_parts", null, v);
            }
            ContentValues c = new ContentValues();
            c.put("session", s); c.put("endpoint", ep); c.put("updated", System.currentTimeMillis());
            db.insertWithOnConflict("cache", null, c, SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    /** Retorna o payload se existir e tiver menos de maxAgeMs; senão null. */
    public synchronized String getCache(String s, String ep, long maxAgeMs) {
        SQLiteDatabase db = getReadableDatabase();
        long upd = -1;
        try (Cursor c = db.rawQuery("SELECT updated FROM cache WHERE session=? AND endpoint=?", new String[]{s, ep})) {
            if (c.moveToFirst()) upd = c.getLong(0);
        }
        if (upd < 0 || System.currentTimeMillis() - upd > maxAgeMs) return null;
        StringBuilder sb = new StringBuilder();
        try (Cursor c = db.rawQuery("SELECT payload FROM cache_parts WHERE session=? AND endpoint=? ORDER BY part", new String[]{s, ep})) {
            while (c.moveToNext()) sb.append(c.getString(0));
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    public synchronized void clearCache() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("cache", null, null);
        db.delete("cache_parts", null, null);
    }

    // ---- favoritos ----
    public synchronized boolean isFavorite(String s, Item i) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM favorites WHERE session=? AND kind=? AND id=?", new String[]{s, i.kind, i.id})) {
            return c.moveToFirst();
        }
    }

    public synchronized boolean toggleFavorite(String s, Item i) {
        SQLiteDatabase db = getWritableDatabase();
        if (isFavorite(s, i)) {
            db.delete("favorites", "session=? AND kind=? AND id=?", new String[]{s, i.kind, i.id});
            return false;
        }
        ContentValues v = new ContentValues();
        v.put("session", s); v.put("kind", i.kind); v.put("id", i.id); v.put("item", i.toJson().toString());
        db.insertWithOnConflict("favorites", null, v, SQLiteDatabase.CONFLICT_REPLACE);
        return true;
    }

    public synchronized List<Item> favorites(String s, String kind) {
        List<Item> out = new ArrayList<>();
        String sql = "SELECT item FROM favorites WHERE session=?" + (kind == null ? "" : " AND kind=?");
        String[] args = kind == null ? new String[]{s} : new String[]{s, kind};
        try (Cursor c = getReadableDatabase().rawQuery(sql, args)) {
            while (c.moveToNext()) { try { out.add(Item.fromJson(new JSONObject(c.getString(0)))); } catch (Exception ignored) { } }
        }
        return out;
    }

    // ---- histórico ----
    public synchronized void progress(String s, Item i, long pos, long dur) {
        boolean done = dur > 0 && pos >= dur * 0.95;
        ContentValues v = new ContentValues();
        v.put("session", s); v.put("kind", i.kind); v.put("id", i.id); v.put("item", i.toJson().toString());
        v.put("position", pos); v.put("duration", dur); v.put("completed", done ? 1 : 0);
        v.put("accessed", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("history", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public synchronized long position(String s, String kind, String id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT position,completed FROM history WHERE session=? AND kind=? AND id=?", new String[]{s, kind, id})) {
            if (c.moveToFirst() && c.getInt(1) == 0) return c.getLong(0);
        }
        return 0;
    }

    /** Itens recentes; onlyResumable = só os que têm posição e não terminaram (continuar assistindo). */
    public synchronized List<Item> history(String s, boolean onlyResumable) {
        List<Item> out = new ArrayList<>();
        String sql = "SELECT item FROM history WHERE session=?" + (onlyResumable ? " AND kind!='live' AND position>0 AND completed=0" : "") + " ORDER BY accessed DESC LIMIT 200";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{s})) {
            while (c.moveToNext()) { try { out.add(Item.fromJson(new JSONObject(c.getString(0)))); } catch (Exception ignored) { } }
        }
        return out;
    }

    public synchronized void clearHistory(String s) { getWritableDatabase().delete("history", "session=?", new String[]{s}); }
}
