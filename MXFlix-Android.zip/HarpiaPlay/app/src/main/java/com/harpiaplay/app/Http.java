package com.harpiaplay.app;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Cliente HTTP compartilhado. */
public final class Http {
    public static final String UA = "HarpiaPlay/" + BuildConfig.VERSION_NAME + " (Android)";
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .connectionPool(new okhttp3.ConnectionPool(8, 5, TimeUnit.MINUTES))
            .build();
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private Http() {}
    public static OkHttpClient client() { return CLIENT; }

    public static class Result { public int code; public String body; }

    public static Result get(String url, String bearer) throws IOException {
        Request.Builder b = new Request.Builder().url(url).header("User-Agent", UA).header("Accept", "*/*");
        if (bearer != null && !bearer.isEmpty()) b.header("Authorization", "Bearer " + bearer);
        return run(b.build());
    }

    public static Result postJson(String url, String json, String bearer) throws IOException {
        Request.Builder b = new Request.Builder().url(url).header("User-Agent", UA)
                .post(RequestBody.create(json, JSON));
        if (bearer != null && !bearer.isEmpty()) b.header("Authorization", "Bearer " + bearer);
        return run(b.build());
    }

    private static Result run(Request req) throws IOException {
        try (Response r = CLIENT.newCall(req).execute()) {
            Result res = new Result();
            res.code = r.code();
            res.body = r.body() != null ? r.body().string() : "";
            return res;
        }
    }
}
