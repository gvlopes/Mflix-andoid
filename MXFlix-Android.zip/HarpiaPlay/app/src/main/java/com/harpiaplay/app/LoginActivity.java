package com.harpiaplay.app;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Entrada: usuário e senha (o app descobre a DNS certa entre as cadastradas no painel) ou ativação por código. */
public class LoginActivity extends BaseActivity {
    private static final String INVALID = "Usuário ou senha inválidos.";
    private LinearLayout formUser, formId;
    private EditText user, pass;
    private TextView message, waiting, tabUser, tabId;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean polling = false, busy = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER);
        sv.addView(outer, new ScrollView.LayoutParams(-1, -1));

        // cartão central
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int pad = UI.dp(this, 26);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(UI.alpha(0xE6));
        bg.setCornerRadius(UI.dp(this, 24 * Theme.radius));
        bg.setStroke(UI.dp(this, 1), 0x33FFFFFF);
        card.setBackground(bg);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(UI.dp(this, 440), -2);
        cl.setMargins(UI.dp(this, 16), UI.dp(this, 16), UI.dp(this, 16), UI.dp(this, 16));
        outer.addView(card, cl);

        ImageView logo = new ImageView(this);
        UI.logo(logo);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(UI.dp(this, 84), UI.dp(this, 84));
        ll.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(logo, ll);
        TextView title = UI.text(this, "Bem-vindo", 24, UI.WHITE, true);
        title.setGravity(Gravity.CENTER);
        card.addView(title, UI.lp(-1, -2, 12, this));
        TextView sub = UI.text(this, "Acesse sua conta para continuar", 13, UI.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        card.addView(sub, UI.lp(-1, -2, 2, this));

        // abas
        LinearLayout tabs = new LinearLayout(this);
        tabs.setBackground(UI.round(this, UI.SURFACE, 14));
        int tp = UI.dp(this, 4);
        tabs.setPadding(tp, tp, tp, tp);
        tabUser = tab("Entrar", 0);
        tabId = tab("Ativar por código", 1);
        tabs.addView(tabUser, new LinearLayout.LayoutParams(0, -2, 1));
        tabs.addView(tabId, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(tabs, UI.lp(-1, -2, 18, this));

        // --- usuário e senha
        formUser = new LinearLayout(this);
        formUser.setOrientation(LinearLayout.VERTICAL);
        user = UI.input(this, T.t("Usuário"), false);
        pass = UI.input(this, T.t("Senha"), true);
        pass.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        pass.setOnEditorActionListener((v, a, e) -> { doUserLogin(); return true; });
        formUser.addView(user, UI.lp(-1, -2, 16, this));
        formUser.addView(pass, UI.lp(-1, -2, 10, this));
        formUser.addView(UI.primaryButton(this, T.t("ENTRAR"), this::doUserLogin), UI.lp(-1, -2, 16, this));
        card.addView(formUser);

        // --- ativação por código
        formId = new LinearLayout(this);
        formId.setOrientation(LinearLayout.VERTICAL);
        formId.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView hint = UI.text(this, "Passe este código ao suporte para liberar seu acesso:", 13, UI.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        formId.addView(hint, UI.lp(-1, -2, 18, this));
        TextView big = UI.text(this, Panel.friendlyId(), 38, Cfg.primary(), true);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.2f);
        big.setBackground(UI.round(this, UI.SURFACE, 14));
        big.setPadding(0, UI.dp(this, 12), 0, UI.dp(this, 12));
        formId.addView(big, UI.lp(-1, -2, 12, this));
        waiting = UI.text(this, "Aguardando ativação...", 13, UI.MUTED, false);
        waiting.setGravity(Gravity.CENTER);
        formId.addView(waiting, UI.lp(-1, -2, 12, this));
        formId.addView(UI.button(this, "Verificar agora", this::checkActivation), UI.lp(-1, -2, 14, this));
        formId.setVisibility(View.GONE);
        card.addView(formId);

        message = UI.text(this, "", 13, 0xFFFF7A7A, false);
        message.setGravity(Gravity.CENTER);
        card.addView(message, UI.lp(-1, -2, 12, this));

        // ações secundárias
        LinearLayout more = new LinearLayout(this);
        more.setGravity(Gravity.CENTER);
        more.addView(link(T.t("GERAR TESTE GRÁTIS"), this::doTrial));
        String phone = Cfg.get("support_phone", "");
        final String wa = !phone.isEmpty() ? "https://wa.me/" + phone : Cfg.get("support_whatsapp", Cfg.get("support_link", ""));
        if (!wa.isEmpty()) more.addView(link(T.t("Suporte"), () -> UI.openUrl(this, wa)));
        card.addView(more, UI.lp(-1, -2, 10, this));

        TextView did = UI.text(this, T.t("ID do aparelho") + ": " + Panel.friendlyId(), 11, UI.MUTED, false);
        did.setGravity(Gravity.CENTER);
        card.addView(did, UI.lp(-1, -2, 12, this));

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(UI.BG);
        ImageView bgImg = new ImageView(this);
        UI.background(bgImg);
        bgImg.setAlpha(0.35f);
        frame.addView(bgImg, new FrameLayout.LayoutParams(-1, -1));
        frame.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));
        frame.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        showTab(0);
        // aquece a lista de DNS do painel (o login também busca de novo, para ficar sempre atualizado)
        Repo.async(Panel::servers, new Repo.Result<JSONArray>() {
            @Override public void ok(JSONArray a) { }
            @Override public void fail(String e) { message.setText(e); }
        });
    }

    private TextView tab(String label, final int idx) {
        TextView t = UI.text(this, label, 13, UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        int ph = UI.dp(this, 10), pv = UI.dp(this, 10);
        t.setPadding(ph, pv, ph, pv);
        t.setFocusable(true); t.setClickable(true);
        t.setOnClickListener(v -> showTab(idx));
        return t;
    }

    private TextView link(String label, final Runnable r) {
        TextView t = UI.text(this, label, 12, Cfg.primary(), true);
        int p = UI.dp(this, 10);
        t.setPadding(p, p, p, p);
        t.setFocusable(true); t.setClickable(true);
        t.setBackground(UI.focusBg(this, 0x00000000, 8));
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void styleTab(TextView t, boolean on) {
        if (on) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Theme.primary, Theme.secondary});
            g.setCornerRadius(UI.dp(this, 11 * Theme.radius));
            t.setBackground(g);
            t.setTextColor(UI.onColor(Theme.primary));
        } else {
            t.setBackground(null);
            t.setTextColor(UI.MUTED);
        }
    }

    private void showTab(int i) {
        formUser.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        formId.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        styleTab(tabUser, i == 0);
        styleTab(tabId, i == 1);
        message.setText("");
        polling = i == 1;
        handler.removeCallbacksAndMessages(null);
        if (polling) schedulePoll(0);
    }

    private void setBusy(boolean v, String msg) {
        busy = v;
        message.setTextColor(v ? UI.MUTED : 0xFFFF7A7A);
        message.setText(msg == null ? "" : msg);
    }

    private void doUserLogin() {
        if (busy) return;
        final String u = user.getText().toString().trim(), p = pass.getText().toString();
        if (u.isEmpty() || p.isEmpty()) { setBusy(false, "Informe usuário e senha."); return; }
        setBusy(true, "Conectando...");
        Repo.async(() -> { loginAny(u, p); return true; }, done());
    }

    private void doTrial() {
        if (busy) return;
        setBusy(true, "Conectando seu teste grátis...");
        Repo.async(() -> {
            JSONObject d = Panel.trial();
            completeFromUrl(d.optString("m3u_url"), false);
            return true;
        }, done());
    }

    private Repo.Result<Boolean> done() {
        return new Repo.Result<Boolean>() {
            @Override public void ok(Boolean v) { setBusy(false, ""); goHome(); }
            @Override public void fail(String e) { setBusy(false, e); }
        };
    }

    private void goHome() {
        handler.removeCallbacksAndMessages(null);
        Intent i = new Intent(this, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    // ----------------------------------------------------------- lógica de login
    /**
     * O cliente informa só usuário e senha. O app busca no painel todas as DNS ativas e tenta uma a uma
     * (a última que funcionou vai primeiro) até achar a que reconhece o usuário.
     */
    static void loginAny(String u, String p) throws Exception {
        JSONArray a;
        try { a = Panel.servers(); } catch (Panel.PanelException e) { throw new Exception(e.getMessage()); }
        List<String> bases = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String b = Rules.normalizeServer(o.optString("url"));
            if (!b.isEmpty() && !bases.contains(b)) bases.add(b);
        }
        if (bases.isEmpty()) throw new Exception("Nenhum servidor disponível. Fale com o suporte.");
        String last = Prefs.get("last_dns", "");
        if (bases.remove(last)) bases.add(0, last);

        String netErr = T.t("Falha de conexão. Verifique a internet.");
        String definitive = null, connection = null;
        boolean invalid = false;
        for (String base : bases) {
            try {
                loginXtream(base, u, p, true);
                Prefs.put("last_dns", base);
                return;
            } catch (Exception e) {
                String m = e.getMessage() == null ? "" : e.getMessage();
                if (m.equals(INVALID)) invalid = true;
                else if (m.equals(netErr)) connection = m;
                else if (definitive == null) definitive = m;   // conta vencida/bloqueada etc.: resposta definitiva
            }
        }
        if (definitive != null) throw new Exception(definitive);
        if (invalid) throw new Exception(INVALID);
        throw new Exception(connection != null ? connection : netErr);
    }

    /** strict = erros do painel (servidor/aparelho bloqueado) impedem o login. */
    static void loginXtream(String base, String u, String p, boolean strict) throws Exception {
        Xtream x = new Xtream(base, u, p);
        JSONObject j;
        try { j = x.auth(); } catch (Exception e) { throw new Exception(T.t("Falha de conexão. Verifique a internet.")); }
        JSONObject ui = j.optJSONObject("user_info");
        String err = Rules.accountError(ui, System.currentTimeMillis() / 1000);
        if (err != null) throw new Exception(err);
        String pinHash = "";
        try {
            pinHash = Panel.registerDevice(base, u, ui.optString("status"), ui.optString("exp_date"));
        } catch (Panel.PanelException e) {
            if (strict || e.code == 403 && e.getMessage() != null && e.getMessage().toLowerCase().contains("bloquead")) throw new Exception(e.getMessage());
        }
        Repo.saveXtream(base, u, p);
        Prefs.put("acc_status", ui.optString("status"));
        Prefs.put("acc_exp", ui.optString("exp_date"));
        Prefs.put("acc_maxcon", ui.optString("max_connections"));
        if (!pinHash.isEmpty()) Prefs.put("pin_hash", pinHash);
        Panel.log("login_success");
    }

    static void completeFromUrl(String url, boolean remote) throws Exception {
        if (url == null || url.isEmpty()) throw new Exception("Lista inválida.");
        String[] x = M3u.xtreamFromUrl(url);
        if (x != null) loginXtream(Rules.normalizeServer(x[0]), x[1], x[2], false);
        else Repo.saveM3u(url);
        Prefs.putBool("activated_remote", remote);
    }

    // ----------------------------------------------------------- ativação por código
    private void schedulePoll(long delay) {
        handler.postDelayed(() -> { if (polling) checkActivation(); }, delay > 0 ? delay : 500);
    }

    private void checkActivation() {
        if (busy) return;
        Repo.async(() -> {
            Panel.Activation a = Panel.activation();
            if (a.active && a.m3u != null && !a.m3u.isEmpty()) {
                completeFromUrl(a.m3u, true);
                Prefs.put("activation_rev", String.valueOf(a.revision));
                return true;
            }
            return false;
        }, new Repo.Result<Boolean>() {
            @Override public void ok(Boolean v) {
                if (v) { waiting.setText("Ativação recebida. Carregando seu conteúdo..."); goHome(); }
                else { waiting.setText("Aguardando ativação..."); if (polling) schedulePoll(6000); }
            }
            @Override public void fail(String e) { waiting.setText(e); if (polling) schedulePoll(10000); }
        });
    }

    @Override protected void onDestroy() { polling = false; handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
