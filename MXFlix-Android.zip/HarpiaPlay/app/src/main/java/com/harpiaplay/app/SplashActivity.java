package com.harpiaplay.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

/** Abertura: logo estilhaçada se juntando (enquanto o app já consulta o painel em paralelo). */
public class SplashActivity extends AppCompatActivity {
    private static final long ANIM_MS = 2300;
    private TextView status, name;
    private LinearLayout root, failBox;
    private boolean animDone = false, configDone = false, navigated = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UI.fullscreen(this);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(UI.BG);
        frame.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        ShatterLogoView logo = new ShatterLogoView(this);
        int size = Math.min(UI.dp(this, 190), getResources().getDisplayMetrics().heightPixels / 2);
        root.addView(logo, new LinearLayout.LayoutParams(size, size));

        name = UI.text(this, Cfg.appName(), 30, UI.WHITE, true);
        name.setGravity(Gravity.CENTER);
        name.setAlpha(0f);
        name.setLetterSpacing(0.12f);
        root.addView(name, UI.lp(-2, -2, 6, this));

        status = UI.text(this, "", 12, UI.MUTED, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, UI.lp(-2, -2, 10, this));
        setContentView(frame);

        logo.start(ANIM_MS, () -> { animDone = true; tryNext(); });
        // o nome aparece quando a logo termina de montar
        name.animate().alpha(1f).setStartDelay((long) (ANIM_MS * 0.7f)).setDuration(600).start();
        start();
    }

    private void start() {
        if (failBox != null) { root.removeView(failBox); failBox = null; }
        configDone = false;
        status.setText("");
        if (!Panel.isConfigured()) { askPanel(); return; }
        Repo.async(() -> {
            try {
                JSONObject cfg = Panel.config();
                try { Theme.save(Panel.theme()); } catch (Exception ignored) { }
                return cfg;
            }
            catch (Panel.PanelException e) {
                // sem cache local ou em manutenção: mostra o erro; com cache, segue offline
                if (e.code == 503 || Prefs.get("config_json", "").isEmpty()) throw new Exception(e.getMessage() + "\n\n" + Panel.baseUrl() + "/api/config.php");
                return null;
            }
        }, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { configDone = true; tryNext(); }
            @Override public void fail(String error) { showFail(error); }
        });
    }

    private void showFail(String error) {
        status.setText(error);
        failBox = new LinearLayout(this);
        failBox.setOrientation(LinearLayout.VERTICAL);
        failBox.setGravity(Gravity.CENTER_HORIZONTAL);
        failBox.addView(UI.primaryButton(this, T.t("Tentar novamente"), this::start), UI.lp(-2, -2, 16, this));
        failBox.addView(UI.button(this, "Trocar URL do painel", this::askPanel), UI.lp(-2, -2, 8, this));
        root.addView(failBox);
    }

    private void askPanel() {
        final EditText e = UI.input(this, "https://seu-painel.com", false);
        if (Panel.isConfigured()) e.setText(Panel.baseUrl());
        new AlertDialog.Builder(this).setTitle("URL do painel").setView(UI.pad(this, e)).setCancelable(Panel.isConfigured())
                .setPositiveButton("OK", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) { askPanel(); return; }
                    Panel.setBaseUrl(s);
                    start();
                }).show();
    }

    /** Só segue quando a animação terminou E o painel respondeu. */
    private void tryNext() {
        if (!animDone || !configDone || navigated) return;
        navigated = true;
        startActivity(new Intent(this, Repo.loggedIn() ? HomeActivity.class : LoginActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
