package com.harpiaplay.app;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Base de todas as telas: tela 100% cheia (sem barra de status/navegação) e respeito ao recorte da câmera. */
public class BaseActivity extends AppCompatActivity {
    /** Telas de vídeo desligam o recuo do recorte para usar a tela inteira. */
    protected boolean padForCutout() { return true; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UI.fullscreen(this);
    }

    @Override public void setContentView(View v) {
        super.setContentView(v);
        UI.fullscreen(this);
        if (padForCutout()) {
            View content = findViewById(android.R.id.content);
            ViewCompat.setOnApplyWindowInsetsListener(content, (view, insets) -> {
                // só o recorte (notch) e o teclado: as barras do sistema ficam escondidas
                Insets i = insets.getInsets(WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
                view.setPadding(i.left, i.top, i.right, i.bottom);
                return insets;
            });
            ViewCompat.requestApplyInsets(content);
        }
    }

    @Override protected void onResume() { super.onResume(); UI.fullscreen(this); }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) UI.fullscreen(this);
    }
}
