package com.harpiaplay.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Preferências simples do app (SharedPreferences). */
public final class Prefs {
    private static SharedPreferences sp;
    private Prefs() {}
    public static void init(Context c) { sp = c.getApplicationContext().getSharedPreferences("harpiaplay", Context.MODE_PRIVATE); }
    public static String get(String k, String d) { return sp.getString(k, d); }
    public static void put(String k, String v) { sp.edit().putString(k, v).apply(); }
    public static boolean bool(String k, boolean d) { return sp.getBoolean(k, d); }
    public static void putBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public static long lng(String k, long d) { return sp.getLong(k, d); }
    public static void putLong(String k, long v) { sp.edit().putLong(k, v).apply(); }
    public static void remove(String k) { sp.edit().remove(k).apply(); }
}
