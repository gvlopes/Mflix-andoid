package com.harpiaplay.app;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.json.JSONArray;
import org.json.JSONObject;

/** Detalhes de filme/série: sinopse, favoritar, assistir/continuar, temporadas e episódios. */
public class DetailsActivity extends AppCompatActivity {
    private Item item;
    private TextView plot, meta, favBtn, watchBtn;
    private LinearLayout seasonBar, episodes;
    private ImageView backdrop;
    private final TreeMap<Integer, List<Item>> seasons = new TreeMap<>();
    private int currentSeason = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        item = Repo.selected;
        if (item == null) { finish(); return; }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(UI.BG);
        backdrop = new ImageView(this);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(0.35f);
        UI.image(backdrop, item.cover, R.drawable.hp_background);
        root.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{UI.alpha(0xF2), UI.alpha(0x99)}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        col.setPadding(p, p, p, p);
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        col.addView(top);
        ImageView poster = new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        UI.image(poster, item.cover, R.drawable.ic_play);
        top.addView(poster, new LinearLayout.LayoutParams(UI.dp(this, 130), UI.dp(this, 195)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(0, -2, 1);
        il.leftMargin = UI.dp(this, 16);
        top.addView(info, il);
        info.addView(UI.text(this, item.name, 22, UI.WHITE, true));
        meta = UI.text(this, item.rating > 0 ? "★ " + String.format(java.util.Locale.US, "%.1f", item.rating) : "", 13, Cfg.primary(), false);
        info.addView(meta, UI.lp(-2, -2, 4, this));
        plot = UI.text(this, item.plot, 13, 0xFFDDE3EE, false);
        plot.setMaxLines(6);
        info.addView(plot, UI.lp(-1, -2, 8, this));

        LinearLayout btns = new LinearLayout(this);
        watchBtn = UI.primaryButton(this, T.t("Assistir"), this::playMain);
        btns.addView(watchBtn);
        favBtn = UI.button(this, "", this::toggleFav);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-2, -2);
        fl.leftMargin = UI.dp(this, 10);
        btns.addView(favBtn, fl);
        col.addView(btns, UI.lp(-2, -2, 14, this));

        seasonBar = new LinearLayout(this);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(seasonBar);
        hs.setHorizontalScrollBarEnabled(false);
        col.addView(hs, UI.lp(-1, -2, 14, this));
        episodes = new LinearLayout(this);
        episodes.setOrientation(LinearLayout.VERTICAL);
        col.addView(episodes, UI.lp(-1, -2, 8, this));

        setContentView(root);
        updateFav();
        updateWatch();
        loadInfo();
    }

    private void updateFav() {
        boolean f = Store.get(this).isFavorite(Repo.session(), item);
        favBtn.setText(f ? T.t("Favorito ✓") : T.t("Favoritar"));
    }

    private void toggleFav() { Store.get(this).toggleFavorite(Repo.session(), item); updateFav(); }

    private void updateWatch() {
        if ("series".equals(item.kind)) { watchBtn.setVisibility(View.GONE); return; }
        long pos = Store.get(this).position(Repo.session(), item.kind, item.id);
        watchBtn.setText(pos > 5000 ? T.t("Continuar") : T.t("Assistir"));
    }

    private void playMain() {
        ArrayList<Item> one = new ArrayList<>();
        one.add(item);
        Repo.playlist = one; Repo.playlistIndex = 0;
        startActivity(new Intent(this, PlayerActivity.class));
    }

    // ---------------------------------------------------------- informações
    private void loadInfo() {
        final Xtream x = Repo.xtream();
        if (x == null) return;
        if ("vod".equals(item.kind)) {
            Repo.async(() -> x.vodInfo(item.id), new Repo.Result<JSONObject>() {
                @Override public void ok(JSONObject j) {
                    JSONObject i = j.optJSONObject("info");
                    if (i == null) return;
                    String pl = i.optString("plot", i.optString("description", ""));
                    if (!pl.isEmpty()) plot.setText(pl);
                    StringBuilder m = new StringBuilder(meta.getText());
                    String g = i.optString("genre", ""), y = i.optString("releasedate", ""), d = i.optString("duration", "");
                    if (!y.isEmpty()) m.append("  •  ").append(y.length() >= 4 ? y.substring(0, 4) : y);
                    if (!g.isEmpty()) m.append("  •  ").append(g);
                    if (!d.isEmpty()) m.append("  •  ").append(d);
                    meta.setText(m.toString());
                    JSONObject md = j.optJSONObject("movie_data");
                    if (md != null && !md.optString("container_extension").isEmpty()) item.ext = md.optString("container_extension");
                }
                @Override public void fail(String e) { }
            });
        } else if ("series".equals(item.kind)) {
            plot.setText(T.t("Carregando..."));
            Repo.async(() -> x.seriesInfo(item.id), new Repo.Result<JSONObject>() {
                @Override public void ok(JSONObject j) { showSeries(j); }
                @Override public void fail(String e) { plot.setText(e); }
            });
        }
    }

    private void showSeries(JSONObject j) {
        JSONObject i = j.optJSONObject("info");
        if (i != null) {
            String pl = i.optString("plot", "");
            plot.setText(pl.isEmpty() ? item.plot : pl);
            String g = i.optString("genre", "");
            if (!g.isEmpty()) meta.setText(meta.getText() + (meta.length() > 0 ? "  •  " : "") + g);
            JSONArray bd = i.optJSONArray("backdrop_path");
            if (bd != null && bd.length() > 0) UI.image(backdrop, bd.optString(0), R.drawable.hp_background);
        }
        JSONObject eps = j.optJSONObject("episodes");
        if (eps == null) { plot.setText(T.t("Nenhum resultado.")); return; }
        Iterator<String> keys = eps.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            int sn;
            try { sn = Integer.parseInt(k); } catch (Exception e) { continue; }
            JSONArray arr = eps.optJSONArray(k);
            if (arr == null) continue;
            List<Item> list = new ArrayList<>();
            for (int n = 0; n < arr.length(); n++) {
                JSONObject e = arr.optJSONObject(n);
                if (e == null) continue;
                Item ep = new Item();
                ep.kind = "episode"; ep.id = e.optString("id");
                int num = e.optInt("episode_num", n + 1);
                String t = e.optString("title", "");
                ep.name = item.name + " · T" + sn + "E" + num + (t.isEmpty() ? "" : " · " + t);
                ep.ext = e.optString("container_extension", "mp4");
                JSONObject ei = e.optJSONObject("info");
                if (ei != null) { ep.cover = ei.optString("movie_image", item.cover); ep.plot = ei.optString("plot", ""); }
                if (ep.cover.isEmpty()) ep.cover = item.cover;
                ep.catId = item.id;
                list.add(ep);
            }
            seasons.put(sn, list);
        }
        buildSeasonBar();
        if (!seasons.isEmpty()) selectSeason(seasons.firstKey());
    }

    private void buildSeasonBar() {
        seasonBar.removeAllViews();
        for (final Integer s : seasons.keySet()) {
            TextView t = UI.button(this, T.t("Temporada") + " " + s, () -> selectSeason(s));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = UI.dp(this, 8);
            seasonBar.addView(t, lp);
        }
    }

    private void selectSeason(int s) {
        currentSeason = s;
        episodes.removeAllViews();
        final List<Item> list = seasons.get(s);
        if (list == null) return;
        for (int i = 0; i < list.size(); i++) {
            final int idx = i;
            final Item ep = list.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setFocusable(true); row.setClickable(true);
            row.setBackground(UI.focusBg(this, UI.SURFACE, 10));
            int pad = UI.dp(this, 8);
            row.setPadding(pad, pad, pad, pad);
            ImageView th = new ImageView(this);
            th.setScaleType(ImageView.ScaleType.CENTER_CROP);
            UI.image(th, ep.cover, R.drawable.ic_play);
            row.addView(th, new LinearLayout.LayoutParams(UI.dp(this, 96), UI.dp(this, 56)));
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1);
            tl.leftMargin = UI.dp(this, 10);
            row.addView(txt, tl);
            String title = ep.name.contains(" · ") ? ep.name.substring(ep.name.indexOf(" · ") + 3) : ep.name;
            txt.addView(UI.text(this, title, 14, UI.WHITE, true));
            if (!ep.plot.isEmpty()) {
                TextView pl = UI.text(this, ep.plot, 11, UI.MUTED, false);
                pl.setMaxLines(2);
                txt.addView(pl);
            }
            long pos = Store.get(this).position(Repo.session(), ep.kind, ep.id);
            if (pos > 5000) txt.addView(UI.text(this, "▶ " + T.t("Continuar"), 11, Cfg.primary(), false));
            row.setOnClickListener(v -> {
                Repo.playlist = new ArrayList<>(list);
                Repo.playlistIndex = idx;
                startActivity(new Intent(this, PlayerActivity.class));
            });
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
            rl.bottomMargin = UI.dp(this, 6);
            episodes.addView(row, rl);
        }
        if (episodes.getChildCount() > 0) episodes.getChildAt(0).requestFocus();
    }

    @Override protected void onResume() {
        super.onResume();
        if (item != null && watchBtn != null) updateWatch();
        if (currentSeason >= 0 && seasons.containsKey(currentSeason)) selectSeason(currentSeason);
    }
}
