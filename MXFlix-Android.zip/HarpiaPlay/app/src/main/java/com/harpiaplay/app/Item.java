package com.harpiaplay.app;

import org.json.JSONObject;

/** Canal, filme ou série. kind = "live" | "vod" | "series". */
public class Item {
    public String kind = "";
    public String id = "";
    public String name = "";
    public String cover = "";
    public String catId = "";
    public String ext = "";
    public String url = "";      // URL direta (modo M3U)
    public String plot = "";
    public String epgId = "";
    public double rating = 0;
    public long added = 0;
    public boolean archive = false;

    public String key() { return kind + ":" + id; }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("kind", kind); o.put("id", id); o.put("name", name); o.put("cover", cover);
            o.put("catId", catId); o.put("ext", ext); o.put("url", url); o.put("plot", plot);
            o.put("epgId", epgId); o.put("rating", rating); o.put("added", added); o.put("archive", archive);
        } catch (Exception ignored) { }
        return o;
    }

    public static Item fromJson(JSONObject o) {
        Item i = new Item();
        i.kind = o.optString("kind"); i.id = o.optString("id"); i.name = o.optString("name");
        i.cover = o.optString("cover"); i.catId = o.optString("catId"); i.ext = o.optString("ext");
        i.url = o.optString("url"); i.plot = o.optString("plot"); i.epgId = o.optString("epgId");
        i.rating = o.optDouble("rating", 0); i.added = o.optLong("added", 0); i.archive = o.optBoolean("archive", false);
        return i;
    }
}
