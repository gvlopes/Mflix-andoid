# minify desativado por padrão; regras mínimas caso ative.
-keep class com.harpiaplay.app.** { *; }
