@echo off
rem gradlew.bat do HarpiaPlay (sem gradle-wrapper.jar): baixa o Gradle 8.7 na 1a execucao.
setlocal
set GRADLE_VERSION=8.7
set DIST=%USERPROFILE%\.gradle\harpiaplay-dists
set GRADLE_BIN=%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  echo Baixando Gradle %GRADLE_VERSION% ...
  mkdir "%DIST%" 2>nul
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%DIST%\g.zip'; Expand-Archive -Force '%DIST%\g.zip' '%DIST%'; Remove-Item '%DIST%\g.zip'"
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
