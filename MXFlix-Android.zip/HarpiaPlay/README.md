# HarpiaPlay — projeto Android Studio

Player IPTV (Xtream Codes / M3U) para celular, tablet e Android TV, integrado ao painel web **HarpiaPlay Painel**.

## 1) Abrir e configurar
1. Android Studio (Koala 2024.1 ou mais novo, JDK 17) → **Open** → pasta `HarpiaPlay`.
2. Aguarde o *Gradle Sync* (baixa o Gradle 8.7 e as dependências; precisa de internet).
3. Já configurado para `https://web.harpiabanner.shop`. Para mudar, edite em `app/build.gradle` a linha:
   `buildConfigField "String", "PANEL_URL", "\"https://SEU-PAINEL.com\""`
   pela URL do seu painel (sem barra no final). Se deixar o padrão, o app pergunta a URL na 1ª abertura.
4. Se quiser outro nome de pacote: `applicationId` em `app/build.gradle` (o código usa `com.harpiaplay.app`).

## 2) Gerar APK e AAB
- **APK de teste:** Build → Build Bundle(s)/APK(s) → Build APK(s).
- **Release assinado (APK/AAB):** Build → Generate Signed Bundle / APK (cria o `.jks`), ou copie
  `keystore.properties.example` para `keystore.properties`, preencha e rode
  `Build → Generate Signed App Bundle`. Guarde o `.jks` e as senhas: sem eles não há como atualizar o app na Play Store.

## 3) O que o app faz
- Login por **usuário/senha** (servidores vêm do painel), **lista M3U**, **ativação remota por ID** (7 caracteres) e **teste grátis**.
- Ao Vivo (zapping cima/baixo, EPG agora/depois, fallback m3u8↔ts), Filmes, Séries (temporadas/episódios, próximo episódio automático), Favoritos, Continuar assistindo, Busca global.
- Controle parental com PIN (sincronizado com o painel), categorias ocultas, conteúdo adulto protegido.
- Clima (Open-Meteo), aviso/marquee, cores, logo, fundo, suporte (WhatsApp/Telegram/QR) controlados pelo painel.
- Senha IPTV guardada com AES-GCM no Android Keystore; cache do catálogo em SQLite.
- Funciona com toque e com controle remoto (Android TV).

## 4) Observações
- O projeto foi escrito sem acesso ao SDK Android neste ambiente: **não foi compilado**. Se o Sync/Build apontar algum erro, me envie a mensagem que eu corrijo.
- O app **não traz nenhum conteúdo**: ele reproduz a lista/servidor que você cadastrar no painel. Use apenas conteúdo que você tem direito de distribuir.
- Para Play Store: política de privacidade, ícone/screenshots e declaração de conteúdo são por sua conta.

## Linha de comando (gradlew)
- Linux/macOS: `./gradlew assembleDebug` (APK) ou `./gradlew bundleRelease` (AAB)
- Windows: `gradlew.bat assembleDebug`
Na 1ª execução o script baixa o Gradle 8.7 sozinho (precisa de internet e JDK 17+).
APK debug: `app/build/outputs/apk/debug/app-debug.apk` · AAB: `app/build/outputs/bundle/release/app-release.aab`

## Conexão com o painel por arquivo (app-config.json)
1. No painel: menu **Conexão do app** → informe a URL principal (e, se quiser, URLs reserva) → **BAIXAR app-config.json**.
2. Coloque o arquivo em `app/src/main/assets/app-config.json` (substitui o que já está lá).
3. Gere o APK/AAB. O app lê o arquivo e se conecta ao painel; se a URL principal cair, tenta as reservas sozinho.
Prioridade da URL: digitada no app (botão "Trocar URL do painel") > app-config.json > `PANEL_URL` do build.gradle.
Mudou de domínio? Gere um novo arquivo no painel, troque e recompile.

## Trocar o app-config.json depois de gerar o APK (sem recompilar)
O APK é um .zip: o arquivo fica em `assets/app-config.json`. Para trocar: descompacte o APK, substitua o JSON,
recompacte e **assine de novo** (apksigner/uber-apk-signer/APK Editor), senão o Android não instala.
Mesmo sem o JSON o app abre normal, na tela de login (usuário/senha, lista M3U ou ativação) — e, se o painel
estiver fora do ar, aparece o campo "Servidor" para digitar manualmente.

## Visual e desempenho
- Abertura animada: logo estilhaçada que se monta (`ShatterLogoView`, duração em `SplashActivity.ANIM_MS`).
- Home em carrossel (`CarouselLayoutManager`) e partículas no fundo (`ParticlesView`: Splash, Login e Home).
- Reprodução acelerada: buffer mínimo de 0,4 s para iniciar (`PlayerActivity`, `DefaultLoadControl`), conexões OkHttp reaproveitadas e ao vivo em TS por padrão (troca em Ajustes → Formato ao vivo; se falhar, tenta m3u8 sozinho).

## Temas
O app baixa o tema ativo do painel (`/api/theme.php`) na abertura e o aplica em todas as telas (`Theme.java`). Se o painel não tiver temas, usa o vermelho padrão. Com o app aberto, ele confere o painel a cada 10 s e redesenha a tela sozinho quando o tema muda (sem reabrir; o vídeo em reprodução não é interrompido).

## Logo e imagens
- A logo (HarpiaPlayer) está em `res/drawable-nodpi/hp_logo.png`, nos ícones `mipmap-*` e em `drawable-xhdpi/tv_banner.png`. A logo exibida dentro do app vem do painel (`assets/app-logo.png`), se configurada.
- As imagens dos cards da Home (Ao Vivo, Filmes, Séries, Favoritos, Continuar) usam as artes originais (`card_*.webp`, sem cor de tema) ou as enviadas no painel em "Imagens do app".
