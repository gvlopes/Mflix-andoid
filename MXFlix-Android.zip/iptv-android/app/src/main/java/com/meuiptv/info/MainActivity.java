package com.meuiptv.info;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Native");
        web.loadUrl("file:///android_asset/index.html");
    }

    private HttpURLConnection open(String u) throws IOException {
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) IPTVInfo");
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) break;
                u = new URL(new URL(u), loc).toString();
                continue;
            }
            return c;
        }
        throw new IOException("redirecionamentos demais");
    }

    private void work(String url, String mode, JSONObject r) throws IOException, JSONException {
        HttpURLConnection c = open(url);
        int code = c.getResponseCode();
        if (code >= 400) {
            c.disconnect();
            throw new IOException("http:" + code);
        }
        BufferedReader in = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"), 65536);
        try {
            if (mode.equals("m3u")) {
                int count = 0, n = 0;
                boolean valid = false;
                StringBuilder head = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    if (n < 3) head.append(line).append('\n');
                    n++;
                    if (line.startsWith("#EXTM3U") || line.startsWith("#EXTINF")) valid = true;
                    if (line.startsWith("#EXTINF")) count++;
                }
                r.put("head", head.toString());
                r.put("count", count);
                r.put("valid", valid);
            } else {
                StringBuilder sb = new StringBuilder();
                char[] buf = new char[8192];
                int k;
                while ((k = in.read(buf)) > 0) sb.append(buf, 0, k);
                String t = sb.toString();
                if (mode.equals("count")) {
                    int n;
                    try {
                        n = new JSONArray(t).length();
                    } catch (JSONException e) {
                        n = -1;
                    }
                    r.put("count", n);
                } else {
                    r.put("data", t);
                }
            }
        } finally {
            in.close();
            c.disconnect();
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void request(final String id, final String url, final String mode) {
            new Thread(() -> {
                JSONObject r = new JSONObject();
                try {
                    r.put("ok", true);
                    work(url, mode, r);
                } catch (Exception e) {
                    String err = "net";
                    if (e instanceof SocketTimeoutException) err = "timeout";
                    else if (e.getMessage() != null && e.getMessage().startsWith("http:")) err = e.getMessage();
                    r = new JSONObject();
                    try {
                        r.put("ok", false);
                        r.put("err", err);
                    } catch (JSONException ignored) {
                    }
                }
                final String js = "window.__nativeDone(" + JSONObject.quote(id) + "," + r.toString() + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        @JavascriptInterface
        public void copy(final String t) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("IPTV Info", t));
            });
        }

        @JavascriptInterface
        public void share(final String t) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, t);
                startActivity(Intent.createChooser(i, "Compartilhar"));
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
