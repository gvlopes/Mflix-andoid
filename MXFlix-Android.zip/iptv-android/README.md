# IPTV Info (projeto Android completo)

Projeto nativo (Java + WebView), sem Node e sem Capacitor. Tem `settings.gradle`, `build.gradle`, `app/build.gradle`, `gradlew` e tudo o que o Android precisa.

## Gerar o APK na nuvem (sem instalar nada)
1. Crie um repositório no github.com e envie TODOS os arquivos desta pasta (mantenha `.github`).
2. Aba **Actions** > **Gerar APK** > **Run workflow**.
3. Ao terminar, baixe **IPTV-Info-APK** no fim da página, descompacte e instale o `app-debug.apk`.

## Gerar no PC
- Android Studio: File > Open (escolha esta pasta) > Build > Build APK(s).
- Terminal (Java 17 + Android SDK): `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
  O `gradlew` baixa o `gradle-wrapper.jar` sozinho se ele não existir.
APK: `app/build/outputs/apk/debug/app-debug.apk`

A interface fica em `app/src/main/assets/index.html`.
