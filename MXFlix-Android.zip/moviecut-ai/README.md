# MovieCut AI

Pesquisa (YouTube Data API) → envio do material autorizado → cortes sugeridos (15/30/45/60s)
→ 9:16 1080x1920 → legendas (Whisper) → logo → vinheta animada → exportar → compartilhar.

## 1. Backend
```bash
cd backend
cp .env.example .env          # cole sua NOVA chave do YouTube e um APP_TOKEN
# Local (precisa de ffmpeg instalado):
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
# ou Docker:
docker build -t moviecut . && docker run -p 8000:8000 --env-file .env -v $PWD/storage:/srv/storage moviecut
```
Publique em um servidor com HTTPS (Railway, Render, VPS) e ponha a URL em `mobile/src/config.js`.

## 2. App
```bash
cd mobile
npm install
npx expo start               # testar com Expo Go
```

## 3. Gerar o APK (Android)
**Opção A – nuvem (mais simples):**
```bash
npm i -g eas-cli && eas login
eas build -p android --profile preview      # gera o .apk
```
**Opção B – local (os arquivos já estão prontos em `mobile/android/`: settings.gradle, build.gradle, gradlew):**
Requisitos: JDK 17, Android SDK (Android Studio) e Node 18+.
```bash
cd mobile
npm install                                  # obrigatório: o Gradle lê os módulos do node_modules
echo "sdk.dir=$HOME/Android/Sdk" > android/local.properties   # ajuste o caminho do seu Android SDK
cd android
chmod +x gradlew
./gradlew assembleRelease                    # Windows: gradlew.bat assembleRelease
```
APK pronto em `mobile/android/app/build/outputs/apk/release/app-release.apk`.
Na 1ª execução o `gradlew` baixa o `gradle-wrapper.jar` sozinho (precisa de internet).
Se algo falhar, apague a pasta `android/` e rode `npx expo prebuild -p android --clean` para regenerar tudo no padrão oficial.

## 4. App Store (iOS)
Requer conta Apple Developer e `bundleIdentifier` no `app.json`:
```bash
eas build -p ios --profile production
eas submit -p ios
```

## 5. Logomarca
No app: Configurações de edição → "Logomarca final" → escolha a imagem (PNG com fundo transparente).
Ela aparece fixa no vídeo e na vinheta final com animação (fade + zoom suave).

## Segurança e limites
- A chave do YouTube fica apenas no backend (`.env`). Nunca no app.
- O app só processa vídeos enviados por você (material próprio ou licenciado). Não baixa vídeos do YouTube.
- Publicação: o compartilhamento do sistema abre TikTok/Facebook/WhatsApp para você revisar e confirmar.
