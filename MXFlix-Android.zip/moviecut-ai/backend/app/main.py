"""MovieCut AI - backend (FastAPI + FFmpeg + Whisper)."""
import os, re, uuid, subprocess, shutil
from pathlib import Path
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, Form, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()
YT_KEY = os.getenv("YOUTUBE_API_KEY", "")
APP_TOKEN = os.getenv("APP_TOKEN", "")
STORE = Path(os.getenv("STORAGE_DIR", "./storage"))
for d in ("uploads", "outputs", "tmp"):
    (STORE / d).mkdir(parents=True, exist_ok=True)
LOGO = STORE / "logo.png"

app = FastAPI(title="MovieCut AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def auth(token: str | None):
    if APP_TOKEN and token != APP_TOKEN:
        raise HTTPException(401, "Token inválido")

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        raise HTTPException(500, p.stderr[-800:])
    return p.stderr

def dur_iso(s):  # PT1M30S -> segundos
    m = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", s)
    h, mi, se = (int(x or 0) for x in m.groups())
    return h * 3600 + mi * 60 + se

# ---------- 1. PESQUISA (YouTube Data API v3 - só metadados) ----------
@app.get("/search")
async def search(q: str, x_token: str | None = Header(None)):
    auth(x_token)
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.get("https://www.googleapis.com/youtube/v3/search", params={
            "part": "snippet", "q": f"{q} trailer oficial", "type": "video",
            "maxResults": 12, "key": YT_KEY})
        r.raise_for_status()
        items = r.json().get("items", [])
        ids = ",".join(i["id"]["videoId"] for i in items)
        d = await c.get("https://www.googleapis.com/youtube/v3/videos", params={
            "part": "contentDetails,status", "id": ids, "key": YT_KEY})
        det = {v["id"]: v for v in d.json().get("items", [])}
    out = []
    for i in items:
        vid = i["id"]["videoId"]; sn = i["snippet"]; v = det.get(vid, {})
        title = sn["title"]
        out.append({
            "id": vid, "title": title, "channel": sn["channelTitle"],
            "thumbnail": sn["thumbnails"]["high"]["url"],
            "duration": dur_iso(v.get("contentDetails", {}).get("duration", "PT0S")),
            "official": bool(re.search(r"official|oficial", title, re.I)),
            "license": v.get("status", {}).get("license", "youtube"),
            "url": f"https://www.youtube.com/watch?v={vid}",
        })
    return out  # o processamento exige upload do usuário (ver /upload)

# ---------- 2. UPLOAD do material autorizado ----------
@app.post("/upload")
async def upload(file: UploadFile = File(...), x_token: str | None = Header(None)):
    auth(x_token)
    vid = uuid.uuid4().hex
    dest = STORE / "uploads" / f"{vid}.mp4"
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"video_id": vid}

@app.post("/logo")
async def set_logo(file: UploadFile = File(...), x_token: str | None = Header(None)):
    auth(x_token)
    with open(LOGO, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"ok": True}

# ---------- 3. IA: sugere cortes (mudanças de cena + fala) ----------
@app.post("/suggest")
async def suggest(video_id: str = Form(...), durations: str = Form("10,20,30,40,50,60"),
                  per_duration: int = Form(3), x_token: str | None = Header(None)):
    auth(x_token)
    src = STORE / "uploads" / f"{video_id}.mp4"
    if not src.exists(): raise HTTPException(404, "Vídeo não encontrado")
    log = run(["ffmpeg", "-i", str(src), "-vf", "select='gt(scene,0.35)',showinfo",
               "-an", "-f", "null", "-"])
    times = [float(t) for t in re.findall(r"pts_time:([\d.]+)", log)]
    probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "csv=p=0", str(src)], capture_output=True, text=True)
    total = float(probe.stdout.strip() or 0)
    out = []
    for length in sorted({int(x) for x in durations.split(",") if x.strip().isdigit() and 10 <= int(x) <= 60}):
        if length > total: continue
        wins, start = [], 0.0
        while start + length <= total:
            n = sum(1 for t in times if start <= t < start + length)  # densidade de ação
            wins.append((n, start)); start += 5
        picked = []
        for n, st in sorted(wins, reverse=True):  # melhores trechos sem sobreposição
            if all(abs(st - q) >= length for q in picked):
                picked.append(st)
                out.append({"start": st, "duration": length, "score": n})
            if len(picked) >= per_duration: break
    return {"total": total, "suggestions": out}

# ---------- 4. RENDER: corte 9:16 + legenda + logo + vinheta ----------
def transcribe(clip: Path, srt: Path):
    from faster_whisper import WhisperModel
    model = WhisperModel("small", compute_type="int8")
    segs, _ = model.transcribe(str(clip), word_timestamps=False)
    def ts(t):
        h, m, s = int(t // 3600), int(t % 3600 // 60), t % 60
        return f"{h:02}:{m:02}:{s:06.3f}".replace(".", ",")
    with open(srt, "w", encoding="utf-8") as f:
        for i, s in enumerate(segs, 1):
            f.write(f"{i}\n{ts(s.start)} --> {ts(s.end)}\n{s.text.strip()}\n\n")

@app.post("/render")
async def render(video_id: str = Form(...), start: float = Form(...), duration: float = Form(30),
                 subtitles: bool = Form(True), logo_pos: str = Form("tr"),
                 outro_seconds: float = Form(3), outro_text: str = Form(""),
                 sub_color: str = Form("FFFFFF"), x_token: str | None = Header(None)):
    auth(x_token)
    src = STORE / "uploads" / f"{video_id}.mp4"
    if not src.exists(): raise HTTPException(404, "Vídeo não encontrado")
    job = uuid.uuid4().hex; tmp = STORE / "tmp"
    base, srt = tmp / f"{job}_base.mp4", tmp / f"{job}.srt"
    # a) corte vertical 1080x1920 + áudio normalizado
    run(["ffmpeg", "-y", "-ss", str(start), "-t", str(duration), "-i", str(src),
         "-vf", "scale=-2:1920,crop=1080:1920,fps=30", "-af", "loudnorm=I=-16:TP=-1.5",
         "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", str(base)])
    cur = base
    # b) legendas automáticas
    if subtitles:
        transcribe(base, srt)
        sub = tmp / f"{job}_sub.mp4"
        bgr = sub_color[4:6] + sub_color[2:4] + sub_color[0:2]
        style = f"FontSize=14,Bold=1,PrimaryColour=&H{bgr}&,OutlineColour=&H000000&,Outline=3,Alignment=2,MarginV=180"
        run(["ffmpeg", "-y", "-i", str(cur), "-vf",
             f"subtitles={srt.as_posix()}:force_style='{style}'", "-c:a", "copy", str(sub)])
        cur = sub
    # c) logomarca fixa
    if LOGO.exists():
        pos = {"tl": "30:30", "tr": "W-w-30:30", "bl": "30:H-h-30", "br": "W-w-30:H-h-30"}[logo_pos]
        lg = tmp / f"{job}_logo.mp4"
        run(["ffmpeg", "-y", "-i", str(cur), "-i", str(LOGO), "-filter_complex",
             f"[1]scale=220:-1[l];[0][l]overlay={pos}", "-c:a", "copy", str(lg)])
        cur = lg
    # d) vinheta final animada (logo com fade + zoom suave)
    final = STORE / "outputs" / f"{job}.mp4"
    if LOGO.exists() and outro_seconds > 0:
        d = outro_seconds
        txt = outro_text.replace("'", "").replace(":", " ")
        draw = (f",drawtext=text='{txt}':fontcolor=white:fontsize=56:x=(w-text_w)/2:y=1250:"
                f"alpha='min(1,max(0,(t-0.8)/0.6))'") if txt else ""
        fc = (f"color=c=0x0b0f19:s=1080x1920:d={d}:r=30[bg];"
              f"[1]format=rgba,scale=w='600*(1+0.08*t/{d})':h=-1:eval=frame,"
              f"fade=in:st=0:d=0.8:alpha=1[lg];"
              f"[bg][lg]overlay=(W-w)/2:(H-h)/2:shortest=1{draw}[outro];"
              f"anullsrc=r=44100:cl=stereo,atrim=0:{d}[oa];"
              f"[0:v][0:a][outro][oa]concat=n=2:v=1:a=1[v][a]")
        run(["ffmpeg", "-y", "-i", str(cur), "-loop", "1", "-t", str(d), "-i", str(LOGO),
             "-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-c:v", "libx264",
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(final)])
    else:
        shutil.copy(cur, final)
    for f in tmp.glob(f"{job}*"): f.unlink(missing_ok=True)
    return {"output_id": job, "url": f"/download/{job}"}

@app.get("/download/{job}")
async def download(job: str, x_token: str | None = Header(None), token: str | None = None):
    auth(x_token or token)
    p = STORE / "outputs" / f"{re.sub(r'[^a-f0-9]', '', job)}.mp4"
    if not p.exists(): raise HTTPException(404)
    return FileResponse(p, media_type="video/mp4", filename="moviecut.mp4")
