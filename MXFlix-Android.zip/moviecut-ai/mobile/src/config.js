// Endereço do SEU backend (nunca coloque a chave do YouTube aqui)
export const API_URL = "https://SEU-SERVIDOR.com";
export const APP_TOKEN = "troque-por-um-token-secreto";
