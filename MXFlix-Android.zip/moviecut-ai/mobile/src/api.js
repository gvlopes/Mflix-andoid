import { API_URL, APP_TOKEN } from "./config";
const H = { "x-token": APP_TOKEN };

export async function search(q) {
  const r = await fetch(`${API_URL}/search?q=${encodeURIComponent(q)}`, { headers: H });
  if (!r.ok) throw new Error("Falha na pesquisa");
  return r.json();
}
export async function upload(path, uri, name, type) {
  const f = new FormData();
  f.append("file", { uri, name, type });
  const r = await fetch(`${API_URL}${path}`, { method: "POST", headers: H, body: f });
  if (!r.ok) throw new Error("Falha no envio");
  return r.json();
}
export async function post(path, fields) {
  const f = new FormData();
  Object.entries(fields).forEach(([k, v]) => f.append(k, String(v)));
  const r = await fetch(`${API_URL}${path}`, { method: "POST", headers: H, body: f });
  if (!r.ok) throw new Error((await r.text()).slice(0, 200));
  return r.json();
}
export const downloadUrl = (u) => `${API_URL}${u}?token=${encodeURIComponent(APP_TOKEN)}`;
