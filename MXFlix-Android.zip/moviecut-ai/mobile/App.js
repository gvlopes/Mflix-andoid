import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, Image, StyleSheet,
         ActivityIndicator, Alert, Linking } from "react-native";
import { StatusBar } from "expo-status-bar";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { search, upload, post, downloadUrl } from "./src/api";

const C = { bg: "#0b0f19", card: "#1a2133", input: "#2a3347", accent: "#7c4dea", text: "#fff", mute: "#8b95ab" };
const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

export default function App() {
  const [q, setQ] = useState("Planeta dos Macacos");
  const [results, setResults] = useState([]);
  const [videoId, setVideoId] = useState(null);
  const [cuts, setCuts] = useState([]);
  const [busy, setBusy] = useState("");
  const [durs, setDurs] = useState([30]);
  const [subs, setSubs] = useState(true);
  const [pos, setPos] = useState("tr");
  const [phrase, setPhrase] = useState("Siga para mais cortes");
  const [outroSec, setOutroSec] = useState(3);
  const [outputUrl, setOutputUrl] = useState(null);

  const guard = (label, fn) => async () => {
    try { setBusy(label); await fn(); } catch (e) { Alert.alert("Erro", e.message); } finally { setBusy(""); }
  };

  const doSearch = guard("Pesquisando vídeos…", async () => setResults(await search(q)));

  const suggestCuts = async (id, d) => {
    const r = await post("/suggest", { video_id: id, durations: d.join(",") });
    setCuts(r.suggestions);
  };
  const toggleDur = (n) => {
    const d = durs.includes(n) ? durs.filter((x) => x !== n) : [...durs, n].sort((a, b) => a - b);
    if (!d.length) return;
    setDurs(d);
    if (videoId) guard("Buscando cortes…", () => suggestCuts(videoId, d))();
  };

  const pickVideo = guard("Enviando vídeo…", async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: "video/*" });
    if (r.canceled) return;
    const a = r.assets[0];
    const { video_id } = await upload("/upload", a.uri, a.name || "video.mp4", a.mimeType || "video/mp4");
    setVideoId(video_id);
    await suggestCuts(video_id, durs);
  });

  const pickLogo = guard("Enviando logomarca…", async () => {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"] });
    if (r.canceled) return;
    const a = r.assets[0];
    await upload("/logo", a.uri, "logo.png", "image/png");
    Alert.alert("Logomarca salva");
  });

  const render = (c) => guard("Gerando vídeo… (pode levar alguns minutos)", async () => {
    const r = await post("/render", { video_id: videoId, start: c.start, duration: c.duration,
      subtitles: subs, logo_pos: pos, outro_seconds: outroSec, outro_text: phrase });
    setOutputUrl(downloadUrl(r.url));
  })();

  const share = guard("Preparando compartilhamento…", async () => {
    const dest = FileSystem.cacheDirectory + "moviecut.mp4";
    await FileSystem.downloadAsync(outputUrl, dest);
    await Sharing.shareAsync(dest, { mimeType: "video/mp4" }); // WhatsApp, TikTok, Facebook... com revisão do usuário
  });

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 60 }}>
        <Text style={s.brand}>MOVIECUT AI</Text>

        <View style={s.card}>
          <Text style={s.label}>Novo projeto</Text>
          <Text style={s.h1}>Qual filme você deseja cortar?</Text>
          <TextInput style={s.input} value={q} onChangeText={setQ} placeholderTextColor={C.mute} />
          <Btn onPress={doSearch}>Pesquisar vídeos</Btn>
        </View>

        {results.map((v) => (
          <TouchableOpacity key={v.id} style={s.result} onPress={() => Linking.openURL(v.url)}>
            <Image source={{ uri: v.thumbnail }} style={s.thumb} />
            <View style={{ flex: 1 }}>
              <Text style={s.title} numberOfLines={2}>{v.title}</Text>
              <Text style={s.mute}>{fmt(v.duration)} · {v.channel}{v.official ? " · Oficial" : ""}</Text>
            </View>
          </TouchableOpacity>
        ))}
        {results.length > 0 && (
          <Text style={s.mute}>Assista ao material de referência e envie o arquivo que você tem autorização para usar.</Text>
        )}

        <Text style={s.h2}>Duração do corte</Text>
        <View style={s.grid}>
          {[10, 20, 30, 40, 50, 60].map((n) =>
            <Chip key={n} small on={durs.includes(n)} label={`${n}s`} onPress={() => toggleDur(n)} />)}
        </View>

        <Text style={s.h2}>Material autorizado</Text>
        <Btn onPress={pickVideo} alt>Enviar vídeo do celular</Btn>

        {cuts.length > 0 && <>
          <Text style={s.h2}>Cortes sugeridos pela IA</Text>
          {cuts.map((c) => (
            <TouchableOpacity key={`${c.duration}-${c.start}`} style={s.cut} onPress={() => render(c)}>
              <Text style={s.title}>{c.duration}s</Text>
              <Text style={s.mute}>Começa em {fmt(Math.round(c.start))} · toque para gerar</Text>
            </TouchableOpacity>
          ))}
        </>}

        <Text style={s.h2}>Configurações de edição</Text>
        <View style={s.grid}>
          <Chip on label="Formato 9:16" />
          <Chip on={subs} label="Legenda automática" onPress={() => setSubs(!subs)} />
          <Chip on label="Corte com IA" />
          <Chip on label="Logomarca final" onPress={pickLogo} />
        </View>
        <Text style={s.mute}>Posição da logo no vídeo</Text>
        <View style={s.grid}>
          {[["tl", "Topo esq."], ["tr", "Topo dir."], ["bl", "Base esq."], ["br", "Base dir."]].map(([k, l]) =>
            <Chip key={k} on={pos === k} label={l} onPress={() => setPos(k)} />)}
        </View>
        <TextInput style={s.input} value={phrase} onChangeText={setPhrase} placeholder="Frase da vinheta" placeholderTextColor={C.mute} />
        <View style={s.grid}>
          {[2, 3, 5].map((n) => <Chip key={n} on={outroSec === n} label={`Vinheta ${n}s`} onPress={() => setOutroSec(n)} />)}
        </View>

        {outputUrl && <View style={s.card}>
          <Text style={s.h1}>Vídeo pronto</Text>
          <Btn onPress={share}>Compartilhar / publicar</Btn>
        </View>}
      </ScrollView>
      {!!busy && <View style={s.busy}><ActivityIndicator color="#fff" size="large" /><Text style={s.title}>{busy}</Text></View>}
    </View>
  );
}

const Btn = ({ children, onPress, alt }) => (
  <TouchableOpacity style={[s.btn, alt && { backgroundColor: C.input }]} onPress={onPress}>
    <Text style={s.btnT}>{children}</Text>
  </TouchableOpacity>
);
const Chip = ({ label, on, onPress, small }) => (
  <TouchableOpacity onPress={onPress} style={[s.chip, small && { minWidth: "30%", alignItems: "center" }, on && { borderColor: C.accent }]}>
    <Text style={s.title}>{label}</Text>
  </TouchableOpacity>
);

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  brand: { color: C.mute, fontSize: 18, fontWeight: "800", letterSpacing: 1, marginBottom: 16 },
  card: { backgroundColor: C.card, borderRadius: 20, padding: 18, marginBottom: 16 },
  label: { color: C.mute, fontSize: 13 },
  h1: { color: C.text, fontSize: 22, fontWeight: "700", marginVertical: 10 },
  h2: { color: C.text, fontSize: 20, fontWeight: "700", marginTop: 24, marginBottom: 12 },
  input: { backgroundColor: C.input, color: C.text, borderRadius: 14, padding: 14, fontSize: 17, marginVertical: 10 },
  btn: { backgroundColor: C.accent, borderRadius: 14, padding: 16, alignItems: "center", marginVertical: 6 },
  btnT: { color: "#fff", fontSize: 17, fontWeight: "800" },
  result: { flexDirection: "row", gap: 12, backgroundColor: C.card, borderRadius: 14, padding: 10, marginBottom: 10 },
  thumb: { width: 120, height: 68, borderRadius: 8 },
  title: { color: C.text, fontSize: 15, fontWeight: "600" },
  mute: { color: C.mute, fontSize: 13, marginVertical: 4 },
  cut: { backgroundColor: C.card, borderRadius: 14, padding: 16, marginBottom: 10 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginVertical: 8 },
  chip: { backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 2, borderColor: "transparent", minWidth: "47%" },
  busy: { ...StyleSheet.absoluteFillObject, backgroundColor: "#000c", alignItems: "center", justifyContent: "center", gap: 12 },
});
