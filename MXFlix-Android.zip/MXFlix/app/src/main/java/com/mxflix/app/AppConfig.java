package com.mxflix.app;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Lê assets/app-config.json (gerado no painel em "Conexão do app"). */
public final class AppConfig {
    private AppConfig() {}
    private static final List<String> URLS = new ArrayList<>();

    public static void init(Context c) {
        URLS.clear();
        try (InputStream in = c.getAssets().open("app-config.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            JSONObject j = new JSONObject(out.toString("UTF-8"));
            add(j.optString("panel_url", ""));
            JSONArray a = j.optJSONArray("panel_urls");
            if (a != null) for (int i = 0; i < a.length(); i++) add(a.optString(i, ""));
        } catch (Exception ignored) {
            // sem arquivo (ou inválido): o app usa BuildConfig.PANEL_URL
        }
    }

    private static void add(String u) {
        u = normalize(u);
        if (!u.isEmpty() && !URLS.contains(u)) URLS.add(u);
    }

    public static String normalize(String u) {
        if (u == null) return "";
        u = u.trim();
        if (u.isEmpty()) return "";
        if (!u.matches("(?i)^https?://.*")) u = "https://" + u;
        u = u.replaceAll("[?#].*$", "").replaceAll("(?i)/(api(/.*)?|login\\.php|index\\.php)$", "");
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    public static List<String> urls() { return new ArrayList<>(URLS); }
}
