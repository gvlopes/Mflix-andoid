package com.mxflix.app;

import android.graphics.Color;
import org.json.JSONObject;

/** Configuração pública vinda do painel (cache local). */
public final class Cfg {
    private Cfg() {}
    private static JSONObject cached;
    private static String raw = "";

    private static JSONObject obj() {
        String s = Prefs.get("config_json", "{}");
        if (cached == null || !s.equals(raw)) {
            raw = s;
            try { cached = new JSONObject(s); } catch (Exception e) { cached = new JSONObject(); }
        }
        return cached;
    }

    public static String get(String k, String d) {
        String v = obj().optString(k, "");
        return v.isEmpty() ? d : v;
    }

    public static int color(String k, String def) {
        try { return Color.parseColor(get(k, def)); } catch (Exception e) { return Color.parseColor(def); }
    }

    public static int primary() { return color("primary_color", "#00d8ff"); }
    public static int secondary() { return color("secondary_color", "#7854ff"); }
    public static String appName() { return get("app_name", "MXFlix"); }
}
