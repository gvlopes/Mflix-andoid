package com.mxflix.app;

import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {
    private LinearLayout col;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(UI.BG);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        col.setPadding(p, p, p, p);
        sv.addView(col);
        setContentView(sv);
        build();
    }

    private void row(String title, String value, Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true); row.setClickable(true);
        row.setBackground(UI.focusBg(this, UI.SURFACE, 12));
        int pad = UI.dp(this, 14);
        row.setPadding(pad, pad, pad, pad);
        row.addView(UI.text(this, title, 15, UI.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        if (value != null) row.addView(UI.text(this, value, 14, Cfg.primary(), false));
        row.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = UI.dp(this, 8);
        col.addView(row, lp);
    }

    private void build() {
        col.removeAllViews();
        col.addView(UI.text(this, T.t("Ajustes"), 22, UI.WHITE, true));

        row(T.t("Atualizar conteúdo"), null, () -> {
            UI.toast(this, T.t("Atualizando conteúdo..."));
            Repo.load(this, true, new Repo.Listener() {
                @Override public void progress(String m) { }
                @Override public void done(String err) { UI.toast(SettingsActivity.this, err == null ? "OK ✓" : err); }
            });
        });
        row(T.t("Limpar cache"), null, () -> { Store.get(this).clearCache(); UI.toast(this, "Cache limpo; favoritos e histórico preservados."); });
        row(T.t("Limpar histórico"), null, () -> { Store.get(this).clearHistory(Repo.session()); UI.toast(this, "OK ✓"); });

        row(T.t("Formato ao vivo"), Repo.liveFormat().toUpperCase(), () -> {
            Prefs.put("live_format", "m3u8".equals(Repo.liveFormat()) ? "ts" : "m3u8");
            build();
        });
        row(T.t("Avançar episódio automaticamente"), Prefs.bool("autoplay_next", true) ? "ON" : "OFF", () -> {
            Prefs.putBool("autoplay_next", !Prefs.bool("autoplay_next", true));
            build();
        });

        row(T.t("Controle parental"), Repo.hasPin() ? "PIN ✓" : "—", this::changePin);
        if (Repo.hasPin()) row("Remover PIN", null, () -> UI.askPin(this, () -> {
            Prefs.remove("pin_hash");
            build();
        }));
        row(T.t("Conteúdo adulto"), Prefs.bool("show_adult", false) ? "ON" : "OFF", () -> {
            final boolean on = Prefs.bool("show_adult", false);
            if (on) { Prefs.putBool("show_adult", false); build(); return; }
            UI.askPin(this, () -> { Prefs.putBool("show_adult", true); build(); });
        });
        row(T.t("Categorias ocultas"), null, this::hiddenCategories);

        row("Sobre", "v" + BuildConfig.VERSION_NAME, () -> new AlertDialog.Builder(this)
                .setMessage(Cfg.appName() + " " + BuildConfig.VERSION_NAME + "\nPainel: " + Panel.baseUrl() + "\n" + T.t("ID do aparelho") + ": " + Panel.friendlyId())
                .setPositiveButton(T.t("Fechar"), null).show());
    }

    private void changePin() {
        if (Repo.hasPin()) UI.askPin(this, this::newPin); else newPin();
    }

    private void newPin() {
        final EditText e = UI.input(this, "4-8", true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("PIN").setView(UI.pad(this, e))
                .setPositiveButton(T.t("Confirmar"), (d, w) -> {
                    String pin = e.getText().toString().trim();
                    if (!pin.matches("\\d{4,8}")) { UI.toast(this, "PIN: 4 a 8 dígitos."); return; }
                    Prefs.put("pin_hash", Repo.sha256(pin));
                    Panel.syncPin(pin);
                    build();
                }).setNegativeButton(T.t("Cancelar"), null).show();
    }

    private void hiddenCategories() {
        final List<String> keys = new ArrayList<>(), labels = new ArrayList<>();
        for (Cat c : Repo.liveCats) { keys.add("live:" + c.id); labels.add(T.t("Ao Vivo") + " · " + c.name); }
        for (Cat c : Repo.vodCats) { keys.add("vod:" + c.id); labels.add(T.t("Filmes") + " · " + c.name); }
        for (Cat c : Repo.seriesCats) { keys.add("series:" + c.id); labels.add(T.t("Séries") + " · " + c.name); }
        if (keys.isEmpty()) { UI.toast(this, T.t("Nenhum resultado.")); return; }
        final Set<String> hidden = Repo.hiddenCats();
        final boolean[] checked = new boolean[keys.size()];
        for (int i = 0; i < keys.size(); i++) checked[i] = hidden.contains(keys.get(i));
        new AlertDialog.Builder(this).setTitle(T.t("Categorias ocultas"))
                .setMultiChoiceItems(labels.toArray(new String[0]), checked, (d, i, on) -> checked[i] = on)
                .setPositiveButton(T.t("Confirmar"), (d, w) -> {
                    Set<String> s = new HashSet<>();
                    for (int i = 0; i < keys.size(); i++) if (checked[i]) s.add(keys.get(i));
                    Repo.setHiddenCats(s);
                }).setNegativeButton(T.t("Cancelar"), null).show();
    }
}
