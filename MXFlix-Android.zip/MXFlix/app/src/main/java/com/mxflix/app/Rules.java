package com.mxflix.app;

import java.util.regex.Pattern;
import org.json.JSONObject;

/** Regras de negócio reaproveitadas do app original (normalização, adulto, conta). */
public final class Rules {
    private Rules() {}
    private static final Pattern ADULT = Pattern.compile(".*(adult|xxx|porn|18\\+).*", Pattern.CASE_INSENSITIVE);
    private static final Pattern KIDS = Pattern.compile(".*\\b(kids|infantil|infantis|criancas|children|desenhos)\\b.*", Pattern.CASE_INSENSITIVE);

    public static boolean adult(String name) { return name != null && ADULT.matcher(name).matches(); }
    public static boolean kids(String name) { return name != null && KIDS.matcher(name).matches(); }

    /** http://host:porta — remove /player_api.php, /get.php, barras finais e espaços. */
    public static String normalizeServer(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.isEmpty()) return "";
        if (!s.matches("(?i)^https?://.*")) s = "http://" + s;
        int q = s.indexOf('?');
        if (q > 0) s = s.substring(0, q);
        s = s.replaceAll("(?i)/(player_api|get|panel_api|c)\\.php$", "");
        s = s.replaceAll("/+$", "");
        return s;
    }

    public static String mediaExtension(String ext) {
        if (ext == null || ext.trim().isEmpty()) return "mp4";
        return ext.trim().replace(".", "");
    }

    /** Retorna null se a conta está OK; senão, a mensagem de erro. */
    public static String accountError(JSONObject userInfo, long nowSec) {
        if (userInfo == null) return "Resposta inválida do servidor.";
        String auth = userInfo.optString("auth", "0");
        if (!"1".equals(auth) && !"true".equalsIgnoreCase(auth)) return "Usuário ou senha inválidos.";
        String status = userInfo.optString("status", "Active");
        if (!status.isEmpty() && !"active".equalsIgnoreCase(status)) {
            if ("expired".equalsIgnoreCase(status)) return "Assinatura vencida. Fale com o suporte para continuar assistindo.";
            if ("banned".equalsIgnoreCase(status)) return "Conta bloqueada pelo servidor.";
            return "Conta desativada. Fale com o suporte.";
        }
        String exp = userInfo.optString("exp_date", "");
        if (exp.matches("\\d{6,12}")) {
            long e = Long.parseLong(exp);
            if (e > 0 && e < nowSec) return "Assinatura vencida. Fale com o suporte para continuar assistindo.";
        }
        return null;
    }
}
