package com.mxflix.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;
import java.util.Random;

/** Abertura: a logo aparece despedaçada em triângulos que voam e se encaixam, seguida de um brilho. */
public class ShatterLogoView extends View {
    private static final int GRID = 7;                       // 7x7 células -> 98 triângulos
    private static final int COUNT = GRID * GRID * 2;
    private final Bitmap bmp;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path[] tri = new Path[COUNT];              // em coordenadas 0..1
    private final float[] cx = new float[COUNT], cy = new float[COUNT];
    private final float[] sx = new float[COUNT], sy = new float[COUNT], sr = new float[COUNT], ss = new float[COUNT], dl = new float[COUNT];
    private final Path work = new Path();
    private final android.graphics.RectF dst = new android.graphics.RectF();
    private final android.graphics.Matrix m = new android.graphics.Matrix();
    private float t = 0f;
    private Runnable onEnd;
    private ValueAnimator anim;

    public ShatterLogoView(Context c) {
        super(c);
        Bitmap raw = BitmapFactory.decodeResource(c.getResources(), R.drawable.mx_logo);
        bmp = raw;
        Random r = new Random(7);
        int k = 0;
        float s = 1f / GRID;
        for (int gy = 0; gy < GRID; gy++) for (int gx = 0; gx < GRID; gx++) {
            float x0 = gx * s, y0 = gy * s, x1 = x0 + s, y1 = y0 + s;
            boolean flip = r.nextBoolean();
            float[][] a = flip ? new float[][]{{x0, y0}, {x1, y0}, {x1, y1}} : new float[][]{{x0, y0}, {x1, y0}, {x0, y1}};
            float[][] b = flip ? new float[][]{{x0, y0}, {x1, y1}, {x0, y1}} : new float[][]{{x1, y0}, {x1, y1}, {x0, y1}};
            for (float[][] p : new float[][][]{a, b}) {
                Path path = new Path();
                path.moveTo(p[0][0], p[0][1]); path.lineTo(p[1][0], p[1][1]); path.lineTo(p[2][0], p[2][1]); path.close();
                tri[k] = path;
                cx[k] = (p[0][0] + p[1][0] + p[2][0]) / 3f; cy[k] = (p[0][1] + p[1][1] + p[2][1]) / 3f;
                double ang = r.nextDouble() * Math.PI * 2;
                float dist = 0.7f + r.nextFloat() * 1.3f;           // em "tamanhos da logo"
                sx[k] = (float) Math.cos(ang) * dist; sy[k] = (float) Math.sin(ang) * dist;
                sr[k] = (r.nextFloat() - 0.5f) * 720f;
                ss[k] = 0.2f + r.nextFloat() * 1.0f;
                dl[k] = r.nextFloat() * 0.42f;
                k++;
            }
        }
    }

    public void start(long durationMs, Runnable end) {
        onEnd = end;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(durationMs);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) { if (onEnd != null) onEnd.run(); }
        });
        anim.start();
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float size = Math.min(w, h);
        float ox = (w - size) / 2f, oy = (h - size) / 2f;

        // brilho atrás da logo (cresce no fim da montagem)
        float g = clamp((t - 0.62f) / 0.38f);
        if (g > 0) {
            float pulse = (float) Math.sin(g * Math.PI);          // sobe e desce
            int col = Cfg.primary();
            glow.setShader(new RadialGradient(w / 2f, h / 2f, size * (0.55f + 0.35f * g), new int[]{(col & 0x00FFFFFF) | ((int) (150 * pulse) << 24), 0x00000000}, null, Shader.TileMode.CLAMP));
            c.drawCircle(w / 2f, h / 2f, size, glow);
        }

        for (int i = 0; i < COUNT; i++) {
            float p = clamp((t - dl[i]) / 0.58f);
            float e = 1f - (1f - p) * (1f - p) * (1f - p);        // easeOutCubic
            float inv = 1f - e;
            float dx = sx[i] * size * inv, dy = sy[i] * size * inv;
            float rot = sr[i] * inv;
            float sc = 1f + (ss[i] - 1f) * inv;
            int alpha = (int) (255 * clamp(p * 2.5f));
            if (alpha <= 0) continue;
            paint.setAlpha(alpha);
            c.save();
            float pcx = ox + cx[i] * size, pcy = oy + cy[i] * size;
            c.translate(dx, dy);
            c.rotate(rot, pcx, pcy);
            c.scale(sc, sc, pcx, pcy);
            m.setScale(size, size);
            m.postTranslate(ox, oy);
            work.set(tri[i]);
            work.transform(m);
            c.clipPath(work);
            dst.set(ox, oy, ox + size, oy + size);
            c.drawBitmap(bmp, null, dst, paint);
            c.restore();
        }
    }

    private static float clamp(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    @Override protected void onDetachedFromWindow() { if (anim != null) { anim.removeAllListeners(); anim.cancel(); } super.onDetachedFromWindow(); }
}
