package com.mxflix.app;

import android.net.Uri;
import android.util.Base64;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;

/** Cliente da API Xtream Codes (player_api.php). */
public class Xtream {
    public final String base, user, pass;
    public Xtream(String base, String user, String pass) { this.base = base; this.user = user; this.pass = pass; }

    private String api(String action, String extra) {
        String u = base + "/player_api.php?username=" + Uri.encode(user) + "&password=" + Uri.encode(pass);
        if (action != null) u += "&action=" + action;
        if (extra != null) u += extra;
        return u;
    }

    public String raw(String action, String extra) throws IOException {
        Http.Result r = Http.get(api(action, extra), null);
        if (r.code < 200 || r.code >= 300) throw new IOException("HTTP " + r.code);
        return r.body;
    }

    public JSONObject auth() throws Exception {
        return new JSONObject(raw(null, null));
    }

    public JSONObject seriesInfo(String id) throws Exception { return new JSONObject(raw("get_series_info", "&series_id=" + Uri.encode(id))); }
    public JSONObject vodInfo(String id) throws Exception { return new JSONObject(raw("get_vod_info", "&vod_id=" + Uri.encode(id))); }

    /** Retorna [agora, a seguir] (títulos) ou array vazio. */
    public String[] shortEpg(String streamId) {
        try {
            JSONObject j = new JSONObject(raw("get_short_epg", "&stream_id=" + Uri.encode(streamId) + "&limit=2"));
            JSONArray a = j.optJSONArray("epg_listings");
            if (a == null || a.length() == 0) return new String[0];
            String[] out = new String[Math.min(2, a.length())];
            for (int i = 0; i < out.length; i++) out[i] = b64(a.getJSONObject(i).optString("title", ""));
            return out;
        } catch (Exception e) { return new String[0]; }
    }

    private static String b64(String s) {
        if (s.isEmpty()) return s;
        try { return new String(Base64.decode(s, Base64.DEFAULT), "UTF-8"); } catch (Exception e) { return s; }
    }

    public String liveUrl(String id, String fmt) { return base + "/live/" + Uri.encode(user) + "/" + Uri.encode(pass) + "/" + id + "." + fmt; }
    public String movieUrl(String id, String ext) { return base + "/movie/" + Uri.encode(user) + "/" + Uri.encode(pass) + "/" + id + "." + Rules.mediaExtension(ext); }
    public String seriesUrl(String id, String ext) { return base + "/series/" + Uri.encode(user) + "/" + Uri.encode(pass) + "/" + id + "." + Rules.mediaExtension(ext); }
    public String catchupUrl(String id, long startSec, int minutes) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm", java.util.Locale.US);
        return base + "/timeshift/" + Uri.encode(user) + "/" + Uri.encode(pass) + "/" + minutes + "/" + f.format(new java.util.Date(startSec * 1000)) + "/" + id + ".ts";
    }
}
