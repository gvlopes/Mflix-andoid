package com.mxflix.app;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/** Card de canal (logo) ou pôster (filme/série/episódio). */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
    public interface Click { void on(Item item, int position); }

    private final List<Item> data = new ArrayList<>();
    private final int widthDp;
    private final Click click, longClick;
    private final String session = Repo.session();

    public ItemAdapter(int widthDp, Click click, Click longClick) {
        this.widthDp = widthDp; this.click = click; this.longClick = longClick;
    }

    public void set(List<Item> items) { data.clear(); data.addAll(items); notifyDataSetChanged(); }
    public List<Item> items() { return data; }

    static class VH extends RecyclerView.ViewHolder {
        final ImageView img; final TextView name; final TextView badge; final LinearLayout card;
        VH(View v, LinearLayout card, ImageView img, TextView name, TextView badge) { super(v); this.card = card; this.img = img; this.name = name; this.badge = badge; }
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int type) {
        Context c = p.getContext();
        boolean live = type == 1;
        FrameLayout cell = new FrameLayout(c);
        cell.setLayoutParams(new RecyclerView.LayoutParams(widthDp == 0 ? -1 : -2, -2));
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setFocusable(true); card.setClickable(true);
        card.setBackground(UI.focusBg(c, UI.SURFACE, 12));
        int pad = UI.dp(c, 6);
        card.setPadding(pad, pad, pad, pad);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(UI.dp(c, widthDp == 0 ? 130 : widthDp), -2);
        cl.gravity = Gravity.CENTER_HORIZONTAL;
        cl.setMargins(pad, pad, pad, pad);
        cell.addView(card, cl);

        FrameLayout imgBox = new FrameLayout(c);
        ImageView img = new ImageView(c);
        img.setScaleType(live ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
        imgBox.addView(img, new FrameLayout.LayoutParams(-1, -1));
        TextView badge = UI.text(c, "", 10, Color.WHITE, true);
        badge.setBackground(UI.round(c, 0xCCE50914, 6));
        badge.setPadding(UI.dp(c, 6), UI.dp(c, 2), UI.dp(c, 6), UI.dp(c, 2));
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-2, -2);
        bl.gravity = Gravity.TOP | Gravity.END; bl.setMargins(0, UI.dp(c, 4), UI.dp(c, 4), 0);
        imgBox.addView(badge, bl);
        int w = UI.dp(c, widthDp == 0 ? 118 : widthDp - 12);
        int h = live ? UI.dp(c, 70) : (int) (w * 1.5f);
        card.addView(imgBox, new LinearLayout.LayoutParams(-1, h));
        TextView name = UI.text(c, "", 12, UI.WHITE, false);
        name.setMaxLines(2); name.setEllipsize(TextUtils.TruncateAt.END); name.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(name, UI.lp(-1, -2, 6, c));
        UI.scaleOnFocus(card);
        return new VH(cell, card, img, name, badge);
    }

    @Override public int getItemViewType(int pos) { return "live".equals(data.get(pos).kind) ? 1 : 0; }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        final Item it = data.get(pos);
        h.name.setText(it.name);
        boolean live = "live".equals(it.kind);
        UI.image(h.img, it.cover, live ? R.drawable.ic_live : R.drawable.ic_play);
        h.badge.setVisibility(it.rating > 0 && !live ? View.VISIBLE : View.GONE);
        if (it.rating > 0) h.badge.setText("★ " + String.format(java.util.Locale.US, "%.1f", it.rating));
        h.card.setOnClickListener(v -> { int p = h.getBindingAdapterPosition(); if (p >= 0 && click != null) click.on(data.get(p), p); });
        h.card.setOnLongClickListener(v -> {
            int p = h.getBindingAdapterPosition();
            if (p >= 0 && longClick != null) { longClick.on(data.get(p), p); return true; }
            return false;
        });
    }

    @Override public int getItemCount() { return data.size(); }
}
