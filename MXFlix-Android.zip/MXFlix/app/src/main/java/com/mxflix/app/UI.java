package com.mxflix.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.bumptech.glide.Glide;

/** Helpers de interface (a UI é montada por código, igual ao app original). */
public final class UI {
    private UI() {}
    public static int BG = 0xFF0A0305, SURFACE = 0xFF1A0A0D, SURFACE2 = 0xFF2A1015, WHITE = 0xFFFFFFFF, MUTED = 0xFFB5A3A6;

    public static int dp(Context c, float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()); }

    public static GradientDrawable round(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(c, radiusDp * Theme.radius));
        return g;
    }

    /** Fundo que ganha contorno colorido ao receber foco (controle remoto) ou toque. */
    public static StateListDrawable focusBg(Context c, int color, int radiusDp) {
        GradientDrawable focused = round(c, brighten(color), radiusDp);
        focused.setStroke(dp(c, 2), Cfg.primary());
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, focused);
        s.addState(new int[]{android.R.attr.state_pressed}, focused);
        s.addState(new int[]{}, round(c, color, radiusDp));
        return s;
    }

    private static int brighten(int c) {
        int r = Math.min(255, Color.red(c) + 24), g = Math.min(255, Color.green(c) + 24), b = Math.min(255, Color.blue(c) + 24);
        return Color.argb(Color.alpha(c), r, g, b);
    }

    public static void scaleOnFocus(final View v) {
        v.setOnFocusChangeListener((x, f) -> x.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).setDuration(120).start());
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(font(bold));
        return t;
    }

    public static TextView button(Context c, String label, final Runnable onClick) {
        TextView t = text(c, label, 15, WHITE, true);
        t.setGravity(Gravity.CENTER);
        int ph = dp(c, 18), pv = dp(c, 12);
        t.setPadding(ph, pv, ph, pv);
        t.setBackground(focusBg(c, SURFACE2, 12));
        t.setFocusable(true); t.setClickable(true);
        t.setOnClickListener(v -> onClick.run());
        scaleOnFocus(t);
        return t;
    }

    public static TextView primaryButton(Context c, String label, final Runnable onClick) {
        TextView t = button(c, label, onClick);
        float r = dp(c, 12 * Theme.radius);
        if ("outline".equals(Theme.button)) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0x00000000); g.setStroke(dp(c, 2), Theme.primary); g.setCornerRadius(r);
            t.setBackground(g); t.setTextColor(Theme.primary);
        } else {
            GradientDrawable g = "solid".equals(Theme.button)
                    ? new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Theme.primary, Theme.primary})
                    : new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Theme.primary, Theme.secondary});
            g.setCornerRadius(r);
            t.setBackground(g); t.setTextColor(onColor(Theme.primary));
        }
        return t;
    }

    /** Branco ou preto, conforme o contraste com a cor de fundo. */
    public static int onColor(int bg) {
        double lum = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0;
        return lum > 0.62 ? 0xFF0A0A0A : 0xFFFFFFFF;
    }

    public static Typeface font(boolean bold) {
        String fam;
        switch (Theme.font) {
            case "serif": fam = "serif"; break;
            case "mono": fam = "monospace"; break;
            case "condensed": fam = "sans-serif-condensed"; break;
            case "rounded": fam = "sans-serif-medium"; break;
            default: fam = null;
        }
        return Typeface.create(fam, bold ? Typeface.BOLD : Typeface.NORMAL);
    }

    /** Cor de fundo do tema com transparência (a = 0..255). */
    public static int alpha(int a) { return (a << 24) | (BG & 0x00FFFFFF); }

    /** Converte a imagem para tons de cinza e pinta com a cor (usado nas artes para seguir o tema). */
    public static void colorize(ImageView iv, int color) {
        android.graphics.ColorMatrix gray = new android.graphics.ColorMatrix();
        gray.setSaturation(0);
        float k = 1.9f;
        float r = Color.red(color) / 255f * k, g = Color.green(color) / 255f * k, b = Color.blue(color) / 255f * k;
        android.graphics.ColorMatrix tint = new android.graphics.ColorMatrix(new float[]{r, 0, 0, 0, 0, 0, g, 0, 0, 0, 0, 0, b, 0, 0, 0, 0, 0, 1, 0});
        gray.postConcat(tint);
        iv.setColorFilter(new android.graphics.ColorMatrixColorFilter(gray));
    }

    public static android.graphics.Bitmap tintBitmap(android.graphics.Bitmap src, int color) {
        android.graphics.Bitmap out = android.graphics.Bitmap.createBitmap(src.getWidth(), src.getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.ColorMatrix gray = new android.graphics.ColorMatrix();
        gray.setSaturation(0);
        float k = 1.9f;
        android.graphics.ColorMatrix tint = new android.graphics.ColorMatrix(new float[]{Color.red(color) / 255f * k, 0, 0, 0, 0, 0, Color.green(color) / 255f * k, 0, 0, 0, 0, 0, Color.blue(color) / 255f * k, 0, 0, 0, 0, 0, 1, 0});
        gray.postConcat(tint);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        p.setColorFilter(new android.graphics.ColorMatrixColorFilter(gray));
        new Canvas(out).drawBitmap(src, 0, 0, p);
        return out;
    }

    public static String logoUrl() { return Theme.logoUrl.isEmpty() ? Cfg.get("logo", "") : Theme.logoUrl; }

    /** Logo: URL do painel/tema, ou a logo embutida pintada com a cor do tema. */
    public static void logo(ImageView iv) {
        String u = logoUrl();
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (u.isEmpty()) { iv.setImageResource(R.drawable.mx_logo); colorize(iv, Theme.primary); }
        else { iv.clearColorFilter(); image(iv, u, R.drawable.mx_logo); iv.setScaleType(ImageView.ScaleType.FIT_CENTER); }
    }

    /** Fundo das telas: imagem do tema/painel, ou arte embutida colorida, ou degradê liso. */
    public static void background(ImageView bg) {
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        String u = !Theme.bgUrl.isEmpty() ? Theme.bgUrl : Cfg.get("background", "");
        if (!u.isEmpty()) { bg.clearColorFilter(); Glide.with(bg.getContext()).load(u).centerCrop().into(bg); return; }
        if (!Theme.bgImage) {
            bg.clearColorFilter();
            bg.setImageDrawable(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Theme.background, Theme.surface}));
            return;
        }
        bg.setImageResource(R.drawable.mx_background);
        colorize(bg, Theme.bgTint);
    }

    public static EditText input(Context c, String hint, boolean password) {
        EditText e = new EditText(c);
        e.setHint(hint); e.setHintTextColor(MUTED); e.setTextColor(WHITE); e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(password ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : InputType.TYPE_CLASS_TEXT);
        int p = dp(c, 14);
        e.setPadding(p, p, p, p);
        e.setBackground(focusBg(c, SURFACE, 10));
        return e;
    }

    public static LinearLayout.LayoutParams lp(int w, int h, int topDp, Context c) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(w, h);
        l.topMargin = dp(c, topDp);
        return l;
    }

    public static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_LONG).show(); }

    public static void image(ImageView iv, String url, int placeholderRes) {
        if (url == null || url.isEmpty()) { iv.setImageResource(placeholderRes); return; }
        Glide.with(iv.getContext()).load(url).placeholder(placeholderRes).error(placeholderRes).centerCrop().into(iv);
    }

    public static void fullscreen(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    public static void openUrl(Context c, String url) {
        try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { toast(c, url); }
    }

    public interface PinResult { void ok(); }

    /** Pede o PIN parental; chama ok() se correto. Sem PIN definido, passa direto. */
    public static void askPin(final Context c, final PinResult r) {
        if (!Repo.hasPin()) { r.ok(); return; }
        final EditText e = input(c, T.t("Digite o PIN"), true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(c).setTitle(T.t("Controle parental")).setView(pad(c, e))
                .setPositiveButton(T.t("Confirmar"), (d, w) -> {
                    if (Repo.checkPin(e.getText().toString().trim())) r.ok(); else toast(c, T.t("PIN incorreto."));
                }).setNegativeButton(T.t("Cancelar"), null).show();
    }

    public static View pad(Context c, View v) {
        LinearLayout l = new LinearLayout(c);
        int p = dp(c, 20);
        l.setPadding(p, p / 2, p, 0);
        l.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    public static ColorDrawable solid(int c) { return new ColorDrawable(c); }
}
