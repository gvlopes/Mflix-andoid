package com.mxflix.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.bumptech.glide.Glide;

/** Helpers de interface (a UI é montada por código, igual ao app original). */
public final class UI {
    private UI() {}
    public static final int BG = 0xFF050B16, SURFACE = 0xFF0B1A33, SURFACE2 = 0xFF12294D, WHITE = 0xFFFFFFFF, MUTED = 0xFF9FB4D1;

    public static int dp(Context c, float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()); }

    public static GradientDrawable round(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    /** Fundo que ganha contorno colorido ao receber foco (controle remoto) ou toque. */
    public static StateListDrawable focusBg(Context c, int color, int radiusDp) {
        GradientDrawable focused = round(c, brighten(color), radiusDp);
        focused.setStroke(dp(c, 2), Cfg.primary());
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, focused);
        s.addState(new int[]{android.R.attr.state_pressed}, focused);
        s.addState(new int[]{}, round(c, color, radiusDp));
        return s;
    }

    private static int brighten(int c) {
        int r = Math.min(255, Color.red(c) + 24), g = Math.min(255, Color.green(c) + 24), b = Math.min(255, Color.blue(c) + 24);
        return Color.argb(Color.alpha(c), r, g, b);
    }

    public static void scaleOnFocus(final View v) {
        v.setOnFocusChangeListener((x, f) -> x.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).setDuration(120).start());
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView button(Context c, String label, final Runnable onClick) {
        TextView t = text(c, label, 15, WHITE, true);
        t.setGravity(Gravity.CENTER);
        int ph = dp(c, 18), pv = dp(c, 12);
        t.setPadding(ph, pv, ph, pv);
        t.setBackground(focusBg(c, SURFACE2, 12));
        t.setFocusable(true); t.setClickable(true);
        t.setOnClickListener(v -> onClick.run());
        scaleOnFocus(t);
        return t;
    }

    public static TextView primaryButton(Context c, String label, final Runnable onClick) {
        TextView t = button(c, label, onClick);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Cfg.primary(), Cfg.secondary()});
        g.setCornerRadius(dp(c, 12));
        t.setBackground(g);
        t.setTextColor(0xFFFFFFFF);
        return t;
    }

    public static EditText input(Context c, String hint, boolean password) {
        EditText e = new EditText(c);
        e.setHint(hint); e.setHintTextColor(MUTED); e.setTextColor(WHITE); e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(password ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : InputType.TYPE_CLASS_TEXT);
        int p = dp(c, 14);
        e.setPadding(p, p, p, p);
        e.setBackground(focusBg(c, SURFACE, 10));
        return e;
    }

    public static LinearLayout.LayoutParams lp(int w, int h, int topDp, Context c) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(w, h);
        l.topMargin = dp(c, topDp);
        return l;
    }

    public static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_LONG).show(); }

    public static void image(ImageView iv, String url, int placeholderRes) {
        if (url == null || url.isEmpty()) { iv.setImageResource(placeholderRes); return; }
        Glide.with(iv.getContext()).load(url).placeholder(placeholderRes).error(placeholderRes).centerCrop().into(iv);
    }

    public static void fullscreen(Activity a) {
        a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    public static void openUrl(Context c, String url) {
        try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { toast(c, url); }
    }

    public interface PinResult { void ok(); }

    /** Pede o PIN parental; chama ok() se correto. Sem PIN definido, passa direto. */
    public static void askPin(final Context c, final PinResult r) {
        if (!Repo.hasPin()) { r.ok(); return; }
        final EditText e = input(c, T.t("Digite o PIN"), true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(c).setTitle(T.t("Controle parental")).setView(pad(c, e))
                .setPositiveButton(T.t("Confirmar"), (d, w) -> {
                    if (Repo.checkPin(e.getText().toString().trim())) r.ok(); else toast(c, T.t("PIN incorreto."));
                }).setNegativeButton(T.t("Cancelar"), null).show();
    }

    public static View pad(Context c, View v) {
        LinearLayout l = new LinearLayout(c);
        int p = dp(c, 20);
        l.setPadding(p, p / 2, p, 0);
        l.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return l;
    }

    public static ColorDrawable solid(int c) { return new ColorDrawable(c); }
}
