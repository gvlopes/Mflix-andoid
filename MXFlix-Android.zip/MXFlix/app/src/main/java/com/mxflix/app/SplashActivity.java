package com.mxflix.app;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

/** Tela de carregamento: logo + nome, barra de progresso e "Conectando ao painel...". */
public class SplashActivity extends AppCompatActivity {
    private TextView status;
    private LinearLayout root;
    private ValueAnimator anim;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(HomeActivity.NAVY);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        UI.image(bg, Cfg.get("background", ""), R.drawable.mx_background);
        frame.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xB0040A14, 0xE6050E1E}));
        frame.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        UI.image(logo, Cfg.get("logo", ""), R.drawable.mx_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brand.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 64), UI.dp(this, 64)));
        TextView name = UI.text(this, Cfg.appName(), 34, UI.WHITE, true);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
        nl.leftMargin = UI.dp(this, 14);
        brand.addView(name, nl);
        root.addView(brand);

        // barra de progresso contínua
        final int trackW = UI.dp(this, 340), segW = UI.dp(this, 130);
        FrameLayout track = new FrameLayout(this);
        track.setBackgroundColor(0x33FFFFFF);
        final View seg = new View(this);
        seg.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x001EA7FD, HomeActivity.CYAN, 0x001EA7FD}));
        track.addView(seg, new FrameLayout.LayoutParams(segW, -1));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(trackW, UI.dp(this, 2));
        tl.topMargin = UI.dp(this, 36);
        root.addView(track, tl);
        anim = ValueAnimator.ofFloat(-segW, trackW);
        anim.setDuration(1400); anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> seg.setTranslationX((Float) a.getAnimatedValue()));
        anim.start();

        status = UI.text(this, "Conectando ao painel...", 15, UI.WHITE, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, UI.lp(-2, -2, 40, this));
        setContentView(frame);
        start();
    }

    private LinearLayout failBox;

    private void start() {
        if (failBox != null) { root.removeView(failBox); failBox = null; }
        status.setText("Conectando ao painel...");
        if (!Panel.isConfigured()) { askPanel(); return; }
        Repo.async(() -> {
            try { return Panel.config(); }
            catch (Panel.PanelException e) {
                // sem cache local ou em manutenção: mostra o erro; com cache, segue offline
                if (e.code == 503 || Prefs.get("config_json", "").isEmpty()) throw new Exception(e.getMessage() + "\n\n" + Panel.baseUrl() + "/api/config.php");
                return null;
            }
        }, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { next(); }
            @Override public void fail(String error) { showFail(error); }
        });
    }

    private void showFail(String error) {
        status.setText(error);
        status.setGravity(Gravity.CENTER);
        failBox = new LinearLayout(this);
        failBox.setOrientation(LinearLayout.VERTICAL);
        failBox.setGravity(Gravity.CENTER_HORIZONTAL);
        failBox.addView(UI.primaryButton(this, T.t("Tentar novamente"), this::start), UI.lp(-2, -2, 16, this));
        failBox.addView(UI.button(this, "Trocar URL do painel", this::askPanel), UI.lp(-2, -2, 8, this));
        root.addView(failBox);
    }

    private void askPanel() {
        final EditText e = UI.input(this, "https://seu-painel.com", false);
        if (Panel.isConfigured()) e.setText(Panel.baseUrl());
        new AlertDialog.Builder(this).setTitle("URL do painel").setView(UI.pad(this, e)).setCancelable(Panel.isConfigured())
                .setPositiveButton("OK", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) { askPanel(); return; }
                    Panel.setBaseUrl(s);
                    start();
                }).show();
    }

    private void next() {
        Intent i = new Intent(this, Repo.loggedIn() ? HomeActivity.class : LoginActivity.class);
        startActivity(i);
        finish();
    }

    @Override protected void onDestroy() { if (anim != null) anim.cancel(); super.onDestroy(); }
}
