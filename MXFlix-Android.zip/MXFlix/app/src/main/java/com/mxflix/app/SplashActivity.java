package com.mxflix.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {
    private TextView status;
    private LinearLayout root;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(UI.BG);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.mx_logo);
        root.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 120), UI.dp(this, 120)));
        TextView name = UI.text(this, "MXFlix", 28, UI.WHITE, true);
        name.setGravity(Gravity.CENTER);
        root.addView(name, UI.lp(-2, -2, 12, this));
        status = UI.text(this, T.t("Carregando..."), 14, UI.MUTED, false);
        root.addView(status, UI.lp(-2, -2, 8, this));
        setContentView(root);
        start();
    }

    private LinearLayout failBox;

    private void start() {
        if (failBox != null) { root.removeView(failBox); failBox = null; }
        status.setText(T.t("Carregando...") + "\n" + Panel.baseUrl());
        if (!Panel.isConfigured()) { askPanel(); return; }
        Repo.async(() -> {
            try { return Panel.config(); }
            catch (Panel.PanelException e) {
                // sem cache local ou em manutenção: mostra o erro; com cache, segue offline
                if (e.code == 503 || Prefs.get("config_json", "").isEmpty()) throw new Exception(e.getMessage() + "\n\n" + Panel.baseUrl() + "/api/config.php");
                return null;
            }
        }, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { next(); }
            @Override public void fail(String error) { showFail(error); }
        });
    }

    private void showFail(String error) {
        status.setText(error);
        status.setGravity(Gravity.CENTER);
        failBox = new LinearLayout(this);
        failBox.setOrientation(LinearLayout.VERTICAL);
        failBox.addView(UI.primaryButton(this, T.t("Tentar novamente"), this::start), UI.lp(-2, -2, 16, this));
        failBox.addView(UI.button(this, "Trocar URL do painel", this::askPanel), UI.lp(-2, -2, 8, this));
        root.addView(failBox);
    }

    private void askPanel() {
        final EditText e = UI.input(this, "https://seu-painel.com", false);
        if (Panel.isConfigured()) e.setText(Panel.baseUrl());
        new AlertDialog.Builder(this).setTitle("URL do painel").setView(UI.pad(this, e)).setCancelable(Panel.isConfigured())
                .setPositiveButton("OK", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.isEmpty()) { askPanel(); return; }
                    Panel.setBaseUrl(s);
                    start();
                }).show();
    }

    private void next() {
        Intent i = new Intent(this, Repo.loggedIn() ? HomeActivity.class : LoginActivity.class);
        startActivity(i);
        finish();
    }
}
