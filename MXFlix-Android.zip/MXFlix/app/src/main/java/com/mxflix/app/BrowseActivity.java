package com.mxflix.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/** Lista categorias + grade de itens (live, vod, series), favoritos, histórico e busca. */
public class BrowseActivity extends AppCompatActivity {
    private String kind;
    private RecyclerView grid, catList;
    private ItemAdapter adapter;
    private TextView count, empty;
    private EditText search;
    private List<Cat> cats = new ArrayList<>();
    private String catId = null;
    private int catIndex = 0;
    private List<Item> current = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        kind = getIntent().getStringExtra("kind");
        if (kind == null) kind = "vod";
        boolean hasCats = kind.equals("live") || kind.equals("vod") || kind.equals("series");

        LinearLayout root = new LinearLayout(this);
        root.setBackgroundColor(UI.BG);
        root.setOrientation(LinearLayout.HORIZONTAL);

        if (hasCats) {
            catList = new RecyclerView(this);
            catList.setLayoutManager(new LinearLayoutManager(this));
            catList.setBackgroundColor(UI.SURFACE);
            catList.setPadding(UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6), UI.dp(this, 6));
            root.addView(catList, new LinearLayout.LayoutParams(UI.dp(this, 220), -1));
        }

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 12);
        right.setPadding(p, p, p, 0);
        root.addView(right, new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = UI.text(this, titleFor(kind), 18, UI.WHITE, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        count = UI.text(this, "", 12, UI.MUTED, false);
        top.addView(count);
        right.addView(top, new LinearLayout.LayoutParams(-1, -2));

        search = UI.input(this, T.t("Buscar canais, filmes e séries"), false);
        right.addView(search, UI.lp(-1, -2, 8, this));

        empty = UI.text(this, T.t("Nenhum resultado."), 14, UI.MUTED, false);
        empty.setGravity(Gravity.CENTER);
        empty.setVisibility(View.GONE);
        right.addView(empty, UI.lp(-1, -2, 20, this));

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int panelPx = hasCats ? UI.dp(this, 220) : 0;
        int cardDp = kind.equals("live") ? 150 : 130;
        int cell = UI.dp(this, cardDp + 12);
        int span = Math.max(2, (dm.widthPixels - panelPx - UI.dp(this, 24)) / cell);
        grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, span));
        grid.setClipToPadding(false);
        adapter = new ItemAdapter(cardDp, (it, pos) -> openItem(it, pos), (it, pos) -> toggleFav(it));
        grid.setAdapter(adapter);
        right.addView(grid, UI.lp(-1, 0, 8, this));
        ((LinearLayout.LayoutParams) grid.getLayoutParams()).weight = 1;

        setContentView(root);

        if (hasCats) {
            cats = new ArrayList<>(Repo.cats(kind));
            catList.setAdapter(new CatAdapter());
        }
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void afterTextChanged(Editable s) { refresh(); }
        });
        if (kind.equals("search")) search.requestFocus();
        refresh();
    }

    private String titleFor(String k) {
        switch (k) {
            case "live": return T.t("Ao Vivo");
            case "vod": return T.t("Filmes");
            case "series": return T.t("Séries");
            case "fav": return T.t("Favoritos");
            case "history": return T.t("Continuar assistindo");
            default: return T.t("Busca");
        }
    }

    private void refresh() {
        String q = search.getText().toString().trim().toLowerCase();
        List<Item> src;
        switch (kind) {
            case "fav": src = Store.get(this).favorites(Repo.session(), null); break;
            case "history": src = Store.get(this).history(Repo.session(), false); break;
            case "search": src = q.length() < 2 ? new ArrayList<Item>() : Repo.search(q); break;
            default: src = Repo.items(kind, catId);
        }
        if (!kind.equals("search") && !q.isEmpty()) {
            List<Item> f = new ArrayList<>();
            for (Item i : src) if (i.name.toLowerCase().contains(q)) f.add(i);
            src = f;
        }
        current = src;
        adapter.set(src);
        count.setText(src.size() + "");
        empty.setVisibility(src.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void toggleFav(Item it) {
        if ("episode".equals(it.kind)) return;
        boolean on = Store.get(this).toggleFavorite(Repo.session(), it);
        UI.toast(this, on ? "Adicionado aos favoritos" : "Removido dos favoritos");
        if (kind.equals("fav")) refresh();
    }

    private void openItem(final Item it, final int pos) {
        if (Rules.adult(it.name) && Repo.hasPin() && !Repo.adultUnlocked) {
            UI.askPin(this, () -> doOpen(it, pos));
            return;
        }
        doOpen(it, pos);
    }

    private void doOpen(Item it, int pos) {
        if ("live".equals(it.kind) || "episode".equals(it.kind)) {
            // playlist = itens visíveis da lista atual (zapping com cima/baixo nos canais)
            Repo.playlist = new ArrayList<>(current);
            Repo.playlistIndex = Math.max(0, current.indexOf(it));
            startActivity(new Intent(this, PlayerActivity.class));
        } else {
            Repo.selected = it;
            startActivity(new Intent(this, DetailsActivity.class));
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (kind.equals("fav") || kind.equals("history")) refresh();
    }

    // -------------------------------------------------- categorias
    private class CatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @NonNull @Override public RecyclerView.ViewHolder onCreateViewHolder(@NonNull android.view.ViewGroup p, int t) {
            TextView v = UI.text(p.getContext(), "", 14, UI.WHITE, false);
            int pad = UI.dp(p.getContext(), 12);
            v.setPadding(pad, pad, pad, pad);
            v.setFocusable(true); v.setClickable(true);
            v.setMaxLines(2);
            v.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder h, int pos) {
            TextView v = (TextView) h.itemView;
            final boolean all = pos == 0;
            Cat c = all ? null : cats.get(pos - 1);
            v.setText(all ? "Todos" : c.name);
            boolean sel = catIndex == pos;
            v.setBackground(sel ? UI.round(v.getContext(), 0x33E50914, 10) : UI.focusBg(v.getContext(), UI.SURFACE, 10));
            v.setTextColor(sel ? Cfg.primary() : UI.WHITE);
            v.setOnClickListener(x -> {
                final int p = h.getBindingAdapterPosition();
                if (p < 0) return;
                final Cat cc = p == 0 ? null : cats.get(p - 1);
                if (cc != null && Rules.adult(cc.name) && Repo.hasPin() && !Repo.adultUnlocked) {
                    UI.askPin(BrowseActivity.this, () -> selectCat(p, cc));
                } else selectCat(p, cc);
            });
        }

        @Override public int getItemCount() { return cats.size() + 1; }
    }

    private void selectCat(int index, Cat c) {
        int old = catIndex;
        catIndex = index;
        catId = c == null ? null : c.id;
        catList.getAdapter().notifyItemChanged(old);
        catList.getAdapter().notifyItemChanged(index);
        refresh();
    }
}
