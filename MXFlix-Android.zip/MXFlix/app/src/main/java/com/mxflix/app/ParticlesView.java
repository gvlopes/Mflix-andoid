package com.mxflix.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.Random;

/** Partículas do tema: "embers" (sobem), "snow" (caem), "stars" (piscam) ou "none". */
public class ParticlesView extends View {
    private static final int MAX = 120;
    private final float[] x = new float[MAX], y = new float[MAX], sp = new float[MAX], sz = new float[MAX], ph = new float[MAX], al = new float[MAX];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final int n;
    private final String style;
    private long last = 0;
    private boolean ready = false;

    public ParticlesView(Context c) {
        super(c);
        setWillNotDraw(false);
        style = Theme.particleStyle;
        n = "none".equals(style) ? 0 : Math.min(MAX, Theme.particleCount);
    }

    private void reset(int i, boolean anywhere) {
        float w = getWidth(), h = getHeight();
        x[i] = rnd.nextFloat() * w;
        boolean down = "snow".equals(style);
        y[i] = anywhere ? rnd.nextFloat() * h : (down ? -10 - rnd.nextFloat() * 40 : h + rnd.nextFloat() * 40);
        sp[i] = 12 + rnd.nextFloat() * 38;
        sz[i] = 1.2f + rnd.nextFloat() * 3.2f;
        ph[i] = rnd.nextFloat() * 6.28f;
        al[i] = 0.25f + rnd.nextFloat() * 0.6f;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w > 0 && h > 0) { for (int i = 0; i < n; i++) reset(i, true); ready = true; }
    }

    @Override protected void onDraw(Canvas c) {
        if (!ready || n == 0) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        float d = getResources().getDisplayMetrics().density;
        int base = (Theme.particleColor != 0 ? Theme.particleColor : Theme.primary) & 0x00FFFFFF;
        boolean up = "embers".equals(style), down = "snow".equals(style);
        float speed = Theme.particleSpeed;
        for (int i = 0; i < n; i++) {
            ph[i] += dt * (up || down ? 1.5f : 2.2f);
            float fade = 1f;
            if (up) {
                y[i] -= sp[i] * d * dt * speed;
                x[i] += (float) Math.sin(ph[i]) * 8f * d * dt;
                if (y[i] < -10) reset(i, false);
                fade = Math.min(1f, Math.max(0f, y[i] / getHeight() * 1.6f));
            } else if (down) {
                y[i] += sp[i] * d * dt * speed;
                x[i] += (float) Math.sin(ph[i]) * 10f * d * dt;
                if (y[i] > getHeight() + 10) reset(i, false);
            }
            float tw = up || down ? (0.7f + 0.3f * (float) Math.sin(ph[i] * 2)) : (0.25f + 0.75f * Math.abs((float) Math.sin(ph[i])));
            int a = Math.max(0, Math.min(255, (int) (255 * al[i] * fade * tw)));
            paint.setColor((a << 24) | (i % 5 == 0 ? 0x00FFFFFF : base));
            c.drawCircle(x[i], y[i], sz[i] * d * ("stars".equals(style) ? 0.7f : 1f), paint);
        }
        postInvalidateOnAnimation();
    }

    @Override protected void onDetachedFromWindow() { last = 0; super.onDetachedFromWindow(); }
}
