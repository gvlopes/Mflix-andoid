package com.mxflix.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.Random;

/** Partículas (brasas) subindo suavemente no fundo. Leve: ~45 círculos, sem alocação no draw. */
public class ParticlesView extends View {
    private static final int N = 45;
    private final float[] x = new float[N], y = new float[N], sp = new float[N], sz = new float[N], ph = new float[N], al = new float[N];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private long last = 0;
    private boolean ready = false;

    public ParticlesView(Context c) { super(c); setWillNotDraw(false); }

    private void reset(int i, boolean anywhere) {
        float w = getWidth(), h = getHeight();
        x[i] = rnd.nextFloat() * w;
        y[i] = anywhere ? rnd.nextFloat() * h : h + rnd.nextFloat() * 40;
        sp[i] = 12 + rnd.nextFloat() * 38;                       // dp/s aprox.
        sz[i] = 1.2f + rnd.nextFloat() * 3.2f;
        ph[i] = rnd.nextFloat() * 6.28f;
        al[i] = 0.25f + rnd.nextFloat() * 0.6f;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w > 0 && h > 0) { for (int i = 0; i < N; i++) reset(i, true); ready = true; }
    }

    @Override protected void onDraw(Canvas c) {
        if (!ready) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        float d = getResources().getDisplayMetrics().density;
        int base = Cfg.primary() & 0x00FFFFFF;
        for (int i = 0; i < N; i++) {
            y[i] -= sp[i] * d * dt;
            ph[i] += dt * 1.5f;
            x[i] += (float) Math.sin(ph[i]) * 8f * d * dt;
            if (y[i] < -10) reset(i, false);
            float fade = Math.min(1f, Math.max(0f, y[i] / getHeight() * 1.6f));   // some perto do topo
            int a = (int) (255 * al[i] * fade * (0.7f + 0.3f * (float) Math.sin(ph[i] * 2)));
            paint.setColor((Math.max(0, Math.min(255, a)) << 24) | (i % 5 == 0 ? 0x00FFFFFF : base));
            c.drawCircle(x[i], y[i], sz[i] * d, paint);
        }
        postInvalidateOnAnimation();
    }

    @Override protected void onDetachedFromWindow() { last = 0; super.onDetachedFromWindow(); }
}
