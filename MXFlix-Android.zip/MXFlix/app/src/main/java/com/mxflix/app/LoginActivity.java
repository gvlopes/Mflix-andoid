package com.mxflix.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    private LinearLayout formUser, formM3u, formId;
    private Spinner spinner;
    private EditText user, pass, m3u;
    private TextView message, waiting;
    private final List<String> serverUrls = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean polling = false, busy = false;

    private TextView[] modeLinks = new TextView[3];
    private boolean showPass = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(HomeActivity.NAVY);

        // fundo (lado esquerdo): imagem do painel, ou arte opcional login_cover
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        int cover = getResources().getIdentifier("login_cover", "drawable", getPackageName());
        UI.image(bg, Cfg.get("login_background", Cfg.get("background", "")), cover != 0 ? cover : R.drawable.mx_background);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x55040A14, 0xB0061226, 0xF2061A3A}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams((int) Math.max(UI.dp(this, 340), dm.widthPixels * 0.46f), -1);
        sl.gravity = Gravity.END;
        root.addView(sv, sl);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        int pw = UI.dp(this, 44), ph = UI.dp(this, 16);
        col.setPadding(pw, ph, pw, ph);
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));

        // marca
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        UI.image(logo, Cfg.get("logo", ""), R.drawable.mx_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        brand.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 44), UI.dp(this, 44)));
        TextView bn = UI.text(this, Cfg.appName(), 22, UI.WHITE, true);
        LinearLayout.LayoutParams bnl = new LinearLayout.LayoutParams(-2, -2);
        bnl.leftMargin = UI.dp(this, 10);
        brand.addView(bn, bnl);
        col.addView(brand);

        // título com o nome em destaque
        String nm = Cfg.appName();
        android.text.SpannableString sp = new android.text.SpannableString("BEM-VINDO AO " + nm);
        sp.setSpan(new android.text.style.ForegroundColorSpan(HomeActivity.CYAN), 13, sp.length(), 0);
        TextView title = UI.text(this, "", 20, UI.WHITE, true);
        title.setText(sp);
        title.setGravity(Gravity.CENTER);
        col.addView(title, UI.lp(-1, -2, 14, this));
        TextView sub = UI.text(this, "Seu entretenimento, sem limites. Filmes, séries e muito mais para toda a família.", 12, 0xFFD5DEEC, false);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub, UI.lp(-1, -2, 6, this));

        // --- formulário usuário/senha
        formUser = new LinearLayout(this);
        formUser.setOrientation(LinearLayout.VERTICAL);
        spinner = new Spinner(this);
        spinner.setBackground(fieldBg(false));
        spinner.setVisibility(View.GONE);
        formUser.addView(spinner, UI.lp(-1, UI.dp(this, 48), 14, this));
        user = UI.input(this, T.t("Usuário"), false);
        pass = UI.input(this, T.t("Senha"), true);
        formUser.addView(field(R.drawable.ic_h_person, user, false), UI.lp(-1, UI.dp(this, 48), 14, this));
        formUser.addView(field(R.drawable.ic_h_lock, pass, true), UI.lp(-1, UI.dp(this, 48), 12, this));
        formUser.addView(mainButton(null, "ENTRAR  →", true, this::doUserLogin), UI.lp(-1, UI.dp(this, 48), 12, this));
        col.addView(formUser, new LinearLayout.LayoutParams(-1, -2));

        // --- formulário M3U
        formM3u = new LinearLayout(this);
        formM3u.setOrientation(LinearLayout.VERTICAL);
        m3u = UI.input(this, "http://servidor/get.php?username=...&password=...", false);
        formM3u.addView(field(R.drawable.ic_h_layers, m3u, false), UI.lp(-1, UI.dp(this, 48), 14, this));
        formM3u.addView(mainButton(null, "ENTRAR  →", true, this::doM3uLogin), UI.lp(-1, UI.dp(this, 48), 12, this));
        formM3u.setVisibility(View.GONE);
        col.addView(formM3u, new LinearLayout.LayoutParams(-1, -2));

        // --- ativação por ID
        formId = new LinearLayout(this);
        formId.setOrientation(LinearLayout.VERTICAL);
        formId.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView hint = UI.text(this, "Informe este ID ao suporte para ativar sua lista:", 13, 0xFFD5DEEC, false);
        hint.setGravity(Gravity.CENTER);
        formId.addView(hint, UI.lp(-1, -2, 14, this));
        TextView big = UI.text(this, Panel.friendlyId(), 36, HomeActivity.CYAN, true);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.2f);
        formId.addView(big, UI.lp(-1, -2, 8, this));
        waiting = UI.text(this, "Aguardando ativação...", 12, 0xFFD5DEEC, false);
        waiting.setGravity(Gravity.CENTER);
        formId.addView(waiting, UI.lp(-1, -2, 8, this));
        formId.addView(mainButton(null, "Verificar agora", false, this::checkActivation), UI.lp(-1, UI.dp(this, 46), 12, this));
        formId.setVisibility(View.GONE);
        col.addView(formId, new LinearLayout.LayoutParams(-1, -2));

        col.addView(mainButton(R.drawable.ic_h_gift, T.t("GERAR TESTE GRÁTIS"), false, this::doTrial), UI.lp(-1, UI.dp(this, 48), 12, this));

        message = UI.text(this, "", 10, 0xFFFF6B6B, false);
        message.setGravity(Gravity.CENTER);
        col.addView(message, UI.lp(-1, -2, 10, this));

        // ID do aparelho (amarelo)
        TextView did = UI.text(this, "", 10, UI.WHITE, false);
        android.text.SpannableString ds = new android.text.SpannableString("ID deste dispositivo: " + Panel.friendlyId());
        ds.setSpan(new android.text.style.ForegroundColorSpan(HomeActivity.GOLD), 22, ds.length(), 0);
        ds.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 22, ds.length(), 0);
        did.setText(ds);
        did.setGravity(Gravity.CENTER);
        col.addView(did, UI.lp(-1, -2, 2, this));

        // outros modos de entrada (mantêm todas as funções do app)
        LinearLayout links = new LinearLayout(this);
        links.setGravity(Gravity.CENTER);
        modeLinks[0] = link(T.t("Usuário e senha"), 0);
        modeLinks[1] = link(T.t("Lista M3U"), 1);
        modeLinks[2] = link(T.t("Ativação por ID"), 2);
        for (TextView t : modeLinks) links.addView(t);
        String phone = Cfg.get("support_phone", "");
        final String wa = !phone.isEmpty() ? "https://wa.me/" + phone : Cfg.get("support_whatsapp", Cfg.get("support_link", ""));
        if (!wa.isEmpty()) links.addView(link(T.t("Suporte"), -1, () -> UI.openUrl(this, wa)));
        col.addView(links, UI.lp(-1, -2, 12, this));
        showTab(0);

        setContentView(root);
        loadServers();
    }

    private GradientDrawable fieldBg(boolean focused) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xCC0A1424);
        g.setStroke(UI.dp(this, 2), focused ? HomeActivity.CYAN : 0x881EA7FD);
        g.setCornerRadius(UI.dp(this, 14));
        return g;
    }

    /** Campo com ícone à esquerda e (opcional) olho para mostrar/ocultar a senha. */
    private View field(int icon, final EditText et, boolean eye) {
        final LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(fieldBg(false));
        int pad = UI.dp(this, 14);
        row.setPadding(pad, 0, pad, 0);
        ImageView ic = new ImageView(this);
        ic.setImageResource(icon); ic.setColorFilter(0xFFFFFFFF);
        row.addView(ic, new LinearLayout.LayoutParams(UI.dp(this, 20), UI.dp(this, 20)));
        et.setBackground(null);
        et.setPadding(UI.dp(this, 12), 0, 0, 0);
        et.setHintTextColor(0xFFB9C7DA);
        row.addView(et, new LinearLayout.LayoutParams(0, -1, 1));
        et.setOnFocusChangeListener((v, f) -> row.setBackground(fieldBg(f)));
        if (eye) {
            final ImageView ev = new ImageView(this);
            ev.setImageResource(R.drawable.ic_h_eye_off); ev.setColorFilter(0xFFFFFFFF);
            ev.setFocusable(true); ev.setClickable(true);
            ev.setOnClickListener(v -> {
                showPass = !showPass;
                int sel = et.getSelectionStart();
                et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | (showPass ? android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD));
                et.setSelection(Math.max(0, sel));
                ev.setImageResource(showPass ? R.drawable.ic_h_eye : R.drawable.ic_h_eye_off);
            });
            row.addView(ev, new LinearLayout.LayoutParams(UI.dp(this, 22), UI.dp(this, 22)));
        }
        return row;
    }

    private View mainButton(Integer icon, String label, boolean filled, final Runnable r) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true); b.setClickable(true);
        GradientDrawable g;
        if (filled) { g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF3D8BFF, 0xFF2E7CF0}); }
        else { g = new GradientDrawable(); g.setColor(0xCC0A1424); g.setStroke(UI.dp(this, 2), 0x881EA7FD); }
        g.setCornerRadius(UI.dp(this, 14));
        b.setBackground(g);
        if (icon != null) {
            ImageView ic = new ImageView(this);
            ic.setImageResource(icon); ic.setColorFilter(0xFFFFFFFF);
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(UI.dp(this, 18), UI.dp(this, 18));
            il.rightMargin = UI.dp(this, 10);
            b.addView(ic, il);
        }
        b.addView(UI.text(this, label, 14, UI.WHITE, true));
        b.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(b);
        return b;
    }

    private TextView link(String label, final int idx) { return link(label, idx, () -> showTab(idx)); }

    private TextView link(String label, int idx, final Runnable r) {
        TextView t = UI.text(this, label, 10, 0xFFB9C7DA, false);
        t.setPadding(UI.dp(this, 8), UI.dp(this, 6), UI.dp(this, 8), UI.dp(this, 6));
        t.setFocusable(true); t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void showTab(int i) {
        formUser.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        formM3u.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        formId.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
        for (int k = 0; k < modeLinks.length; k++) {
            if (modeLinks[k] != null) {
                modeLinks[k].setTextColor(k == i ? HomeActivity.CYAN : 0xFFB9C7DA);
                modeLinks[k].setTypeface(k == i ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            }
        }
        if (message != null) message.setText("");
        polling = i == 2;
        handler.removeCallbacksAndMessages(null);
        if (polling) schedulePoll(0);
    }

    private void loadServers() {
        Repo.async(Panel::servers, new Repo.Result<JSONArray>() {
            @Override public void ok(JSONArray a) {
                List<String> names = new ArrayList<>();
                serverUrls.clear();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o == null) continue;
                    names.add(o.optString("name", "Servidor"));
                    serverUrls.add(o.optString("url"));
                }
                if (names.isEmpty()) { names.add("(sem servidores)"); }
                ArrayAdapter<String> ad = new ArrayAdapter<>(LoginActivity.this, android.R.layout.simple_spinner_dropdown_item, names);
                spinner.setAdapter(ad);
                spinner.setVisibility(serverUrls.size() > 1 ? View.VISIBLE : View.GONE);
            }
            @Override public void fail(String e) { message.setText(e); }
        });
    }

    private void setBusy(boolean v, String msg) { busy = v; message.setTextColor(v ? UI.MUTED : 0xFFFF7A7A); message.setText(msg == null ? "" : msg); }

    private void doUserLogin() {
        if (busy) return;
        final int pos = spinner.getSelectedItemPosition();
        final String u = user.getText().toString().trim(), p = pass.getText().toString();
        if (serverUrls.isEmpty() || pos < 0 || pos >= serverUrls.size()) { setBusy(false, "Nenhum servidor disponível. Fale com o suporte."); return; }
        if (u.isEmpty() || p.isEmpty()) { setBusy(false, "Informe usuário e senha."); return; }
        final String base = Rules.normalizeServer(serverUrls.get(pos));
        setBusy(true, "Conectando...");
        Repo.async(() -> { loginXtream(base, u, p, true); return true; }, done());
    }

    private void doM3uLogin() {
        if (busy) return;
        final String url = m3u.getText().toString().trim();
        if (!url.matches("(?i)^https?://.+")) { setBusy(false, "Endereço inválido."); return; }
        setBusy(true, "Carregando lista M3U...");
        Repo.async(() -> { completeFromUrl(url, false); return true; }, done());
    }

    private void doTrial() {
        if (busy) return;
        setBusy(true, "Conectando seu teste grátis...");
        Repo.async(() -> {
            JSONObject d = Panel.trial();
            completeFromUrl(d.optString("m3u_url"), false);
            return true;
        }, done());
    }

    private Repo.Result<Boolean> done() {
        return new Repo.Result<Boolean>() {
            @Override public void ok(Boolean v) { setBusy(false, ""); goHome(); }
            @Override public void fail(String e) { setBusy(false, e); }
        };
    }

    private void goHome() {
        handler.removeCallbacksAndMessages(null);
        Intent i = new Intent(this, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    // ----------------------------------------------------------- lógica de login
    /** strict = erros do painel (servidor/aparelho bloqueado) impedem o login. */
    static void loginXtream(String base, String u, String p, boolean strict) throws Exception {
        Xtream x = new Xtream(base, u, p);
        JSONObject j;
        try { j = x.auth(); } catch (Exception e) { throw new Exception(T.t("Falha de conexão. Verifique a internet.")); }
        JSONObject ui = j.optJSONObject("user_info");
        String err = Rules.accountError(ui, System.currentTimeMillis() / 1000);
        if (err != null) throw new Exception(err);
        String pinHash = "";
        try {
            pinHash = Panel.registerDevice(base, u, ui.optString("status"), ui.optString("exp_date"));
        } catch (Panel.PanelException e) {
            if (strict || e.code == 403 && e.getMessage() != null && e.getMessage().toLowerCase().contains("bloquead")) throw new Exception(e.getMessage());
        }
        Repo.saveXtream(base, u, p);
        Prefs.put("acc_status", ui.optString("status"));
        Prefs.put("acc_exp", ui.optString("exp_date"));
        Prefs.put("acc_maxcon", ui.optString("max_connections"));
        if (!pinHash.isEmpty()) Prefs.put("pin_hash", pinHash);
        Panel.log("login_success");
    }

    static void completeFromUrl(String url, boolean remote) throws Exception {
        if (url == null || url.isEmpty()) throw new Exception("Lista inválida.");
        String[] x = M3u.xtreamFromUrl(url);
        if (x != null) loginXtream(Rules.normalizeServer(x[0]), x[1], x[2], false);
        else Repo.saveM3u(url);
        Prefs.putBool("activated_remote", remote);
    }

    // ----------------------------------------------------------- ativação por ID
    private void schedulePoll(long delay) {
        handler.postDelayed(() -> { if (polling) checkActivation(); }, delay > 0 ? delay : 500);
    }

    private void checkActivation() {
        if (busy) return;
        Repo.async(() -> {
            Panel.Activation a = Panel.activation();
            if (a.active && a.m3u != null && !a.m3u.isEmpty()) {
                completeFromUrl(a.m3u, true);
                Prefs.put("activation_rev", String.valueOf(a.revision));
                return true;
            }
            return false;
        }, new Repo.Result<Boolean>() {
            @Override public void ok(Boolean v) {
                if (v) { waiting.setText("Ativação recebida. Carregando seu conteúdo..."); goHome(); }
                else { waiting.setText("Aguardando ativação..."); if (polling) schedulePoll(6000); }
            }
            @Override public void fail(String e) { waiting.setText(e); if (polling) schedulePoll(10000); }
        });
    }

    @Override protected void onDestroy() { polling = false; handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
