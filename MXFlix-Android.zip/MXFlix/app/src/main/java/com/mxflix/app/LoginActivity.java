package com.mxflix.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {
    private LinearLayout formUser, formM3u, formId;
    private Spinner spinner;
    private EditText user, pass, m3u, manualServer;
    private TextView message, waiting;
    private final List<String> serverUrls = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean polling = false, busy = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout outer = new LinearLayout(this);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(outer, new ScrollView.LayoutParams(-1, -2));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 24);
        col.setPadding(p, p, p, p);
        outer.addView(col, new LinearLayout.LayoutParams(UI.dp(this, 520), -2));

        ImageView logo = new ImageView(this);
        UI.image(logo, Cfg.get("logo", ""), R.drawable.mx_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(UI.dp(this, 96), UI.dp(this, 96));
        ll.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(logo, ll);
        TextView title = UI.text(this, "BEM-VINDO AO " + Cfg.appName().toUpperCase(), 20, UI.WHITE, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, UI.lp(-1, -2, 10, this));
        TextView did = UI.text(this, T.t("ID do aparelho") + ": " + Panel.friendlyId(), 13, UI.MUTED, false);
        did.setGravity(Gravity.CENTER);
        col.addView(did, UI.lp(-1, -2, 4, this));

        // seletor de modo
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        col.addView(tabs, UI.lp(-1, -2, 16, this));
        tabs.addView(tab(T.t("Usuário e senha"), 0), new LinearLayout.LayoutParams(0, -2, 1));
        tabs.addView(tab(T.t("Lista M3U"), 1), tabLp());
        tabs.addView(tab(T.t("Ativação por ID"), 2), tabLp());

        // --- formulário usuário/senha
        formUser = new LinearLayout(this);
        formUser.setOrientation(LinearLayout.VERTICAL);
        spinner = new Spinner(this);
        spinner.setBackground(UI.focusBg(this, UI.SURFACE, 10));
        formUser.addView(spinner, UI.lp(-1, UI.dp(this, 50), 12, this));
        manualServer = UI.input(this, T.t("Servidor") + " (http://dominio:porta)", false);
        manualServer.setVisibility(View.GONE);
        formUser.addView(manualServer, UI.lp(-1, -2, 12, this));
        user = UI.input(this, T.t("Usuário"), false);
        pass = UI.input(this, T.t("Senha"), true);
        formUser.addView(user, UI.lp(-1, -2, 10, this));
        formUser.addView(pass, UI.lp(-1, -2, 10, this));
        formUser.addView(UI.primaryButton(this, T.t("ENTRAR"), this::doUserLogin), UI.lp(-1, -2, 14, this));
        col.addView(formUser);

        // --- formulário M3U
        formM3u = new LinearLayout(this);
        formM3u.setOrientation(LinearLayout.VERTICAL);
        m3u = UI.input(this, "http://servidor/get.php?username=...&password=...", false);
        formM3u.addView(m3u, UI.lp(-1, -2, 12, this));
        formM3u.addView(UI.primaryButton(this, T.t("ENTRAR"), this::doM3uLogin), UI.lp(-1, -2, 14, this));
        formM3u.setVisibility(View.GONE);
        col.addView(formM3u);

        // --- ativação por ID
        formId = new LinearLayout(this);
        formId.setOrientation(LinearLayout.VERTICAL);
        formId.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView hint = UI.text(this, "Informe este ID ao suporte para ativar sua lista:", 14, UI.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        formId.addView(hint, UI.lp(-1, -2, 14, this));
        TextView big = UI.text(this, Panel.friendlyId(), 40, Cfg.primary(), true);
        big.setGravity(Gravity.CENTER);
        big.setLetterSpacing(0.2f);
        formId.addView(big, UI.lp(-1, -2, 8, this));
        waiting = UI.text(this, "Aguardando ativação...", 13, UI.MUTED, false);
        waiting.setGravity(Gravity.CENTER);
        formId.addView(waiting, UI.lp(-1, -2, 8, this));
        formId.addView(UI.button(this, "Verificar agora", this::checkActivation), UI.lp(-1, -2, 12, this));
        formId.setVisibility(View.GONE);
        col.addView(formId);

        message = UI.text(this, "", 13, 0xFFFF7A7A, false);
        message.setGravity(Gravity.CENTER);
        col.addView(message, UI.lp(-1, -2, 12, this));

        col.addView(UI.button(this, T.t("GERAR TESTE GRÁTIS"), this::doTrial), UI.lp(-1, -2, 12, this));
        String phone = Cfg.get("support_phone", "");
        final String wa = !phone.isEmpty() ? "https://wa.me/" + phone : Cfg.get("support_whatsapp", Cfg.get("support_link", ""));
        if (!wa.isEmpty()) col.addView(UI.button(this, T.t("Suporte"), () -> UI.openUrl(this, wa)), UI.lp(-1, -2, 10, this));

        android.widget.FrameLayout frame = new android.widget.FrameLayout(this);
        frame.setBackgroundColor(UI.BG);
        frame.addView(new ParticlesView(this), new android.widget.FrameLayout.LayoutParams(-1, -1));
        frame.addView(sv, new android.widget.FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        loadServers();
    }

    private LinearLayout.LayoutParams tabLp() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, -2, 1);
        l.leftMargin = UI.dp(this, 8);
        return l;
    }

    private TextView tab(String label, final int idx) {
        TextView t = UI.button(this, label, () -> showTab(idx));
        t.setTextSize(13);
        return t;
    }

    private void showTab(int i) {
        formUser.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
        formM3u.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
        formId.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
        message.setText("");
        polling = i == 2;
        handler.removeCallbacksAndMessages(null);
        if (polling) schedulePoll(0);
    }

    private void loadServers() {
        Repo.async(Panel::servers, new Repo.Result<JSONArray>() {
            @Override public void ok(JSONArray a) {
                List<String> names = new ArrayList<>();
                serverUrls.clear();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    if (o == null) continue;
                    names.add(o.optString("name", "Servidor"));
                    serverUrls.add(o.optString("url"));
                }
                if (names.isEmpty()) { useManualServer(); names.add("(sem servidores)"); }
                ArrayAdapter<String> ad = new ArrayAdapter<>(LoginActivity.this, android.R.layout.simple_spinner_dropdown_item, names);
                spinner.setAdapter(ad);
            }
            @Override public void fail(String e) { useManualServer(); message.setText("Não foi possível carregar os servidores do painel. Digite o servidor manualmente."); }
        });
    }

    private void useManualServer() {
        spinner.setVisibility(View.GONE);
        manualServer.setVisibility(View.VISIBLE);
    }

    private void setBusy(boolean v, String msg) { busy = v; message.setTextColor(v ? UI.MUTED : 0xFFFF7A7A); message.setText(msg == null ? "" : msg); }

    private void doUserLogin() {
        if (busy) return;
        final boolean manual = manualServer.getVisibility() == View.VISIBLE;
        final int pos = spinner.getSelectedItemPosition();
        final String u = user.getText().toString().trim(), p = pass.getText().toString();
        if (!manual && (serverUrls.isEmpty() || pos < 0 || pos >= serverUrls.size())) { setBusy(false, "Nenhum servidor disponível. Fale com o suporte."); return; }
        if (u.isEmpty() || p.isEmpty()) { setBusy(false, "Informe usuário e senha."); return; }
        final String base = Rules.normalizeServer(manual ? manualServer.getText().toString() : serverUrls.get(pos));
        if (base.isEmpty()) { setBusy(false, "Informe o servidor."); return; }
        setBusy(true, "Conectando...");
        Repo.async(() -> { loginXtream(base, u, p, !manual); return true; }, done());
    }

    private void doM3uLogin() {
        if (busy) return;
        final String url = m3u.getText().toString().trim();
        if (!url.matches("(?i)^https?://.+")) { setBusy(false, "Endereço inválido."); return; }
        setBusy(true, "Carregando lista M3U...");
        Repo.async(() -> { completeFromUrl(url, false); return true; }, done());
    }

    private void doTrial() {
        if (busy) return;
        setBusy(true, "Conectando seu teste grátis...");
        Repo.async(() -> {
            JSONObject d = Panel.trial();
            completeFromUrl(d.optString("m3u_url"), false);
            return true;
        }, done());
    }

    private Repo.Result<Boolean> done() {
        return new Repo.Result<Boolean>() {
            @Override public void ok(Boolean v) { setBusy(false, ""); goHome(); }
            @Override public void fail(String e) { setBusy(false, e); }
        };
    }

    private void goHome() {
        handler.removeCallbacksAndMessages(null);
        Intent i = new Intent(this, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    // ----------------------------------------------------------- lógica de login
    /** strict = erros do painel (servidor/aparelho bloqueado) impedem o login. */
    static void loginXtream(String base, String u, String p, boolean strict) throws Exception {
        Xtream x = new Xtream(base, u, p);
        JSONObject j;
        try { j = x.auth(); } catch (Exception e) { throw new Exception(T.t("Falha de conexão. Verifique a internet.")); }
        JSONObject ui = j.optJSONObject("user_info");
        String err = Rules.accountError(ui, System.currentTimeMillis() / 1000);
        if (err != null) throw new Exception(err);
        String pinHash = "";
        try {
            pinHash = Panel.registerDevice(base, u, ui.optString("status"), ui.optString("exp_date"));
        } catch (Panel.PanelException e) {
            boolean offline = e.code == -1 || e.code >= 502;
            boolean blocked = e.code == 403 && e.getMessage() != null && e.getMessage().toLowerCase().contains("bloquead");
            if (blocked || (strict && !offline)) throw new Exception(e.getMessage());
        }
        Repo.saveXtream(base, u, p);
        Prefs.put("acc_status", ui.optString("status"));
        Prefs.put("acc_exp", ui.optString("exp_date"));
        Prefs.put("acc_maxcon", ui.optString("max_connections"));
        if (!pinHash.isEmpty()) Prefs.put("pin_hash", pinHash);
        Panel.log("login_success");
    }

    static void completeFromUrl(String url, boolean remote) throws Exception {
        if (url == null || url.isEmpty()) throw new Exception("Lista inválida.");
        String[] x = M3u.xtreamFromUrl(url);
        if (x != null) loginXtream(Rules.normalizeServer(x[0]), x[1], x[2], false);
        else Repo.saveM3u(url);
        Prefs.putBool("activated_remote", remote);
    }

    // ----------------------------------------------------------- ativação por ID
    private void schedulePoll(long delay) {
        handler.postDelayed(() -> { if (polling) checkActivation(); }, delay > 0 ? delay : 500);
    }

    private void checkActivation() {
        if (busy) return;
        Repo.async(() -> {
            Panel.Activation a = Panel.activation();
            if (a.active && a.m3u != null && !a.m3u.isEmpty()) {
                completeFromUrl(a.m3u, true);
                Prefs.put("activation_rev", String.valueOf(a.revision));
                return true;
            }
            return false;
        }, new Repo.Result<Boolean>() {
            @Override public void ok(Boolean v) {
                if (v) { waiting.setText("Ativação recebida. Carregando seu conteúdo..."); goHome(); }
                else { waiting.setText("Aguardando ativação..."); if (polling) schedulePoll(6000); }
            }
            @Override public void fail(String e) { waiting.setText(e); if (polling) schedulePoll(10000); }
        });
    }

    @Override protected void onDestroy() { polling = false; handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
