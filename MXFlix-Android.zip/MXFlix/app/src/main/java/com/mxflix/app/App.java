package com.mxflix.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;

public class App extends Application {
    private static final long CHECK_MS = 10_000;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Activity current;
    private boolean checking = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() { check(); handler.postDelayed(this, CHECK_MS); }
    };

    @Override public void onCreate() {
        super.onCreate();
        Prefs.init(this);
        AppConfig.init(this);
        Theme.load();
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityResumed(Activity a) {
                current = a;
                handler.removeCallbacks(tick);
                handler.postDelayed(tick, 1500);
            }
            @Override public void onActivityPaused(Activity a) {
                if (current == a) { current = null; handler.removeCallbacks(tick); }
            }
            @Override public void onActivityCreated(Activity a, Bundle b) { }
            @Override public void onActivityStarted(Activity a) { }
            @Override public void onActivityStopped(Activity a) { }
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
            @Override public void onActivityDestroyed(Activity a) { }
        });
    }

    /** Enquanto o app está aberto, confere o tema do painel; se mudou, aplica e redesenha a tela. */
    private void check() {
        if (checking || current == null || !Panel.isConfigured()) return;
        checking = true;
        Repo.async(Panel::theme, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject t) {
                checking = false;
                if (t.optString("rev", "").equals(Theme.rev)) return;
                Theme.save(t);
                Activity a = current;
                // não interrompe o vídeo nem a digitação do login; essas telas pegam o tema na próxima abertura
                if (a != null && !(a instanceof PlayerActivity) && !(a instanceof LoginActivity) && !(a instanceof SplashActivity)) a.recreate();
            }
            @Override public void fail(String e) { checking = false; }
        });
    }
}
