package com.mxflix.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Tela inicial: cabeçalho, menu lateral, banner de destaque, assinatura, relógio/clima e categorias em círculos. */
public class HomeActivity extends AppCompatActivity {
    // paleta azul/ciano
    static final int NAVY = 0xFF040A14, PANEL = 0xCC081528, CYAN = 0xFF1EA7FD, CYAN_SOFT = 0x661EA7FD,
            GOLD = 0xFFF5B82E, TXT = 0xFFFFFFFF, TXT2 = 0xFFB9C7DA;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView loading, weatherText, weatherDesc, dateText;
    private ImageView weatherIcon, heroImg, wifiIcon;
    private TextView heroChip, heroTitle, heroMeta, heroPlot;
    private View heroButtons;
    private LinearLayout dots;
    private final List<Slide> slides = new ArrayList<>();
    private int slideIndex = 0;
    private boolean destroyed = false;

    /** Um destaque do banner (dados básicos já na lista; detalhes chegam do servidor). */
    private static class Slide {
        Item item; String backdrop = "", plot = "", genre = "", year = ""; double rating;
        Slide(Item i) { item = i; plot = i.plot == null ? "" : i.plot; rating = i.rating; }
    }

    private final Runnable rotate = new Runnable() {
        @Override public void run() {
            if (slides.size() > 1) showSlide((slideIndex + 1) % slides.size());
            ui.postDelayed(this, 7000);
        }
    };
    private final Runnable tickDate = new Runnable() {
        @Override public void run() {
            dateText.setText(new SimpleDateFormat("EEE, dd MMM yyyy", new Locale("pt", "BR")).format(new Date()).replace(".", "").toUpperCase(new Locale("pt", "BR")));
            ui.postDelayed(this, 30_000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(NAVY);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        UI.image(bg, Cfg.get("background", ""), R.drawable.mx_background);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xE6040A14, 0xF2050E1E}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 14);
        col.setPadding(p, UI.dp(this, 8), p, UI.dp(this, 10));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        col.addView(buildHeader(), new LinearLayout.LayoutParams(-1, -2));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-1, 0, 1);
        ml.topMargin = UI.dp(this, 6);
        col.addView(mid, ml);
        mid.addView(buildSidebar(), new LinearLayout.LayoutParams(UI.dp(this, 86), -1));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(0, -1, 1);
        rl.leftMargin = UI.dp(this, 12);
        mid.addView(right, rl);
        right.addView(buildHero(), new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, UI.dp(this, 62));
        il.topMargin = UI.dp(this, 10);
        right.addView(buildInfoRow(), il);

        int circle = Math.min((int) (dm.heightPixels * 0.27f), (int) ((dm.widthPixels - UI.dp(this, 28)) / 6.3f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, circle + UI.dp(this, 8));
        cl.topMargin = UI.dp(this, 8);
        col.addView(buildCircles(circle), cl);

        loading = UI.text(this, T.t("Atualizando conteúdo..."), 15, UI.WHITE, true);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundColor(0xF0040A14);
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        tickDate.run();
        loadContent(false);
        refreshWeather();
        checkRemote();
        Repo.async(Panel::config, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { }
            @Override public void fail(String e) { }
        });
    }

    // ------------------------------------------------------------ cabeçalho
    private View buildHeader() {
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        UI.image(logo, Cfg.get("logo", ""), R.drawable.mx_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_START);
        head.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 150), UI.dp(this, 44)));

        View sp = new View(this);
        head.addView(sp, new LinearLayout.LayoutParams(0, 1, 0.4f));

        ImageView user = icon(R.drawable.ic_h_person, 26, TXT);
        head.addView(user);
        LinearLayout ucol = new LinearLayout(this);
        ucol.setOrientation(LinearLayout.VERTICAL);
        ucol.addView(UI.text(this, "USUÁRIO", 9, TXT2, false));
        String uname = Prefs.get("x_user", "");
        if (uname.isEmpty()) uname = Panel.friendlyId();
        ucol.addView(UI.text(this, uname, 15, TXT, false));
        LinearLayout.LayoutParams ul = new LinearLayout.LayoutParams(-2, -2);
        ul.leftMargin = UI.dp(this, 10);
        head.addView(ucol, ul);

        View div = new View(this);
        div.setBackgroundColor(0x44FFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(UI.dp(this, 1), UI.dp(this, 36));
        dl.leftMargin = UI.dp(this, 26); dl.rightMargin = UI.dp(this, 20);
        head.addView(div, dl);

        // aviso editável pelo painel
        String notice = Cfg.get("home_notice", "");
        TextView n = UI.text(this, notice, 16, TXT, true);
        n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        n.setMarqueeRepeatLimit(-1); n.setSelected(true);
        head.addView(n, new LinearLayout.LayoutParams(0, -2, 1));

        wifiIcon = icon(R.drawable.ic_h_wifi, 24, TXT);
        head.addView(circleBtn(wifiIcon, () -> UI.toast(this, "Conexão: " + (Repo.loaded ? "online" : "conectando..."))));
        ImageView bell = icon(R.drawable.ic_h_bell, 24, TXT);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.leftMargin = UI.dp(this, 10);
        View bellBtn = circleBtn(bell, () -> {
            String msg = Cfg.get("home_notice", "");
            new AlertDialog.Builder(this).setTitle("Avisos").setMessage(msg.isEmpty() ? "Sem avisos no momento." : msg)
                    .setPositiveButton(T.t("Fechar"), null).show();
        });
        bellBtn.setLayoutParams(bl);
        head.addView(bellBtn);
        return head;
    }

    private View circleBtn(ImageView ic, Runnable r) {
        FrameLayout f = new FrameLayout(this);
        int pad = UI.dp(this, 11);
        f.setPadding(pad, pad, pad, pad);
        f.setBackground(ring(0x22000000, 0x66FFFFFF, 1));
        f.setFocusable(true); f.setClickable(true);
        f.addView(ic, new FrameLayout.LayoutParams(UI.dp(this, 24), UI.dp(this, 24)));
        f.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UI.dp(this, 46), UI.dp(this, 46));
        lp.leftMargin = UI.dp(this, 10);
        f.setLayoutParams(lp);
        return f;
    }

    // ------------------------------------------------------------ menu lateral
    private View buildSidebar() {
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setBackground(panelBg(18, CYAN_SOFT));
        int pad = UI.dp(this, 4);
        side.setPadding(pad, pad, pad, pad);
        side.addView(sideItem(R.drawable.ic_h_home, "Início", true, () -> { }), new LinearLayout.LayoutParams(-1, 0, 1));
        side.addView(sideItem(R.drawable.ic_h_search, "Buscar", false, () -> open("search")), new LinearLayout.LayoutParams(-1, 0, 1));
        side.addView(sideItem(R.drawable.ic_h_history, "Histórico", false, () -> open("history")), new LinearLayout.LayoutParams(-1, 0, 1));
        side.addView(sideItem(R.drawable.ic_h_fav, "Favoritos", false, () -> open("fav")), new LinearLayout.LayoutParams(-1, 0, 1));
        side.addView(sideItem(R.drawable.ic_h_person, "Perfil", false, () -> startActivity(new Intent(this, AccountActivity.class))), new LinearLayout.LayoutParams(-1, 0, 1));
        side.addView(sideItem(R.drawable.ic_h_settings, "Ajustes", false, () -> startActivity(new Intent(this, SettingsActivity.class))), new LinearLayout.LayoutParams(-1, 0, 1));
        return side;
    }

    private View sideItem(int ic, String label, boolean selected, Runnable r) {
        LinearLayout it = new LinearLayout(this);
        it.setOrientation(LinearLayout.VERTICAL);
        it.setGravity(Gravity.CENTER);
        it.setFocusable(true); it.setClickable(true);
        it.setBackground(focusPanel(selected ? 0x331EA7FD : 0x00000000, 14));
        it.addView(icon(ic, 22, selected ? CYAN : TXT), new LinearLayout.LayoutParams(UI.dp(this, 24), UI.dp(this, 24)));
        TextView t = UI.text(this, label, 10, selected ? CYAN : TXT, false);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.topMargin = UI.dp(this, 4);
        it.addView(t, tl);
        it.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(it);
        return it;
    }

    // ------------------------------------------------------------ banner de destaque
    private View buildHero() {
        FrameLayout hero = new FrameLayout(this);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(0xFF0A1424); shape.setCornerRadius(UI.dp(this, 22));
        hero.setBackground(shape);
        hero.setClipToOutline(true);

        heroImg = new ImageView(this);
        heroImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(heroImg, new FrameLayout.LayoutParams(-1, -1));
        View fade = new View(this);
        fade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF2040A14, 0xCC040A14, 0x00040A14}));
        hero.addView(fade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        int pad = UI.dp(this, 22);
        info.setPadding(pad, UI.dp(this, 10), pad, UI.dp(this, 20));
        DisplayMetrics dm = getResources().getDisplayMetrics();
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams((int) (dm.widthPixels * 0.5f), -1);
        hero.addView(info, infoLp);

        heroChip = UI.text(this, "", 9, CYAN, true);
        heroChip.setBackground(ring(0x00000000, CYAN, 1));
        heroChip.setPadding(UI.dp(this, 22), UI.dp(this, 4), UI.dp(this, 22), UI.dp(this, 4));
        heroChip.setLetterSpacing(0.05f);
        info.addView(heroChip, new LinearLayout.LayoutParams(-2, -2));

        heroTitle = UI.text(this, Cfg.appName(), 28, TXT, true);
        heroTitle.setMaxLines(2); heroTitle.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(heroTitle, UI.lp(-1, -2, 8, this));
        heroMeta = UI.text(this, "", 11, CYAN, false);
        info.addView(heroMeta, UI.lp(-1, -2, 2, this));
        heroPlot = UI.text(this, "", 12, 0xDDFFFFFF, false);
        heroPlot.setMaxLines(3); heroPlot.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(heroPlot, UI.lp(-1, -2, 6, this));

        LinearLayout btns = new LinearLayout(this);
        btns.addView(heroBtn(R.drawable.ic_h_play, "ASSISTIR AGORA", true, () -> heroAction(true)));
        btns.addView(heroBtn(R.drawable.ic_h_info, "MAIS INFORMAÇÕES", false, () -> heroAction(false)));
        heroButtons = btns;
        info.addView(btns, UI.lp(-2, -2, 12, this));

        dots = new LinearLayout(this);
        dots.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(-1, -2);
        dl.gravity = Gravity.BOTTOM; dl.bottomMargin = UI.dp(this, 8);
        hero.addView(dots, dl);

        View border = new View(this);
        border.setBackground(ring(0x00000000, CYAN_SOFT, 2, 22));
        hero.addView(border, new FrameLayout.LayoutParams(-1, -1));

        slides.clear();
        setHeroEmpty();
        return hero;
    }

    private View heroBtn(int ic, String label, boolean filled, Runnable r) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true); b.setClickable(true);
        int ph = UI.dp(this, 22), pv = UI.dp(this, 9);
        b.setPadding(ph, pv, ph, pv);
        b.setBackground(ring(filled ? 0x551EA7FD : 0x44081528, CYAN, 2, 12));
        b.addView(icon(ic, 14, TXT), new LinearLayout.LayoutParams(UI.dp(this, 14), UI.dp(this, 14)));
        TextView t = UI.text(this, label, 10, TXT, true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = UI.dp(this, 8);
        b.addView(t, tl);
        b.setOnClickListener(v -> r.run());
        UI.scaleOnFocus(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = UI.dp(this, 10);
        b.setLayoutParams(lp);
        return b;
    }

    private void setHeroEmpty() {
        heroChip.setVisibility(View.GONE);
        heroButtons.setVisibility(View.GONE);
        heroMeta.setText("");
        heroPlot.setText(Cfg.get("home_notice", ""));
        heroTitle.setText(Cfg.appName());
        UI.image(heroImg, Cfg.get("background", ""), R.drawable.mx_background);
    }

    private void showSlide(int idx) {
        if (slides.isEmpty() || destroyed) return;
        slideIndex = idx;
        Slide s = slides.get(idx);
        heroChip.setVisibility(View.VISIBLE);
        heroButtons.setVisibility(View.VISIBLE);
        heroChip.setText("series".equals(s.item.kind) ? "SÉRIE EM DESTAQUE" : "FILME EM DESTAQUE");
        String t = s.item.name;
        if (!s.year.isEmpty() && !t.contains("(")) t += " (" + s.year + ")";
        heroTitle.setText(t);
        StringBuilder m = new StringBuilder(s.genre);
        if (s.rating > 0) { if (m.length() > 0) m.append("  •  "); m.append("★ ").append(String.format(Locale.US, "%.2f", s.rating)); }
        heroMeta.setText(m.toString());
        heroPlot.setText(s.plot);
        String img = !s.backdrop.isEmpty() ? s.backdrop : s.item.cover;
        heroImg.animate().alpha(0.2f).setDuration(150).withEndAction(() -> {
            if (destroyed) return;
            Glide.with(this).load(img).centerCrop().into(heroImg);
            heroImg.animate().alpha(1f).setDuration(350).start();
        }).start();
        dots.removeAllViews();
        for (int i = 0; i < slides.size(); i++) {
            View d = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(i == idx ? CYAN : 0x66FFFFFF);
            d.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UI.dp(this, 6), UI.dp(this, 6));
            lp.leftMargin = lp.rightMargin = UI.dp(this, 4);
            dots.addView(d, lp);
        }
    }

    private void loadHero() {
        slides.clear();
        for (Item i : Repo.featured(6)) slides.add(new Slide(i));
        ui.removeCallbacks(rotate);
        if (slides.isEmpty()) { setHeroEmpty(); return; }
        showSlide(0);
        ui.postDelayed(rotate, 7000);
        // busca detalhes (sinopse, gêneros, fundo) no servidor, um destaque por vez
        final Xtream x = Repo.xtream();
        if (x == null) return;
        for (final Slide s : new ArrayList<>(slides)) {
            Repo.async(() -> details(x, s), new Repo.Result<Slide>() {
                @Override public void ok(Slide v) { if (!destroyed && !slides.isEmpty() && slides.get(slideIndex) == v) showSlide(slideIndex); }
                @Override public void fail(String e) { }
            });
        }
    }

    private Slide details(Xtream x, Slide s) throws Exception {
        boolean series = "series".equals(s.item.kind);
        JSONObject j = series ? x.seriesInfo(s.item.id) : x.vodInfo(s.item.id);
        JSONObject info = j.optJSONObject("info");
        if (info == null) return s;
        Object bd = info.opt("backdrop_path");
        if (bd instanceof JSONArray && ((JSONArray) bd).length() > 0) s.backdrop = ((JSONArray) bd).optString(0, "");
        else if (bd instanceof String) s.backdrop = (String) bd;
        String plot = info.optString("plot", info.optString("description", ""));
        if (!plot.isEmpty()) s.plot = plot;
        s.genre = info.optString("genre", "");
        double r = info.optDouble("rating", 0);
        if (r > 0) s.rating = r;
        String rd = info.optString("releasedate", info.optString("releaseDate", ""));
        if (rd.length() >= 4 && rd.substring(0, 4).matches("\\d{4}")) s.year = rd.substring(0, 4);
        return s;
    }

    private void heroAction(boolean watch) {
        if (slides.isEmpty()) return;
        final Item it = slides.get(slideIndex).item;
        Runnable go = () -> {
            if (watch && "vod".equals(it.kind)) {
                ArrayList<Item> one = new ArrayList<>(); one.add(it);
                Repo.playlist = one; Repo.playlistIndex = 0;
                startActivity(new Intent(this, PlayerActivity.class));
            } else {
                Repo.selected = it;
                startActivity(new Intent(this, DetailsActivity.class));
            }
        };
        if (Rules.adult(it.name) && Repo.hasPin() && !Repo.adultUnlocked) UI.askPin(this, go::run); else go.run();
    }

    // ------------------------------------------------------------ assinatura + relógio/clima
    private View buildInfoRow() {
        LinearLayout row = new LinearLayout(this);
        row.addView(buildSubscription(), new LinearLayout.LayoutParams(0, -1, 1.05f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, -1, 1f);
        cl.leftMargin = UI.dp(this, 10);
        row.addView(buildClock(), cl);
        return row;
    }

    private View buildSubscription() {
        String exp = Prefs.get("acc_exp", "");
        String title = "ASSINATURA ATIVA", sub = "Sem data de vencimento";
        int color = GOLD;
        if (exp.matches("\\d{6,12}")) {
            long e = Long.parseLong(exp) * 1000L;
            String d = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR")).format(new Date(e));
            if (e < System.currentTimeMillis()) { title = "ASSINATURA VENCIDA"; sub = "Venceu em " + d; color = 0xFFFF5A5F; }
            else sub = "Válida até " + d;
        }
        final int c = color;
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setFocusable(true); card.setClickable(true);
        int pad = UI.dp(this, 14);
        card.setPadding(pad, 0, pad, 0);
        card.setBackground(ring(0x33F5B82E, c, 2, 14));
        card.addView(icon(R.drawable.ic_h_crown, 30, c), new LinearLayout.LayoutParams(UI.dp(this, 34), UI.dp(this, 34)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.addView(UI.text(this, title, 12, c, true));
        t.addView(UI.text(this, sub, 12, TXT, false));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1);
        tl.leftMargin = UI.dp(this, 12);
        card.addView(t, tl);
        card.addView(icon(R.drawable.ic_h_chevron, 22, TXT2), new LinearLayout.LayoutParams(UI.dp(this, 22), UI.dp(this, 22)));
        card.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        UI.scaleOnFocus(card);
        return card;
    }

    private View buildClock() {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        int pad = UI.dp(this, 14);
        card.setPadding(pad, 0, pad, 0);
        card.setBackground(ring(PANEL, CYAN_SOFT, 2, 14));
        card.addView(icon(R.drawable.ic_h_clock, 34, CYAN), new LinearLayout.LayoutParams(UI.dp(this, 36), UI.dp(this, 36)));

        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm a");
        clock.setTextColor(TXT); clock.setTextSize(24); clock.setTypeface(Typeface.DEFAULT_BOLD);
        t.addView(clock);
        dateText = UI.text(this, "", 9, TXT2, false);
        t.addView(dateText);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1);
        tl.leftMargin = UI.dp(this, 12);
        card.addView(t, tl);

        weatherIcon = new ImageView(this);
        card.addView(weatherIcon, new LinearLayout.LayoutParams(UI.dp(this, 30), UI.dp(this, 30)));
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);
        weatherText = UI.text(this, "--°C", 18, TXT, true);
        weatherDesc = UI.text(this, "", 9, TXT2, false);
        w.addView(weatherText); w.addView(weatherDesc);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.leftMargin = UI.dp(this, 8);
        card.addView(w, wl);
        return card;
    }

    private static String weatherName(int c) {
        if (c == 0) return "Céu limpo";
        if (c == 1) return "Predominante limpo";
        if (c == 2) return "Poucas nuvens";
        if (c == 3) return "Nublado";
        if (c == 45 || c == 48) return "Neblina";
        if (c >= 51 && c <= 57) return "Garoa";
        if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return "Chuva";
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return "Neve";
        if (c >= 95) return "Tempestade";
        return "";
    }

    // ------------------------------------------------------------ categorias em círculos
    private View buildCircles(int d) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.addView(circle(d, "CANAIS", "card_canais", R.drawable.ic_h_tv, 0xFF1EA7FD, 0xFF0B3A6B, "live"), cellLp());
        row.addView(circle(d, "FILMES", "card_filmes", R.drawable.ic_h_play, 0xFFE5304A, 0xFF5A0F1E, "vod"), cellLp());
        row.addView(circle(d, "SÉRIES", "card_series", R.drawable.ic_h_layers, 0xFF8A4DFF, 0xFF2D1566, "series"), cellLp());
        row.addView(circle(d, "ANIMES", "card_animes", R.drawable.ic_h_play, 0xFFD43FD0, 0xFF5A1457, "anime"), cellLp());
        row.addView(circle(d, "KIDS", "card_kids", R.drawable.ic_h_tv, 0xFFFF8A1E, 0xFF6B3207, "kids"), cellLp());
        row.addView(circle(d, "ESPORTES", "card_esportes", R.drawable.ic_h_sensors, 0xFF2FD26B, 0xFF0B4A24, "sports"), cellLp());
        return row;
    }

    private LinearLayout.LayoutParams cellLp() { return new LinearLayout.LayoutParams(0, -1, 1); }

    private View circle(int d, String label, String artName, int ic, int ringColor, int fillColor, final String kind) {
        FrameLayout cell = new FrameLayout(this);
        cell.setFocusable(true); cell.setClickable(true);
        FrameLayout c = new FrameLayout(this);
        GradientDrawable oval = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{fillColor, 0xFF050B16});
        oval.setShape(GradientDrawable.OVAL);
        oval.setStroke(UI.dp(this, 3), ringColor);
        c.setBackground(oval);
        c.setClipToOutline(true);
        int res = getResources().getIdentifier(artName, "drawable", getPackageName());
        if (res != 0) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageResource(res);
            c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        }
        View g = new View(this);
        GradientDrawable shade = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0x22000000, 0xDD000000});
        g.setBackground(shade);
        c.addView(g, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout lab = new LinearLayout(this);
        lab.setOrientation(LinearLayout.VERTICAL);
        lab.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        lab.setPadding(0, 0, 0, (int) (d * 0.13f));
        int isz = Math.max(UI.dp(this, 20), (int) (d * 0.17f));
        lab.addView(icon(ic, 20, TXT), new LinearLayout.LayoutParams(isz, isz));
        TextView t = UI.text(this, label, 13, TXT, true);
        t.setGravity(Gravity.CENTER);
        lab.addView(t);
        c.addView(lab, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(d, d);
        cl.gravity = Gravity.CENTER;
        cell.addView(c, cl);
        // anel de foco para controle remoto
        View focus = new View(this);
        GradientDrawable f = new GradientDrawable();
        f.setShape(GradientDrawable.OVAL); f.setStroke(UI.dp(this, 3), 0xFFFFFFFF);
        focus.setBackground(f); focus.setVisibility(View.INVISIBLE);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(d + UI.dp(this, 8), d + UI.dp(this, 8));
        fl.gravity = Gravity.CENTER;
        cell.addView(focus, fl);
        cell.setOnFocusChangeListener((v, has) -> {
            focus.setVisibility(has ? View.VISIBLE : View.INVISIBLE);
            v.animate().scaleX(has ? 1.06f : 1f).scaleY(has ? 1.06f : 1f).setDuration(120).start();
        });
        cell.setOnClickListener(v -> open(kind));
        return cell;
    }

    // ------------------------------------------------------------ helpers visuais
    private ImageView icon(int res, int dp, int tint) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setColorFilter(tint);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return iv;
    }

    private GradientDrawable ring(int fill, int stroke, int strokeDp) { return ring(fill, stroke, strokeDp, 100); }

    private GradientDrawable ring(int fill, int stroke, int strokeDp, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setStroke(UI.dp(this, strokeDp), stroke);
        g.setCornerRadius(UI.dp(this, radiusDp));
        return g;
    }

    private GradientDrawable panelBg(int radiusDp, int stroke) { return ring(PANEL, stroke, 2, radiusDp); }

    private android.graphics.drawable.StateListDrawable focusPanel(int normal, int radiusDp) {
        GradientDrawable focused = ring(0x551EA7FD, CYAN, 2, radiusDp);
        GradientDrawable base = new GradientDrawable();
        base.setColor(normal); base.setCornerRadius(UI.dp(this, radiusDp));
        android.graphics.drawable.StateListDrawable s = new android.graphics.drawable.StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, focused);
        s.addState(new int[]{android.R.attr.state_pressed}, focused);
        s.addState(new int[]{}, base);
        return s;
    }

    // ------------------------------------------------------------ navegação / dados
    private void open(String kind) {
        if (!Repo.loaded) { UI.toast(this, T.t("Atualizando conteúdo...")); return; }
        Intent i = new Intent(this, BrowseActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void loadContent(boolean force) {
        loading.setVisibility(View.VISIBLE);
        loading.setText(T.t("Atualizando conteúdo..."));
        Repo.load(this, force, new Repo.Listener() {
            @Override public void progress(String m) { loading.setText(T.t("Atualizando conteúdo...") + "\n" + m); }
            @Override public void done(String err) {
                if (destroyed) return;
                if (err != null) {
                    new AlertDialog.Builder(HomeActivity.this).setMessage(err).setCancelable(false)
                            .setPositiveButton(T.t("Tentar novamente"), (d, w) -> loadContent(true))
                            .setNegativeButton(T.t("Sair da conta"), (d, w) -> logout()).show();
                    return;
                }
                loading.setVisibility(View.GONE);
                loadHero();
            }
        });
    }

    private void refreshWeather() {
        Repo.async(Weather::fetch, new Repo.Result<Weather.Info>() {
            @Override public void ok(Weather.Info w) {
                weatherText.setText(w.temp + "°C");
                weatherDesc.setText(weatherName(w.code));
                weatherIcon.setImageResource(Weather.icon(w));
            }
            @Override public void fail(String e) { weatherText.setText("--°C"); }
        });
    }

    /** Ativação remota: confere se o painel mudou a lista (DNS/URL) ou desativou o ID. */
    private void checkRemote() {
        if (!Prefs.bool("activated_remote", false)) return;
        Repo.async(Panel::activation, new Repo.Result<Panel.Activation>() {
            @Override public void ok(Panel.Activation a) {
                if (!a.active) { UI.toast(HomeActivity.this, "Ativação removida pelo painel."); logout(); return; }
                String rev = String.valueOf(a.revision);
                if (!rev.equals(Prefs.get("activation_rev", ""))) {
                    Prefs.put("activation_rev", rev);
                    final String url = a.m3u;
                    Repo.async(() -> { LoginActivity.completeFromUrl(url, true); return true; }, new Repo.Result<Boolean>() {
                        @Override public void ok(Boolean v) { loadContent(true); }
                        @Override public void fail(String e) { UI.toast(HomeActivity.this, e); }
                    });
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void logout() {
        Repo.logout(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!Repo.loaded && loading.getVisibility() != View.VISIBLE) loadContent(false);
        if (slides.size() > 1) { ui.removeCallbacks(rotate); ui.postDelayed(rotate, 7000); }
    }

    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(rotate); }

    @Override protected void onDestroy() {
        destroyed = true;
        ui.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Fechar " + Cfg.appName() + "?")
                .setPositiveButton(T.t("Fechar"), (d, w) -> finishAffinity())
                .setNegativeButton(T.t("Cancelar"), null).show();
    }
}
