package com.mxflix.app;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HomeActivity extends AppCompatActivity {
    private TextView loading, weatherText;
    private ImageView weatherIcon;
    private RecyclerView carousel;
    private CarouselAdapter carouselAdapter;
    private LinearLayout content;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        UI.image(bg, Cfg.get("background", ""), R.drawable.mx_background);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC0A0305, 0xF20A0305}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));
        root.addView(new ParticlesView(this), new FrameLayout.LayoutParams(-1, -1));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        content.setPadding(p, p / 2, p, p / 2);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        // cabeçalho
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        UI.image(logo, Cfg.get("logo", ""), R.drawable.mx_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        head.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 40), UI.dp(this, 40)));
        TextView name = UI.text(this, Cfg.appName(), 20, UI.WHITE, true);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, -2, 1);
        nl.leftMargin = UI.dp(this, 10);
        head.addView(name, nl);
        weatherIcon = new ImageView(this);
        head.addView(weatherIcon, new LinearLayout.LayoutParams(UI.dp(this, 28), UI.dp(this, 28)));
        weatherText = UI.text(this, "--°C", 14, UI.WHITE, false);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.leftMargin = UI.dp(this, 6); wl.rightMargin = UI.dp(this, 14);
        head.addView(weatherText, wl);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm a");
        clock.setTextColor(UI.WHITE); clock.setTextSize(18);
        head.addView(clock);
        content.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // aviso do painel
        String notice = Cfg.get("home_notice", "");
        if (!notice.isEmpty()) {
            TextView n = UI.text(this, "📢  " + notice, 13, Cfg.primary(), false);
            n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.MARQUEE);
            n.setMarqueeRepeatLimit(-1); n.setSelected(true);
            content.addView(n, UI.lp(-1, -2, 8, this));
        }

        // carrossel principal
        carousel = new RecyclerView(this);
        carousel.setClipToPadding(false);
        carousel.setClipChildren(false);
        carousel.setOverScrollMode(View.OVER_SCROLL_NEVER);
        carousel.setLayoutManager(new CarouselLayoutManager(this));
        new LinearSnapHelper().attachToRecyclerView(carousel);
        carouselAdapter = new CarouselAdapter();
        carousel.setAdapter(carouselAdapter);
        carousel.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> {
            int h = bt - t, w = r - l;
            if (h <= 0 || w <= 0) return;
            int ch = Math.max(UI.dp(this, 150), h - UI.dp(this, 12));
            int cw = (int) (ch * 0.64f);
            if (ch != cardH || cw != cardW) {
                cardH = ch; cardW = cw;
                int pad = Math.max(0, (w - cw) / 2);
                carousel.setPadding(pad, 0, pad, 0);
                carouselAdapter.notifyDataSetChanged();
            }
        });
        content.addView(carousel, UI.lp(-1, 0, 8, this));
        ((LinearLayout.LayoutParams) carousel.getLayoutParams()).weight = 1;

        // botões inferiores
        LinearLayout bar = new LinearLayout(this);
        bar.addView(navBtn("🔍  " + T.t("Busca"), () -> open("search")));
        bar.addView(navBtn("⚙  " + T.t("Ajustes"), () -> startActivity(new Intent(this, SettingsActivity.class))));
        bar.addView(navBtn("👤  " + T.t("Conta"), () -> startActivity(new Intent(this, AccountActivity.class))));
        content.addView(bar, UI.lp(-1, -2, 12, this));

        loading = UI.text(this, T.t("Atualizando conteúdo..."), 15, UI.WHITE, true);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundColor(0xE60A0305);
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        loadContent(false);
        refreshWeather();
        checkRemote();
        Repo.async(Panel::config, new Repo.Result<org.json.JSONObject>() {
            @Override public void ok(org.json.JSONObject v) { }
            @Override public void fail(String e) { }
        });
    }

    private int cardW = 0, cardH = 0;
    private final String[] KINDS = {"live", "vod", "series", "fav", "history"};

    /** Cards do carrossel (arte + título). O item do centro é destacado pelo CarouselLayoutManager. */
    private class CarouselAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public RecyclerView.ViewHolder onCreateViewHolder(android.view.ViewGroup p, int t) {
            FrameLayout f = new FrameLayout(p.getContext());
            f.setFocusable(true); f.setClickable(true);
            f.setBackground(UI.focusBg(p.getContext(), UI.SURFACE, 16));
            int pad = UI.dp(p.getContext(), 3);
            f.setPadding(pad, pad, pad, pad);
            ImageView iv = new ImageView(p.getContext());
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setId(android.R.id.icon);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            View g = new View(p.getContext());
            g.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0xEE000000}));
            FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(-1, UI.dp(p.getContext(), 100));
            gl.gravity = Gravity.BOTTOM;
            f.addView(g, gl);
            TextView tv = UI.text(p.getContext(), "", 17, UI.WHITE, true);
            tv.setId(android.R.id.text1);
            tv.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2);
            tl.gravity = Gravity.BOTTOM; tl.bottomMargin = UI.dp(p.getContext(), 14);
            f.addView(tv, tl);
            f.setLayoutParams(new RecyclerView.LayoutParams(Math.max(cardW, 1), Math.max(cardH, 1)));
            return new RecyclerView.ViewHolder(f) { };
        }

        @Override public void onBindViewHolder(final RecyclerView.ViewHolder h, int pos) {
            final String kind = KINDS[pos];
            int art; String label;
            switch (kind) {
                case "live": art = R.drawable.card_canais; label = T.t("Ao Vivo"); break;
                case "vod": art = R.drawable.card_filmes; label = T.t("Filmes"); break;
                case "series": art = R.drawable.card_series; label = T.t("Séries"); break;
                case "fav": art = R.drawable.card_animes; label = T.t("Favoritos"); break;
                default: art = R.drawable.card_historico; label = T.t("Continuar assistindo"); break;
            }
            ((ImageView) h.itemView.findViewById(android.R.id.icon)).setImageResource(art);
            ((TextView) h.itemView.findViewById(android.R.id.text1)).setText(label);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(Math.max(cardW, 1), Math.max(cardH, 1));
            lp.leftMargin = UI.dp(HomeActivity.this, 8); lp.rightMargin = UI.dp(HomeActivity.this, 8);
            h.itemView.setLayoutParams(lp);
            h.itemView.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p < 0) return;
                if (v.getScaleX() < 0.97f) carousel.smoothScrollToPosition(p);   // lateral: primeiro centraliza
                else open(kind);
            });
            h.itemView.setOnFocusChangeListener((v, f) -> {
                int p = h.getBindingAdapterPosition();
                if (f && p >= 0) carousel.smoothScrollToPosition(p);
            });
        }

        @Override public int getItemCount() { return KINDS.length; }
    }

    private View navBtn(String label, Runnable r) {
        TextView b = UI.button(this, label, r);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = UI.dp(this, 10);
        b.setLayoutParams(lp);
        return b;
    }

    private void open(String kind) {
        if (!Repo.loaded) { UI.toast(this, T.t("Atualizando conteúdo...")); return; }
        Intent i = new Intent(this, BrowseActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void play(Item it) {
        if ("episode".equals(it.kind) || "live".equals(it.kind) || it.url != null && !it.url.isEmpty()) {
            java.util.ArrayList<Item> one = new java.util.ArrayList<>();
            one.add(it);
            Repo.playlist = one; Repo.playlistIndex = 0;
            startActivity(new Intent(this, PlayerActivity.class));
        } else {
            Repo.selected = it;
            startActivity(new Intent(this, DetailsActivity.class));
        }
    }

    private void loadContent(boolean force) {
        loading.setVisibility(View.VISIBLE);
        loading.setText(T.t("Atualizando conteúdo..."));
        Repo.load(this, force, new Repo.Listener() {
            @Override public void progress(String m) { loading.setText(T.t("Atualizando conteúdo...") + "\n" + m); }
            @Override public void done(String err) {
                if (err != null) {
                    new AlertDialog.Builder(HomeActivity.this).setMessage(err).setCancelable(false)
                            .setPositiveButton(T.t("Tentar novamente"), (d, w) -> loadContent(true))
                            .setNegativeButton(T.t("Sair da conta"), (d, w) -> logout()).show();
                    return;
                }
                loading.setVisibility(View.GONE);
            }
        });
    }

    private void refreshWeather() {
        Repo.async(Weather::fetch, new Repo.Result<Weather.Info>() {
            @Override public void ok(Weather.Info w) {
                weatherText.setText(w.temp + "°C");
                weatherIcon.setImageResource(Weather.icon(w));
            }
            @Override public void fail(String e) { weatherText.setText("--°C"); }
        });
    }

    /** Ativação remota: confere se o painel mudou a lista (DNS/URL) ou desativou o ID. */
    private void checkRemote() {
        if (!Prefs.bool("activated_remote", false)) return;
        Repo.async(Panel::activation, new Repo.Result<Panel.Activation>() {
            @Override public void ok(Panel.Activation a) {
                if (!a.active) { UI.toast(HomeActivity.this, "Ativação removida pelo painel."); logout(); return; }
                String rev = String.valueOf(a.revision);
                if (!rev.equals(Prefs.get("activation_rev", ""))) {
                    Prefs.put("activation_rev", rev);
                    final String url = a.m3u;
                    Repo.async(() -> { LoginActivity.completeFromUrl(url, true); return true; }, new Repo.Result<Boolean>() {
                        @Override public void ok(Boolean v) { loadContent(true); }
                        @Override public void fail(String e) { UI.toast(HomeActivity.this, e); }
                    });
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void logout() {
        Repo.logout(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!Repo.loaded && loading.getVisibility() != View.VISIBLE) loadContent(false);
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Fechar " + Cfg.appName() + "?")
                .setPositiveButton(T.t("Fechar"), (d, w) -> finishAffinity())
                .setNegativeButton(T.t("Cancelar"), null).show();
    }
}
