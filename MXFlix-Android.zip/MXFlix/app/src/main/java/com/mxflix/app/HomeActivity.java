package com.mxflix.app;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HomeActivity extends AppCompatActivity {
    private TextView loading, weatherText, continueLabel;
    private ImageView weatherIcon;
    private RecyclerView rail;
    private ItemAdapter railAdapter;
    private LinearLayout content;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(UI.BG);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        UI.image(bg, Cfg.get("background", ""), R.drawable.mx_background);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xCC05070D, 0xF205070D}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int p = UI.dp(this, 20);
        content.setPadding(p, p / 2, p, p / 2);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        // cabeçalho
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        UI.image(logo, Cfg.get("logo", ""), R.drawable.mx_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        head.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 40), UI.dp(this, 40)));
        TextView name = UI.text(this, Cfg.appName(), 20, UI.WHITE, true);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, -2, 1);
        nl.leftMargin = UI.dp(this, 10);
        head.addView(name, nl);
        weatherIcon = new ImageView(this);
        head.addView(weatherIcon, new LinearLayout.LayoutParams(UI.dp(this, 28), UI.dp(this, 28)));
        weatherText = UI.text(this, "--°C", 14, UI.WHITE, false);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-2, -2);
        wl.leftMargin = UI.dp(this, 6); wl.rightMargin = UI.dp(this, 14);
        head.addView(weatherText, wl);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm"); clock.setFormat12Hour("hh:mm a");
        clock.setTextColor(UI.WHITE); clock.setTextSize(18);
        head.addView(clock);
        content.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // aviso do painel
        String notice = Cfg.get("home_notice", "");
        if (!notice.isEmpty()) {
            TextView n = UI.text(this, "📢  " + notice, 13, Cfg.primary(), false);
            n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.MARQUEE);
            n.setMarqueeRepeatLimit(-1); n.setSelected(true);
            content.addView(n, UI.lp(-1, -2, 8, this));
        }

        // cards principais
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        hs.addView(row);
        row.addView(card(T.t("Ao Vivo"), R.drawable.card_canais, "live"));
        row.addView(card(T.t("Filmes"), R.drawable.card_filmes, "vod"));
        row.addView(card(T.t("Séries"), R.drawable.card_series, "series"));
        row.addView(card(T.t("Favoritos"), R.drawable.card_animes, "fav"));
        row.addView(card(T.t("Continuar assistindo"), R.drawable.card_historico, "history"));
        content.addView(hs, UI.lp(-1, -2, 12, this));

        // botões inferiores
        LinearLayout bar = new LinearLayout(this);
        bar.addView(navBtn("🔍  " + T.t("Busca"), () -> open("search")));
        bar.addView(navBtn("⚙  " + T.t("Ajustes"), () -> startActivity(new Intent(this, SettingsActivity.class))));
        bar.addView(navBtn("👤  " + T.t("Conta"), () -> startActivity(new Intent(this, AccountActivity.class))));
        content.addView(bar, UI.lp(-1, -2, 12, this));

        continueLabel = UI.text(this, T.t("Continuar assistindo").toUpperCase(), 12, UI.MUTED, true);
        content.addView(continueLabel, UI.lp(-1, -2, 12, this));
        rail = new RecyclerView(this);
        rail.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        railAdapter = new ItemAdapter(110, (it, pos) -> play(it), null);
        rail.setAdapter(railAdapter);
        content.addView(rail, new LinearLayout.LayoutParams(-1, 0, 1));

        loading = UI.text(this, T.t("Atualizando conteúdo..."), 15, UI.WHITE, true);
        loading.setGravity(Gravity.CENTER);
        loading.setBackgroundColor(0xE605070D);
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        loadContent(false);
        refreshWeather();
        checkRemote();
        Repo.async(Panel::config, new Repo.Result<org.json.JSONObject>() {
            @Override public void ok(org.json.JSONObject v) { }
            @Override public void fail(String e) { }
        });
    }

    private View card(String label, int art, final String kind) {
        FrameLayout f = new FrameLayout(this);
        f.setFocusable(true); f.setClickable(true);
        f.setBackground(UI.focusBg(this, UI.SURFACE, 14));
        int pad = UI.dp(this, 3);
        f.setPadding(pad, pad, pad, pad);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setImageResource(art);
        f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        View g = new View(this);
        g.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0xE6000000}));
        FrameLayout.LayoutParams gl = new FrameLayout.LayoutParams(-1, UI.dp(this, 90));
        gl.gravity = Gravity.BOTTOM;
        f.addView(g, gl);
        TextView t = UI.text(this, label, 15, UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(-1, -2);
        tl.gravity = Gravity.BOTTOM; tl.bottomMargin = UI.dp(this, 12);
        f.addView(t, tl);
        f.setOnClickListener(v -> open(kind));
        UI.scaleOnFocus(f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UI.dp(this, 140), UI.dp(this, 215));
        lp.rightMargin = UI.dp(this, 12);
        f.setLayoutParams(lp);
        return f;
    }

    private View navBtn(String label, Runnable r) {
        TextView b = UI.button(this, label, r);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = UI.dp(this, 10);
        b.setLayoutParams(lp);
        return b;
    }

    private void open(String kind) {
        if (!Repo.loaded) { UI.toast(this, T.t("Atualizando conteúdo...")); return; }
        Intent i = new Intent(this, BrowseActivity.class);
        i.putExtra("kind", kind);
        startActivity(i);
    }

    private void play(Item it) {
        if ("episode".equals(it.kind) || "live".equals(it.kind) || it.url != null && !it.url.isEmpty()) {
            java.util.ArrayList<Item> one = new java.util.ArrayList<>();
            one.add(it);
            Repo.playlist = one; Repo.playlistIndex = 0;
            startActivity(new Intent(this, PlayerActivity.class));
        } else {
            Repo.selected = it;
            startActivity(new Intent(this, DetailsActivity.class));
        }
    }

    private void loadContent(boolean force) {
        loading.setVisibility(View.VISIBLE);
        loading.setText(T.t("Atualizando conteúdo..."));
        Repo.load(this, force, new Repo.Listener() {
            @Override public void progress(String m) { loading.setText(T.t("Atualizando conteúdo...") + "\n" + m); }
            @Override public void done(String err) {
                if (err != null) {
                    new AlertDialog.Builder(HomeActivity.this).setMessage(err).setCancelable(false)
                            .setPositiveButton(T.t("Tentar novamente"), (d, w) -> loadContent(true))
                            .setNegativeButton(T.t("Sair da conta"), (d, w) -> logout()).show();
                    return;
                }
                loading.setVisibility(View.GONE);
                refreshRail();
            }
        });
    }

    private void refreshRail() {
        List<Item> h = Store.get(this).history(Repo.session(), true);
        railAdapter.set(h);
        int vis = h.isEmpty() ? View.GONE : View.VISIBLE;
        rail.setVisibility(vis); continueLabel.setVisibility(vis);
    }

    private void refreshWeather() {
        Repo.async(Weather::fetch, new Repo.Result<Weather.Info>() {
            @Override public void ok(Weather.Info w) {
                weatherText.setText(w.temp + "°C");
                weatherIcon.setImageResource(Weather.icon(w));
            }
            @Override public void fail(String e) { weatherText.setText("--°C"); }
        });
    }

    /** Ativação remota: confere se o painel mudou a lista (DNS/URL) ou desativou o ID. */
    private void checkRemote() {
        if (!Prefs.bool("activated_remote", false)) return;
        Repo.async(Panel::activation, new Repo.Result<Panel.Activation>() {
            @Override public void ok(Panel.Activation a) {
                if (!a.active) { UI.toast(HomeActivity.this, "Ativação removida pelo painel."); logout(); return; }
                String rev = String.valueOf(a.revision);
                if (!rev.equals(Prefs.get("activation_rev", ""))) {
                    Prefs.put("activation_rev", rev);
                    final String url = a.m3u;
                    Repo.async(() -> { LoginActivity.completeFromUrl(url, true); return true; }, new Repo.Result<Boolean>() {
                        @Override public void ok(Boolean v) { loadContent(true); }
                        @Override public void fail(String e) { UI.toast(HomeActivity.this, e); }
                    });
                }
            }
            @Override public void fail(String e) { }
        });
    }

    private void logout() {
        Repo.logout(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Repo.loaded) refreshRail();
        if (!Repo.loaded && loading.getVisibility() != View.VISIBLE) loadContent(false);
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setMessage("Fechar " + Cfg.appName() + "?")
                .setPositiveButton(T.t("Fechar"), (d, w) -> finishAffinity())
                .setNegativeButton(T.t("Cancelar"), null).show();
    }
}
