package com.mxflix.app;

import android.os.Build;
import java.security.MessageDigest;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

/** Comunicação com o painel web (api/*.php). */
public final class Panel {
    private Panel() {}

    public static class PanelException extends Exception {
        public final int code;
        public PanelException(String m, int code) { super(m); this.code = code; }
    }

    public static String baseUrl() {
        String u = Prefs.get("panel_url", "");
        if (u.isEmpty()) u = BuildConfig.PANEL_URL;
        u = u.trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    public static boolean isConfigured() {
        String u = baseUrl();
        return !u.isEmpty() && !u.contains("SEU-PAINEL");
    }

    public static void setBaseUrl(String url) {
        url = url.trim();
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        if (url.endsWith("/api")) url = url.substring(0, url.length() - 4);
        Prefs.put("panel_url", url);
    }

    /** ID interno único do aparelho (16-80 chars [a-zA-Z0-9-]). */
    public static String deviceId() {
        String id = Prefs.get("device_id", "");
        if (id.isEmpty()) { id = UUID.randomUUID().toString(); Prefs.put("device_id", id); }
        return id;
    }

    /** ID amigável de 7 caracteres exibido ao usuário e usado pelo suporte. */
    public static String friendlyId() {
        String f = Prefs.get("friendly_id", "");
        if (f.length() == 7) return f;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest(deviceId().getBytes("UTF-8"));
            String alpha = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 7; i++) sb.append(alpha.charAt((h[i] & 0xff) % alpha.length()));
            f = sb.toString();
        } catch (Exception e) { f = "MXF" + (int) (Math.random() * 9000 + 1000); }
        Prefs.put("friendly_id", f);
        return f;
    }

    private static String token() { return Vault.decrypt(Prefs.get("device_token", "")); }

    private static JSONObject call(String path, JSONObject body, boolean auth, boolean post) throws PanelException {
        if (!isConfigured()) throw new PanelException("Painel não configurado.", 0);
        try {
            String url = baseUrl() + "/api/" + path;
            Http.Result r = post
                    ? Http.postJson(url, body == null ? "{}" : body.toString(), auth ? token() : null)
                    : Http.get(url, auth ? token() : null);
            JSONObject j;
            try { j = new JSONObject(r.body); } catch (Exception e) { throw new PanelException("Resposta inválida do painel (" + r.code + ").", r.code); }
            if (!j.optBoolean("success", false)) throw new PanelException(j.optString("error", "Erro do painel."), r.code);
            return j;
        } catch (PanelException e) {
            throw e;
        } catch (Exception e) {
            throw new PanelException(T.t("Falha de conexão. Verifique a internet."), -1);
        }
    }

    /** Configurações públicas (aparência, suporte, avisos). Mantém cache local. */
    public static JSONObject config() throws PanelException {
        JSONObject j = call("config.php", null, false, false);
        JSONObject d = j.optJSONObject("data");
        if (d == null) d = new JSONObject();
        Prefs.put("config_json", d.toString());
        Prefs.putLong("config_time", System.currentTimeMillis());
        return d;
    }

    public static JSONArray servers() throws PanelException {
        JSONObject j = call("servers.php", null, false, false);
        JSONArray a = j.optJSONArray("data");
        return a == null ? new JSONArray() : a;
    }

    /** Registra/atualiza o aparelho. Retorna pin_hash (pode ser vazio). */
    public static String registerDevice(String server, String username, String status, String expiration) throws PanelException {
        try {
            JSONObject b = new JSONObject();
            b.put("device_id", deviceId());
            b.put("friendly_device_id", friendlyId());
            b.put("username", username);
            b.put("server", server);
            b.put("status", status == null ? "" : status);
            b.put("expiration", expiration == null ? "" : expiration);
            b.put("model", (Build.MANUFACTURER + " " + Build.MODEL).trim());
            b.put("app_version", BuildConfig.VERSION_NAME);
            JSONObject j = call("device.php", b, true, true);
            JSONObject d = j.optJSONObject("data");
            if (d == null) return "";
            String tk = d.optString("token", "");
            if (!tk.isEmpty()) Prefs.put("device_token", Vault.encrypt(tk));
            return d.optString("pin_hash", "");
        } catch (org.json.JSONException e) {
            throw new PanelException("Erro interno.", 0);
        }
    }

    /** Resultado da ativação remota por ID. */
    public static class Activation { public boolean active; public int revision; public String m3u; }

    public static Activation activation() throws PanelException {
        try {
            JSONObject b = new JSONObject();
            b.put("device_id", deviceId());
            b.put("friendly_device_id", friendlyId());
            String t = Vault.decrypt(Prefs.get("activation_token", ""));
            if (!t.isEmpty()) b.put("token", t);
            JSONObject j = call("activation.php", b, false, true);
            JSONObject d = j.optJSONObject("data");
            Activation a = new Activation();
            if (d != null) {
                a.active = d.optBoolean("active", false);
                a.revision = d.optInt("revision", 0);
                a.m3u = d.optString("m3u_url", "");
                String tk = d.optString("token", "");
                if (!tk.isEmpty()) Prefs.put("activation_token", Vault.encrypt(tk));
            }
            return a;
        } catch (org.json.JSONException e) {
            throw new PanelException("Erro interno.", 0);
        }
    }

    /** Teste grátis: retorna objeto com m3u_url, username, expires_at. */
    public static JSONObject trial() throws PanelException {
        try {
            JSONObject b = new JSONObject();
            b.put("device_id", deviceId());
            b.put("friendly_device_id", friendlyId());
            JSONObject j = call("trial.php", b, false, true);
            JSONObject d = j.optJSONObject("data");
            if (d == null) throw new PanelException("Resposta inválida.", 0);
            return d;
        } catch (org.json.JSONException e) {
            throw new PanelException("Erro interno.", 0);
        }
    }

    public static void log(final String event) {
        new Thread(() -> {
            try {
                if (token().isEmpty()) return;
                JSONObject b = new JSONObject();
                b.put("event", event);
                call("login_log.php", b, true, true);
            } catch (Exception ignored) { }
        }).start();
    }

    public static void syncPin(final String pin) {
        new Thread(() -> {
            try {
                if (token().isEmpty()) return;
                JSONObject b = new JSONObject();
                b.put("pin", pin);
                call("pin.php", b, true, true);
            } catch (Exception ignored) { }
        }).start();
    }
}
