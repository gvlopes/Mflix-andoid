package com.mxflix.app;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;

/** Carrossel horizontal: o item do centro é maior e opaco; os laterais diminuem e esmaecem. */
public class CarouselLayoutManager extends LinearLayoutManager {
    public CarouselLayoutManager(Context c) { super(c, HORIZONTAL, false); }

    @Override public void onLayoutCompleted(RecyclerView.State s) { super.onLayoutCompleted(s); apply(); }

    @Override public int scrollHorizontallyBy(int dx, RecyclerView.Recycler r, RecyclerView.State s) {
        int scrolled = super.scrollHorizontallyBy(dx, r, s);
        apply();
        return scrolled;
    }

    private void apply() {
        float mid = getWidth() / 2f;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            if (v == null) continue;
            float cm = (getDecoratedLeft(v) + getDecoratedRight(v)) / 2f;
            float d = Math.min(1f, Math.abs(mid - cm) / Math.max(1f, v.getWidth() * 1.7f));
            float sc = 1f - 0.26f * d;
            v.setScaleX(sc); v.setScaleY(sc);
            v.setAlpha(1f - 0.55f * d);
        }
    }

    /** Rola centralizando o item alvo. */
    @Override public void smoothScrollToPosition(RecyclerView rv, RecyclerView.State state, int position) {
        LinearSmoothScroller ss = new LinearSmoothScroller(rv.getContext()) {
            @Override public int calculateDtToFit(int viewStart, int viewEnd, int boxStart, int boxEnd, int pref) {
                return (boxStart + (boxEnd - boxStart) / 2) - (viewStart + (viewEnd - viewStart) / 2);
            }
            @Override protected float calculateSpeedPerPixel(DisplayMetrics dm) { return 70f / dm.densityDpi; }
        };
        ss.setTargetPosition(position);
        startSmoothScroll(ss);
    }
}
