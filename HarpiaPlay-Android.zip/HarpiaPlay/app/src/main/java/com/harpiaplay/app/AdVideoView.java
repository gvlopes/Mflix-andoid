package com.harpiaplay.app;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import okhttp3.Request;
import okhttp3.Response;

/** Vídeo de fundo (anúncio do painel): baixa uma vez, toca mudo e em loop infinito. */
@OptIn(markerClass = UnstableApi.class)
public class AdVideoView extends FrameLayout {
    private static final long MAX_BYTES = 60L * 1024 * 1024;
    private ExoPlayer player;
    private boolean paused = false;

    public AdVideoView(Context c) { super(c); setBackgroundColor(Color.TRANSPARENT); }

    /** Começa a baixar (se preciso) e tocar o vídeo da URL. URL vazia = não faz nada. */
    public void load(final String url) {
        if (url == null || url.isEmpty()) return;
        Repo.async(() -> download(url), new Repo.Result<File>() {
            @Override public void ok(File f) { if (isAttachedToWindow() || getParent() != null) start(f); }
            @Override public void fail(String e) { }
        });
    }

    private File download(String url) throws Exception {
        File dir = getContext().getCacheDir();
        String name = "ad_" + Repo.sha256(url).substring(0, 16) + ".mp4";
        File f = new File(dir, name);
        if (f.exists() && f.length() > 0) return f;
        File[] old = dir.listFiles((d, n) -> n.startsWith("ad_") && (n.endsWith(".mp4") || n.endsWith(".part")));
        if (old != null) for (File o : old) o.delete();
        File tmp = new File(dir, name + ".part");
        Request rq = new Request.Builder().url(url).header("User-Agent", Http.UA).build();
        try (Response r = Http.client().newCall(rq).execute()) {
            if (!r.isSuccessful() || r.body() == null) throw new Exception("HTTP " + r.code());
            if (r.body().contentLength() > MAX_BYTES) throw new Exception("Vídeo grande demais");
            try (InputStream in = r.body().byteStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[16384];
                long total = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > MAX_BYTES) throw new Exception("Vídeo grande demais");
                    out.write(buf, 0, n);
                }
            }
        } catch (Exception e) { tmp.delete(); throw e; }
        if (!tmp.renameTo(f)) throw new Exception("Falha ao salvar o vídeo");
        return f;
    }

    private void start(File f) {
        if (player != null) return;
        PlayerView pv = new PlayerView(getContext());
        pv.setUseController(false);
        pv.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        pv.setShutterBackgroundColor(Color.TRANSPARENT);
        pv.setKeepContentOnPlayerReset(true);
        pv.setAlpha(0f);
        addView(pv, new FrameLayout.LayoutParams(-1, -1));
        player = new ExoPlayer.Builder(getContext()).build();
        player.setRepeatMode(Player.REPEAT_MODE_ALL);    // loop infinito
        player.setVolume(0f);
        pv.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(f)));
        player.prepare();
        player.setPlayWhenReady(!paused);
        pv.animate().alpha(1f).setDuration(700).start();   // aparece suavemente
    }

    public void pause() { paused = true; if (player != null) player.setPlayWhenReady(false); }
    public void resume() { paused = false; if (player != null) player.setPlayWhenReady(true); }

    public void release() {
        if (player != null) { player.release(); player = null; }
    }

    @Override protected void onDetachedFromWindow() { release(); super.onDetachedFromWindow(); }

    /** Atalho para esconder/mostrar sem recriar. */
    public void show(boolean v) { setVisibility(v ? View.VISIBLE : View.GONE); }
}
