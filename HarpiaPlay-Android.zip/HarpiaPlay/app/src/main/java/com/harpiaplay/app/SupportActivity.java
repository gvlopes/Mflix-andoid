package com.harpiaplay.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;

/** Suporte: QR code (só se o painel tiver um link) e, ao lado, telefone e e-mail. */
public class SupportActivity extends BaseActivity {
    private FrameLayout holder;

    /** +55 (11) 99999-9999 para números brasileiros; "+" + dígitos nos demais. */
    static String formatPhone(String digits) {
        if (digits == null || digits.isEmpty()) return "";
        String d = digits.replaceAll("\\D", "");
        if (d.startsWith("55") && (d.length() == 12 || d.length() == 13)) {
            String ddd = d.substring(2, 4), n = d.substring(4);
            return "+55 (" + ddd + ") " + n.substring(0, n.length() - 4) + "-" + n.substring(n.length() - 4);
        }
        return "+" + d;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        int p = UI.dp(this, 20);
        root.setPadding(p, p, p, p);
        root.addView(UI.topBar(this, Cfg.get("support_name", T.t("Suporte"))));
        holder = new FrameLayout(this);
        root.addView(holder, UI.lp(-1, 0, 12, this));
        ((LinearLayout.LayoutParams) holder.getLayoutParams()).weight = 1;
        setContentView(root);
        build();
        // pega o que foi alterado no painel agora mesmo
        Repo.async(Panel::config, new Repo.Result<JSONObject>() {
            @Override public void ok(JSONObject v) { build(); }
            @Override public void fail(String e) { }
        });
    }

    private void build() {
        holder.removeAllViews();
        final String qr = Cfg.get("support_qr", "");
        final String phone = Cfg.get("support_phone", "");
        final String email = Cfg.get("support_email", "");
        final String tg = Cfg.get("support_telegram_user", "");
        final String text = Cfg.get("support_text", "");

        if (qr.isEmpty() && phone.isEmpty() && email.isEmpty() && tg.isEmpty() && text.isEmpty()) {
            TextView t = UI.text(this, "O suporte ainda não foi configurado.", 15, UI.MUTED, false);
            holder.addView(t, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
            return;
        }

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(row, new ScrollView.LayoutParams(-1, -2));
        holder.addView(sv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER_VERTICAL));
        row.setGravity(Gravity.CENTER);

        // QR code (somente se houver link no painel)
        if (!qr.isEmpty()) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            card.setBackground(UI.round(this, UI.SURFACE, 18));
            int cp = UI.dp(this, 16);
            card.setPadding(cp, cp, cp, cp);
            ImageView iv = new ImageView(this);
            iv.setBackgroundColor(0xFFFFFFFF);
            iv.setPadding(UI.dp(this, 8), UI.dp(this, 8), UI.dp(this, 8), UI.dp(this, 8));
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            UI.image(iv, qr, R.drawable.hp_logo);
            card.addView(iv, new LinearLayout.LayoutParams(UI.dp(this, 190), UI.dp(this, 190)));
            TextView cap = UI.text(this, "Aponte a câmera do celular", 12, UI.MUTED, false);
            cap.setGravity(Gravity.CENTER);
            card.addView(cap, UI.lp(-2, -2, 10, this));
            LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(-2, -2);
            ql.rightMargin = UI.dp(this, 20);
            row.addView(card, ql);
        }

        // contatos ao lado
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setBackground(UI.round(this, UI.SURFACE, 18));
        row.addView(info, new LinearLayout.LayoutParams(UI.dp(this, 360), -2));
        if (!phone.isEmpty()) contact(info, "Telefone", SupportActivity.formatPhone(phone), () -> {
            try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:+" + phone.replaceAll("\\D", "")))); } catch (Exception e) { UI.toast(this, formatPhone(phone)); }
        });
        if (!phone.isEmpty()) contact(info, "WhatsApp", "Abrir conversa", () -> UI.openUrl(this, "https://wa.me/" + phone.replaceAll("\\D", "")));
        if (!email.isEmpty()) contact(info, "E-mail", email, () -> {
            try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + email))); } catch (Exception e) { UI.toast(this, email); }
        });
        if (!tg.isEmpty()) contact(info, "Telegram", "@" + tg, () -> UI.openUrl(this, "https://t.me/" + tg));
        if (!text.isEmpty()) {
            TextView t = UI.text(this, text, 13, UI.MUTED, false);
            int tp = UI.dp(this, 16);
            t.setPadding(tp, tp, tp, tp);
            info.addView(t);
        }
    }

    private void contact(LinearLayout g, String label, String value, final Runnable r) {
        if (g.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(0x1AFFFFFF);
            g.addView(d, new LinearLayout.LayoutParams(-1, 1));
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setFocusable(true); row.setClickable(true);
        row.setBackground(UI.focusBg(this, 0x00000000, 18));
        int p = UI.dp(this, 16);
        row.setPadding(p, UI.dp(this, 13), p, UI.dp(this, 13));
        row.addView(UI.text(this, label.toUpperCase(), 10, Cfg.primary(), true));
        row.addView(UI.text(this, value, 16, UI.WHITE, true));
        row.setOnClickListener(v -> r.run());
        g.addView(row);
    }
}
